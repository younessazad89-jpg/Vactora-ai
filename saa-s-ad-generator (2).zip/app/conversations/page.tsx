'use client'

import { Sidebar } from '@/components/Sidebar'
import { dummyConversations } from '@/lib/data'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { Search, Bot } from 'lucide-react'
import { useState } from 'react'

function getInitials(name: string) {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

export default function ConversationsPage() {
  const [selectedId, setSelectedId] = useState(dummyConversations[0]?.id)
  const selectedConversation = dummyConversations.find(c => c.id === selectedId)

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex overflow-hidden">
        {/* Conversations List */}
        <div className="w-80 border-r border-border flex flex-col">
          <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b border-border px-4 h-14 flex items-center">
            <h1 className="text-lg font-semibold text-foreground">Conversations</h1>
          </header>
          
          <div className="p-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search..." 
                className="pl-9 bg-card border-border h-9"
              />
            </div>
          </div>

          <div className="flex-1 overflow-auto">
            {dummyConversations.map((conversation) => (
              <div 
                key={conversation.id}
                onClick={() => setSelectedId(conversation.id)}
                className={cn(
                  "px-4 py-3 cursor-pointer transition-colors border-b border-border",
                  selectedId === conversation.id 
                    ? "bg-muted/50" 
                    : "hover:bg-muted/30"
                )}
              >
                <div className="flex items-start gap-3">
                  <Avatar className="w-9 h-9">
                    <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                      {getInitials(conversation.leadName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className={cn(
                        "text-sm truncate",
                        conversation.unread ? "font-semibold text-foreground" : "font-medium text-foreground"
                      )}>
                        {conversation.leadName}
                      </p>
                      <span className="text-xs text-muted-foreground flex-shrink-0">
                        {conversation.timestamp}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground truncate mt-0.5">
                      {conversation.lastMessage}
                    </p>
                  </div>
                  {conversation.unread && (
                    <div className="w-2 h-2 rounded-full bg-chart-2 flex-shrink-0 mt-2" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {selectedConversation ? (
            <>
              <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b border-border px-6 h-14 flex items-center gap-3">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                    {getInitials(selectedConversation.leadName)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium text-foreground">{selectedConversation.leadName}</p>
                  <p className="text-xs text-muted-foreground">{selectedConversation.leadPhone}</p>
                </div>
              </header>

              <div className="flex-1 p-6 overflow-auto">
                <div className="max-w-2xl mx-auto space-y-4">
                  {/* Sample messages */}
                  <div className="flex justify-start">
                    <div className="bg-card border border-border rounded-lg px-4 py-2 max-w-md">
                      <p className="text-sm text-foreground">Hello, I saw your ad about the premium package. Can you tell me more?</p>
                      <p className="text-xs text-muted-foreground mt-1">10:30 AM</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <div className="bg-primary/10 border border-primary/20 rounded-lg px-4 py-2 max-w-md">
                      <div className="flex items-center gap-1 mb-1">
                        <Bot className="w-3 h-3 text-primary" />
                        <span className="text-xs text-primary font-medium">AI Agent</span>
                      </div>
                      <p className="text-sm text-foreground">{selectedConversation.lastMessage.replace('AI: ', '')}</p>
                      <p className="text-xs text-muted-foreground mt-1">10:31 AM</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 border-t border-border">
                <div className="max-w-2xl mx-auto">
                  <Input 
                    placeholder="AI is handling this conversation..." 
                    disabled
                    className="bg-muted border-border"
                  />
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <p className="text-muted-foreground">Select a conversation</p>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
