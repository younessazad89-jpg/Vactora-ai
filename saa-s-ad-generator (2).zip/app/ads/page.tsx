'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Label } from '@/components/ui/label'
import { 
  Sparkles,
  Copy,
  RefreshCw,
  Download,
  Share2,
  ThumbsUp,
  ThumbsDown,
  Wand2,
  Target,
  TrendingUp,
  Zap,
  Facebook,
  Instagram,
  Youtube,
  Twitter,
  Linkedin,
  Globe,
  Image,
  Video,
  Type,
  Hash,
  ArrowRight,
  CheckCircle2,
  Star
} from 'lucide-react'

const platforms = [
  { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'text-[#1877F2]' },
  { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'text-[#E4405F]' },
  { id: 'tiktok', name: 'TikTok', icon: Video, color: 'text-white' },
  { id: 'google', name: 'Google Ads', icon: Globe, color: 'text-[#4285F4]' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'text-[#0A66C2]' },
  { id: 'youtube', name: 'YouTube', icon: Youtube, color: 'text-[#FF0000]' },
]

const adTypes = [
  { id: 'hooks', name: 'Hooks', icon: Zap },
  { id: 'headlines', name: 'Headlines', icon: Type },
  { id: 'copy', name: 'Ad Copy', icon: Hash },
  { id: 'scripts', name: 'Video Scripts', icon: Video },
  { id: 'images', name: 'Image Ideas', icon: Image },
  { id: 'cta', name: 'CTAs', icon: ArrowRight },
]

const generatedAds = [
  {
    id: '1',
    type: 'hook',
    platform: 'facebook',
    content: 'Stop losing $10,000/month to manual follow-ups. Here is how AI changed everything for 500+ agencies...',
    score: 94,
    saved: true,
  },
  {
    id: '2',
    type: 'hook',
    platform: 'facebook',
    content: 'POV: You just automated 80% of your sales team with one AI tool',
    score: 91,
    saved: false,
  },
  {
    id: '3',
    type: 'hook',
    platform: 'facebook',
    content: 'The reason your competitors are closing 3x more deals? They replaced humans with this...',
    score: 88,
    saved: false,
  },
]

const headlines = [
  { content: 'Never Miss Another Lead With 24/7 AI Sales Agents', score: 96 },
  { content: 'Turn WhatsApp Into Your #1 Sales Channel', score: 93 },
  { content: 'Close Deals While You Sleep - AI Does The Work', score: 91 },
  { content: 'From 10 Leads to 100+ Conversions Monthly', score: 89 },
]

const bodyCopy = `Tired of losing leads because you can not reply fast enough?

Vactora AI handles your WhatsApp, Instagram, and Email conversations 24/7. Our AI agents:

✅ Respond instantly to every inquiry
✅ Qualify leads automatically  
✅ Book meetings on your calendar
✅ Follow up until they buy or say goodbye

500+ agencies already use Vactora to 3x their conversion rates.

👉 Start your free trial today`

export default function AdsPage() {
  const [selectedPlatform, setSelectedPlatform] = useState('facebook')
  const [selectedType, setSelectedType] = useState('hooks')
  const [productDescription, setProductDescription] = useState('')
  const [targetAudience, setTargetAudience] = useState('')
  const [generating, setGenerating] = useState(false)

  const handleGenerate = () => {
    setGenerating(true)
    setTimeout(() => setGenerating(false), 2000)
  }

  return (
    <div className="flex h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">AI Ad Generator</h1>
              <p className="text-muted-foreground">Generate high-converting ads with AI</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge className="bg-primary/20 text-primary border-0">
                <Sparkles className="w-3 h-3 mr-1" />
                47 Credits Remaining
              </Badge>
              <Button variant="outline" className="rounded-xl border-white/[0.08]">
                <Download className="w-4 h-4 mr-2" />
                Export All
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Input Panel */}
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold text-white mb-6">Input Details</h3>
              
              {/* Platform Selection */}
              <div className="mb-6">
                <Label className="text-sm text-muted-foreground mb-3 block">Platform</Label>
                <div className="grid grid-cols-3 gap-2">
                  {platforms.map((platform) => (
                    <button
                      key={platform.id}
                      onClick={() => setSelectedPlatform(platform.id)}
                      className={`p-3 rounded-xl border transition-all ${
                        selectedPlatform === platform.id
                          ? 'bg-primary/10 border-primary'
                          : 'bg-white/[0.02] border-white/[0.06] hover:border-white/[0.1]'
                      }`}
                    >
                      <platform.icon className={`w-5 h-5 mx-auto mb-1 ${platform.color}`} />
                      <span className="text-[10px] text-muted-foreground">{platform.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Ad Type */}
              <div className="mb-6">
                <Label className="text-sm text-muted-foreground mb-3 block">Ad Type</Label>
                <div className="grid grid-cols-3 gap-2">
                  {adTypes.map((type) => (
                    <button
                      key={type.id}
                      onClick={() => setSelectedType(type.id)}
                      className={`p-3 rounded-xl border transition-all ${
                        selectedType === type.id
                          ? 'bg-primary/10 border-primary'
                          : 'bg-white/[0.02] border-white/[0.06] hover:border-white/[0.1]'
                      }`}
                    >
                      <type.icon className="w-4 h-4 mx-auto mb-1 text-muted-foreground" />
                      <span className="text-[10px] text-muted-foreground">{type.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Product Description */}
              <div className="mb-6">
                <Label className="text-sm text-muted-foreground mb-2 block">Product/Service</Label>
                <Textarea
                  value={productDescription}
                  onChange={(e) => setProductDescription(e.target.value)}
                  placeholder="Describe your product or service..."
                  className="bg-white/[0.04] border-white/[0.08] rounded-xl min-h-[100px]"
                />
              </div>

              {/* Target Audience */}
              <div className="mb-6">
                <Label className="text-sm text-muted-foreground mb-2 block">Target Audience</Label>
                <Input
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  placeholder="e.g., Marketing agencies, Coaches, SMBs..."
                  className="bg-white/[0.04] border-white/[0.08] rounded-xl"
                />
              </div>

              {/* Generate Button */}
              <Button 
                onClick={handleGenerate}
                disabled={generating}
                className="w-full rounded-xl bg-gradient-to-r from-primary to-accent hover:opacity-90 h-12"
              >
                {generating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Generate Ads
                  </>
                )}
              </Button>
            </div>

            {/* Output Panel */}
            <div className="lg:col-span-2 space-y-6">
              {/* Hooks/Headlines */}
              <div className="glass-card p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Generated Hooks</h3>
                  <Button variant="ghost" size="sm" className="rounded-full">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
                
                <div className="space-y-3">
                  {generatedAds.map((ad) => (
                    <div 
                      key={ad.id}
                      className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:border-white/[0.1] transition-all"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <p className="text-white flex-1">{ad.content}</p>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-green-500/20 text-green-400 border-0">
                            <Target className="w-3 h-3 mr-1" />
                            {ad.score}%
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/[0.06]">
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm" className="h-8 rounded-full">
                            <ThumbsUp className="w-3.5 h-3.5" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 rounded-full">
                            <ThumbsDown className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm" className="h-8 rounded-full">
                            <Copy className="w-3.5 h-3.5 mr-1" />
                            Copy
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 rounded-full">
                            <Star className={`w-3.5 h-3.5 ${ad.saved ? 'fill-yellow-400 text-yellow-400' : ''}`} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Headlines */}
              <div className="glass-card p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Headlines</h3>
                  <Button variant="ghost" size="sm" className="rounded-full">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {headlines.map((headline, i) => (
                    <div 
                      key={i}
                      className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:border-white/[0.1] transition-all cursor-pointer group"
                    >
                      <p className="text-white text-sm mb-2">{headline.content}</p>
                      <div className="flex items-center justify-between">
                        <Badge className="bg-primary/20 text-primary border-0 text-[10px]">
                          Score: {headline.score}%
                        </Badge>
                        <Copy className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Full Ad Copy */}
              <div className="glass-card p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">Full Ad Copy</h3>
                    <p className="text-sm text-muted-foreground">Ready-to-use Facebook ad copy</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-green-500/20 text-green-400 border-0">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Optimized
                    </Badge>
                    <Button variant="outline" size="sm" className="rounded-full border-white/[0.08]">
                      <Copy className="w-4 h-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                </div>
                
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                  <pre className="text-white text-sm whitespace-pre-wrap font-sans leading-relaxed">
                    {bodyCopy}
                  </pre>
                </div>

                <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                  <span>Characters: 487</span>
                  <span>Words: 78</span>
                  <span>Reading time: 30s</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
