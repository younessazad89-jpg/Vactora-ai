'use client'

import { Sidebar } from '@/components/Sidebar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Users, 
  DollarSign, 
  Copy, 
  Check,
  TrendingUp,
  Gift,
  Award,
  Sparkles,
  ExternalLink,
  ArrowRight
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'

const tiers = [
  {
    name: 'Referral Partner',
    commission: '20%',
    description: 'Lifetime commission on all referrals',
    features: [
      '20% recurring commission',
      'Lifetime payouts',
      'Basic affiliate dashboard',
      'Email support',
    ],
    color: 'from-blue-500/20 to-blue-600/10',
    borderColor: 'border-blue-500/30',
    example: '$997 client = $199/mo for you',
  },
  {
    name: 'Agency Partner',
    commission: '30%',
    description: 'Enhanced partnership with white-label access',
    features: [
      '30% recurring commission',
      'White-label dashboard',
      'Priority support',
      'Co-branded materials',
      'Quarterly strategy calls',
    ],
    color: 'from-primary/20 to-accent/10',
    borderColor: 'border-primary/30',
    example: '$997 client = $299/mo for you',
    popular: true,
  },
  {
    name: 'Reseller',
    commission: '50%/20%',
    description: '50% month 1, then 20% lifetime',
    features: [
      '50% first month commission',
      '20% recurring after',
      'Full white-label solution',
      'Dedicated account manager',
      'Custom pricing options',
      'API access',
    ],
    color: 'from-amber-500/20 to-orange-500/10',
    borderColor: 'border-amber-500/30',
    example: '$997 client = $498 + $199/mo',
  },
]

const earnings = [
  { month: 'Jan', amount: 1240 },
  { month: 'Feb', amount: 1890 },
  { month: 'Mar', amount: 2340 },
  { month: 'Apr', amount: 3120 },
  { month: 'May', amount: 4280 },
]

const referrals = [
  { name: 'Apex Marketing', status: 'active', plan: 'Pro', commission: 89.10, date: '2024-05-12' },
  { name: 'Growth Labs', status: 'active', plan: 'Agency', commission: 299.10, date: '2024-05-08' },
  { name: 'Digital First Co', status: 'trial', plan: 'Starter', commission: 0, date: '2024-05-15' },
  { name: 'Scale Solutions', status: 'active', plan: 'Pro', commission: 89.10, date: '2024-04-22' },
]

export default function AffiliatesPage() {
  const [copied, setCopied] = useState(false)
  const referralLink = 'https://vactora.ai/ref/ABC123XYZ'

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    toast.success('Referral link copied!')
    setTimeout(() => setCopied(false), 2000)
  }

  const totalEarnings = earnings.reduce((sum, e) => sum + e.amount, 0)
  const activeReferrals = referrals.filter(r => r.status === 'active').length
  const monthlyCommission = referrals.reduce((sum, r) => sum + r.commission, 0)

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <main className="flex-1 lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">Vactora Partners</h1>
              <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
                <Sparkles className="w-3 h-3 mr-1" />
                Affiliate Program
              </Badge>
            </div>
          </div>
        </header>

        <div className="p-4 lg:p-6 space-y-6 pb-24 lg:pb-6">
          {/* Hero Section */}
          <div className="glass-card rounded-xl p-8 bg-gradient-to-r from-primary/10 via-accent/5 to-transparent border-primary/20">
            <div className="max-w-2xl">
              <div className="flex items-center gap-2 mb-4">
                <Gift className="w-6 h-6 text-primary" />
                <span className="text-sm font-medium text-primary">Earn Passive Income</span>
              </div>
              <h2 className="text-3xl font-bold mb-3">
                Refer an agency, get <span className="gradient-text">20% lifetime</span>
              </h2>
              <p className="text-muted-foreground text-lg mb-6">
                Join the Vactora Partners program and earn recurring commissions for every client you refer. 
                A $997/mo client earns you $199/mo. 10 clients = $1,990/mo passive income.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 flex gap-2">
                  <Input 
                    value={referralLink}
                    readOnly
                    className="bg-background/50 font-mono text-sm"
                  />
                  <Button onClick={copyLink} variant="outline" className="shrink-0">
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
                <Button className="bg-primary hover:bg-primary/90 gap-2">
                  Share Now <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="glass-card border-border/50">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Earnings</p>
                    <p className="text-2xl font-bold">${totalEarnings.toLocaleString()}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card border-border/50">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Active Referrals</p>
                    <p className="text-2xl font-bold">{activeReferrals}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card border-border/50">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Monthly Commission</p>
                    <p className="text-2xl font-bold">${monthlyCommission.toFixed(2)}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-card border-border/50">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Partner Tier</p>
                    <p className="text-2xl font-bold">Referral</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                    <Award className="w-6 h-6 text-blue-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tiers */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Partner Tiers</h3>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {tiers.map((tier) => (
                <Card 
                  key={tier.name} 
                  className={`glass-card ${tier.borderColor} relative overflow-hidden`}
                >
                  {tier.popular && (
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                    </div>
                  )}
                  <CardHeader className={`bg-gradient-to-br ${tier.color}`}>
                    <CardTitle className="flex items-center gap-2">
                      <Award className="w-5 h-5" />
                      {tier.name}
                    </CardTitle>
                    <CardDescription>{tier.description}</CardDescription>
                    <div className="pt-2">
                      <span className="text-3xl font-bold">{tier.commission}</span>
                      <span className="text-muted-foreground ml-1">commission</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6 space-y-4">
                    <ul className="space-y-2">
                      {tier.features.map((feature, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm">
                          <Check className="w-4 h-4 text-success" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="pt-4 border-t border-border">
                      <p className="text-xs text-muted-foreground mb-1">Example earnings:</p>
                      <p className="text-sm font-medium text-accent">{tier.example}</p>
                    </div>
                    <Button 
                      className={tier.popular ? 'w-full bg-primary hover:bg-primary/90' : 'w-full'} 
                      variant={tier.popular ? 'default' : 'outline'}
                    >
                      {tier.popular ? 'Current Tier' : 'Upgrade'}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Referrals Table */}
          <Card className="glass-card border-border/50">
            <CardHeader>
              <CardTitle>Your Referrals</CardTitle>
              <CardDescription>Track all your referred clients and commissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Client</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Plan</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Commission</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Joined</th>
                    </tr>
                  </thead>
                  <tbody>
                    {referrals.map((referral, i) => (
                      <tr key={i} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                        <td className="py-3 px-4 font-medium">{referral.name}</td>
                        <td className="py-3 px-4">
                          <Badge variant={referral.status === 'active' ? 'default' : 'secondary'} 
                            className={referral.status === 'active' ? 'bg-success/20 text-success border-success/30' : ''}>
                            {referral.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-muted-foreground">{referral.plan}</td>
                        <td className="py-3 px-4 font-medium text-success">
                          {referral.commission > 0 ? `$${referral.commission.toFixed(2)}/mo` : '-'}
                        </td>
                        <td className="py-3 px-4 text-muted-foreground">{referral.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
