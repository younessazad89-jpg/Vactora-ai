'use client'

import { Sidebar } from '@/components/Sidebar'
import { leadsChartData, revenueChartData, conversionChartData, responseTimeData } from '@/lib/data'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import {
  BarChart3,
  TrendingUp,
  Sparkles,
  ArrowUpRight,
  Download,
  Users,
  DollarSign,
  Clock,
  Target,
} from 'lucide-react'
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'

// Supabase table: analytics { id, workspace_id, metric_type, value, date, created_at }

const funnelData = [
  { stage: 'Visitors', value: 12400, percent: 100 },
  { stage: 'Leads', value: 2847, percent: 23 },
  { stage: 'Qualified', value: 1245, percent: 10 },
  { stage: 'Booked', value: 523, percent: 4.2 },
  { stage: 'Won', value: 267, percent: 2.2 },
]

const aiInsights = [
  { text: 'Lead conversion rate is up 8.4% - WhatsApp Ads are your top performer.', type: 'positive' as const },
  { text: 'Response time dropped below 30s, improving close rate by an estimated 12%.', type: 'positive' as const },
  { text: 'Consider increasing follow-up frequency for the "Interested" stage - 34% drop off there.', type: 'suggestion' as const },
  { text: 'Tuesday and Wednesday are your highest converting days - allocate more ad spend.', type: 'suggestion' as const },
]

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="glass-card rounded-lg p-3 border border-border text-sm">
      <p className="text-muted-foreground text-xs mb-1">{label}</p>
      <p className="font-bold">{typeof payload[0].value === 'number' && payload[0].value > 100 ? `$${payload[0].value.toLocaleString()}` : payload[0].value}</p>
    </div>
  )
}

export default function AnalyticsPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">Analytics</h1>
            </div>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="w-4 h-4" />
              Export
            </Button>
          </div>
        </header>

        <div className="p-4 lg:p-6 space-y-6 pb-24 lg:pb-6">
          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Leads Growth */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" />
                  <h3 className="font-semibold text-sm">Leads Growth</h3>
                </div>
                <div className="flex items-center gap-1 text-success text-xs">
                  <ArrowUpRight className="w-3 h-3" />
                  <span>+18.2%</span>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={leadsChartData}>
                  <defs>
                    <linearGradient id="leadsGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.7 0.18 250)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.7 0.18 250)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.01 260)" />
                  <XAxis dataKey="month" tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="leads" stroke="oklch(0.7 0.18 250)" fill="url(#leadsGradient)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Revenue Growth */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-success" />
                  <h3 className="font-semibold text-sm">Revenue Growth</h3>
                </div>
                <div className="flex items-center gap-1 text-success text-xs">
                  <ArrowUpRight className="w-3 h-3" />
                  <span>+15.8%</span>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={revenueChartData}>
                  <defs>
                    <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.65 0.2 165)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.65 0.2 165)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.01 260)" />
                  <XAxis dataKey="month" tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="revenue" stroke="oklch(0.65 0.2 165)" fill="url(#revenueGradient)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Conversion Rate */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-chart-3" />
                  <h3 className="font-semibold text-sm">Conversion Rate</h3>
                </div>
                <div className="flex items-center gap-1 text-success text-xs">
                  <ArrowUpRight className="w-3 h-3" />
                  <span>+8.4%</span>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={conversionChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.01 260)" />
                  <XAxis dataKey="month" tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="rate" stroke="oklch(0.75 0.15 45)" strokeWidth={2} dot={{ fill: 'oklch(0.75 0.15 45)', r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Response Time */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-chart-5" />
                  <h3 className="font-semibold text-sm">Avg Response Time (seconds)</h3>
                </div>
                <div className="flex items-center gap-1 text-success text-xs">
                  <TrendingUp className="w-3 h-3" />
                  <span>-15% faster</span>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={responseTimeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.01 260)" />
                  <XAxis dataKey="day" tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'oklch(0.6 0 0)', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}s`} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="time" fill="oklch(0.7 0.15 200)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Bottom row: Funnel + AI Insights */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Funnel Analytics */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center gap-2 mb-6">
                <BarChart3 className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-sm">Sales Funnel</h3>
              </div>
              <div className="space-y-3">
                {funnelData.map((item, i) => (
                  <div key={item.stage} className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{item.stage}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{item.value.toLocaleString()}</span>
                        <span className="text-[10px] text-muted-foreground">({item.percent}%)</span>
                      </div>
                    </div>
                    <div className="h-2 rounded-full bg-muted/50 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all duration-1000"
                        style={{ width: `${item.percent}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Insights */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center gap-2 mb-6">
                <Sparkles className="w-4 h-4 text-accent" />
                <h3 className="font-semibold text-sm">AI-Generated Insights</h3>
              </div>
              <div className="space-y-3">
                {aiInsights.map((insight, i) => (
                  <div
                    key={i}
                    className={cn(
                      "p-3 rounded-lg border text-sm",
                      insight.type === 'positive'
                        ? "bg-success/5 border-success/20 text-success"
                        : "bg-primary/5 border-primary/20 text-foreground"
                    )}
                  >
                    <div className="flex items-start gap-2">
                      {insight.type === 'positive' ? (
                        <TrendingUp className="w-4 h-4 shrink-0 mt-0.5" />
                      ) : (
                        <Sparkles className="w-4 h-4 shrink-0 mt-0.5 text-primary" />
                      )}
                      <p className="text-xs leading-relaxed">{insight.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
