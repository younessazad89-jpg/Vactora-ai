'use client'

import { Sidebar } from '@/components/Sidebar'
import { dummyAgents } from '@/lib/data'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import {
  Bot,
  MessageCircle,
  UserCheck,
  RefreshCw,
  Calendar,
  Sparkles,
  TrendingUp,
  Zap,
  Upload,
  Globe,
  FileText,
  Mic,
  Brain,
  Shield,
  Copy,
  ArrowRight,
  Plus,
  Search,
} from 'lucide-react'
import { useState } from 'react'

const iconMap: Record<string, React.ElementType> = {
  MessageCircle,
  UserCheck,
  RefreshCw,
  Calendar,
}

const agentStatusColors = {
  active: 'bg-success/20 text-success border-success/30',
  paused: 'bg-warning/20 text-warning border-warning/30',
  inactive: 'bg-muted text-muted-foreground border-muted',
}

// Supabase table: agents { id, workspace_id, name, description, type, status, config, messages_handled, success_rate, created_at }

const trainingItems = [
  { name: 'Product FAQ', type: 'PDF', status: 'completed', confidence: 96, icon: FileText, lastTrained: '2 days ago' },
  { name: 'Company Website', type: 'URL', status: 'completed', confidence: 92, icon: Globe, lastTrained: '1 day ago' },
  { name: 'Sales Scripts', type: 'Document', status: 'completed', confidence: 94, icon: FileText, lastTrained: '3 days ago' },
  { name: 'Voice Samples', type: 'Audio', status: 'in_progress', confidence: 78, icon: Mic, lastTrained: 'Training...' },
]

export default function AgentsPage() {
  const [agents, setAgents] = useState(dummyAgents)
  const [competitorUrl, setCompetitorUrl] = useState('')
  const [cloneProgress, setCloneProgress] = useState(0)
  const [isCloning, setIsCloning] = useState(false)

  const toggleAgent = (id: string) => {
    setAgents(prev => prev.map(agent =>
      agent.id === id
        ? { ...agent, status: agent.status === 'active' ? 'paused' as const : 'active' as const }
        : agent
    ))
  }

  const handleClone = () => {
    if (!competitorUrl) return
    setIsCloning(true)
    setCloneProgress(0)
    const interval = setInterval(() => {
      setCloneProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsCloning(false)
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 500)
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">AI Agents</h1>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 text-xs">
                {agents.filter(a => a.status === 'active').length} Active
              </Badge>
            </div>
            <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4" />
              Create Agent
            </Button>
          </div>
        </header>

        <div className="p-4 lg:p-6 space-y-6 pb-24 lg:pb-6">
          <Tabs defaultValue="agents" className="space-y-6">
            <TabsList className="bg-muted/50 border border-border">
              <TabsTrigger value="agents" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <Bot className="w-4 h-4 mr-2" />
                Agents
              </TabsTrigger>
              <TabsTrigger value="training" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <Brain className="w-4 h-4 mr-2" />
                Training Center
              </TabsTrigger>
              <TabsTrigger value="clone" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <Copy className="w-4 h-4 mr-2" />
                Clone Competitor
              </TabsTrigger>
            </TabsList>

            {/* Agents Tab */}
            <TabsContent value="agents" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {agents.map((agent) => {
                  const Icon = iconMap[agent.icon] || Bot
                  return (
                    <div key={agent.id} className="glass-card rounded-xl p-6 transition-all duration-300 hover:scale-[1.01]">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "flex items-center justify-center w-11 h-11 rounded-xl",
                            agent.status === 'active'
                              ? "bg-gradient-to-br from-primary/20 to-accent/20"
                              : "bg-muted"
                          )}>
                            <Icon className={cn(
                              "w-5 h-5",
                              agent.status === 'active' ? "text-primary" : "text-muted-foreground"
                            )} />
                          </div>
                          <div>
                            <h3 className="font-semibold text-sm">{agent.name}</h3>
                            <p className="text-xs text-muted-foreground mt-0.5">{agent.description}</p>
                          </div>
                        </div>
                        <Switch
                          checked={agent.status === 'active'}
                          onCheckedChange={() => toggleAgent(agent.id)}
                        />
                      </div>

                      <div className="flex items-center gap-2 mb-4">
                        <Badge
                          variant="outline"
                          className={cn("text-[10px]", agentStatusColors[agent.status])}
                        >
                          {agent.status}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <p className="text-xs text-muted-foreground">Messages Handled</p>
                          <p className="text-lg font-bold">{agent.messagesHandled.toLocaleString()}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs text-muted-foreground">Success Rate</p>
                          <div className="flex items-center gap-2">
                            <p className="text-lg font-bold">{agent.successRate}%</p>
                            <TrendingUp className="w-4 h-4 text-success" />
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t border-border flex items-center gap-2">
                        <Button variant="outline" size="sm" className="flex-1 text-xs">
                          <Sparkles className="w-3 h-3 mr-1" />
                          Configure
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1 text-xs">
                          <Shield className="w-3 h-3 mr-1" />
                          Objections
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </TabsContent>

            {/* Training Center Tab */}
            <TabsContent value="training" className="space-y-6">
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="font-semibold text-lg">Knowledge Base</h3>
                    <p className="text-sm text-muted-foreground mt-1">Upload documents and data to train your AI agents</p>
                  </div>
                  <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
                    <Upload className="w-4 h-4" />
                    Upload
                  </Button>
                </div>

                <div className="space-y-3">
                  {trainingItems.map((item, i) => (
                    <div key={i} className="flex items-center gap-4 p-4 rounded-lg bg-muted/30 border border-border">
                      <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10">
                        <item.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-sm">{item.name}</p>
                          <Badge variant="outline" className="text-[10px]">{item.type}</Badge>
                        </div>
                        <div className="flex items-center gap-3">
                          <Progress value={item.confidence} className="h-1.5 flex-1 max-w-[200px]" />
                          <span className="text-xs text-muted-foreground">{item.confidence}% confidence</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-[10px]",
                            item.status === 'completed' ? "text-success border-success/30" : "text-warning border-warning/30"
                          )}
                        >
                          {item.status === 'completed' ? 'Trained' : 'Training'}
                        </Badge>
                        <p className="text-[10px] text-muted-foreground mt-1">{item.lastTrained}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Voice Cloning Section */}
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20">
                    <Mic className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Voice Cloning</h3>
                    <p className="text-xs text-muted-foreground">Clone your voice for AI phone calls</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-warning animate-pulse" />
                    <span className="text-sm">Voice model not yet configured</span>
                  </div>
                  <Button size="sm" variant="outline" className="gap-2">
                    <Mic className="w-3 h-3" />
                    Clone My Voice
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* Clone Competitor Tab */}
            <TabsContent value="clone" className="space-y-6">
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Zap className="w-5 h-5 text-accent" />
                  <h3 className="font-semibold text-lg">1-Click Clone Competitor</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-6">
                  Enter a competitor&apos;s website URL and our AI will analyze their sales approach, messaging, and objection handling to generate an optimized agent configuration.
                </p>

                <div className="flex items-center gap-3 mb-6">
                  <div className="relative flex-1">
                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="https://competitor.com"
                      value={competitorUrl}
                      onChange={(e) => setCompetitorUrl(e.target.value)}
                      className="pl-10 bg-muted/50 border-border"
                    />
                  </div>
                  <Button
                    onClick={handleClone}
                    disabled={isCloning || !competitorUrl}
                    className="gap-2 bg-accent text-accent-foreground hover:bg-accent/90"
                  >
                    {isCloning ? 'Analyzing...' : 'Analyze & Clone'}
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>

                {(isCloning || cloneProgress >= 100) && (
                  <div className="space-y-4 p-4 rounded-lg bg-muted/30 border border-border">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Analysis Progress</span>
                        <span className="font-medium">{Math.min(Math.round(cloneProgress), 100)}%</span>
                      </div>
                      <Progress value={Math.min(cloneProgress, 100)} className="h-2" />
                    </div>
                    {cloneProgress >= 100 && (
                      <div className="space-y-3 pt-2">
                        <div className="flex items-center gap-2 text-success text-sm">
                          <Sparkles className="w-4 h-4" />
                          <span className="font-medium">Analysis complete! Agent config generated.</span>
                        </div>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-center">
                            <p className="text-xs text-muted-foreground">Sales Tactics</p>
                            <p className="font-bold text-primary mt-1">12</p>
                          </div>
                          <div className="p-3 rounded-lg bg-accent/10 border border-accent/20 text-center">
                            <p className="text-xs text-muted-foreground">Objection Scripts</p>
                            <p className="font-bold text-accent mt-1">8</p>
                          </div>
                          <div className="p-3 rounded-lg bg-success/10 border border-success/20 text-center">
                            <p className="text-xs text-muted-foreground">Keywords Found</p>
                            <p className="font-bold text-success mt-1">34</p>
                          </div>
                        </div>
                        <Button className="w-full gap-2 bg-primary hover:bg-primary/90">
                          <Sparkles className="w-4 h-4" />
                          Apply Configuration to Agent
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
