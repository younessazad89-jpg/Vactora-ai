'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Plus,
  Search,
  MoreHorizontal,
  Mail,
  Shield,
  Users,
  Crown,
  Clock,
  Activity,
  Settings,
  Trash2,
  UserPlus,
  CheckCircle2,
  XCircle
} from 'lucide-react'

const teamMembers = [
  {
    id: '1',
    name: 'Ahmed Hassan',
    email: 'ahmed@vactora.ai',
    avatar: 'AH',
    role: 'Owner',
    status: 'online',
    lastActive: 'Now',
    permissions: ['all'],
    joinedAt: 'Jan 15, 2024',
    activity: 'Edited automation workflow',
  },
  {
    id: '2',
    name: 'Sarah Mitchell',
    email: 'sarah@vactora.ai',
    avatar: 'SM',
    role: 'Admin',
    status: 'online',
    lastActive: '5 min ago',
    permissions: ['leads', 'inbox', 'agents', 'analytics'],
    joinedAt: 'Feb 20, 2024',
    activity: 'Responded to lead',
  },
  {
    id: '3',
    name: 'Michael Chen',
    email: 'michael@vactora.ai',
    avatar: 'MC',
    role: 'Agent',
    status: 'away',
    lastActive: '1 hour ago',
    permissions: ['leads', 'inbox'],
    joinedAt: 'Mar 10, 2024',
    activity: 'Closed deal #1847',
  },
  {
    id: '4',
    name: 'Emily Johnson',
    email: 'emily@vactora.ai',
    avatar: 'EJ',
    role: 'Agent',
    status: 'offline',
    lastActive: '3 hours ago',
    permissions: ['inbox'],
    joinedAt: 'Apr 5, 2024',
    activity: 'Updated CRM contact',
  },
]

const pendingInvites = [
  { email: 'john@agency.com', role: 'Agent', sentAt: '2 days ago' },
  { email: 'lisa@company.com', role: 'Admin', sentAt: '5 days ago' },
]

const roles = [
  { name: 'Owner', description: 'Full access to all features', icon: Crown, color: 'text-yellow-400' },
  { name: 'Admin', description: 'Manage team and settings', icon: Shield, color: 'text-purple-400' },
  { name: 'Agent', description: 'Handle leads and conversations', icon: Users, color: 'text-blue-400' },
  { name: 'Viewer', description: 'View-only access', icon: Activity, color: 'text-muted-foreground' },
]

export default function TeamPage() {
  return (
    <div className="flex h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Team</h1>
              <p className="text-muted-foreground">Manage your team members and permissions</p>
            </div>
            <Button className="rounded-xl bg-primary hover:bg-primary/90">
              <UserPlus className="w-4 h-4 mr-2" />
              Invite Member
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="glass-card p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-white">{teamMembers.length}</div>
                  <div className="text-sm text-muted-foreground">Team Members</div>
                </div>
                <div className="p-3 rounded-xl bg-primary/10">
                  <Users className="w-5 h-5 text-primary" />
                </div>
              </div>
            </div>
            <div className="glass-card p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-white">
                    {teamMembers.filter(m => m.status === 'online').length}
                  </div>
                  <div className="text-sm text-muted-foreground">Online Now</div>
                </div>
                <div className="p-3 rounded-xl bg-green-500/10">
                  <Activity className="w-5 h-5 text-green-400" />
                </div>
              </div>
            </div>
            <div className="glass-card p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-white">{pendingInvites.length}</div>
                  <div className="text-sm text-muted-foreground">Pending Invites</div>
                </div>
                <div className="p-3 rounded-xl bg-yellow-500/10">
                  <Mail className="w-5 h-5 text-yellow-400" />
                </div>
              </div>
            </div>
            <div className="glass-card p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-white">4</div>
                  <div className="text-sm text-muted-foreground">Roles</div>
                </div>
                <div className="p-3 rounded-xl bg-purple-500/10">
                  <Shield className="w-5 h-5 text-purple-400" />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Team Members List */}
            <div className="lg:col-span-2">
              <div className="glass-card overflow-hidden">
                <div className="p-6 border-b border-white/[0.06]">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-white">Team Members</h3>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search members..." 
                        className="pl-10 w-64 bg-white/[0.04] border-white/[0.08] rounded-xl"
                      />
                    </div>
                  </div>
                </div>

                <div className="divide-y divide-white/[0.04]">
                  {teamMembers.map((member) => (
                    <div key={member.id} className="p-5 hover:bg-white/[0.02] transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="bg-gradient-to-br from-primary/40 to-accent/40 text-white">
                              {member.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-[#050816] ${
                            member.status === 'online' ? 'bg-green-500' :
                            member.status === 'away' ? 'bg-yellow-500' : 'bg-muted-foreground'
                          }`} />
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="font-medium text-white">{member.name}</span>
                            {member.role === 'Owner' && (
                              <Crown className="w-4 h-4 text-yellow-400" />
                            )}
                            <Badge 
                              className={`text-[10px] border-0 ${
                                member.role === 'Owner' ? 'bg-yellow-500/20 text-yellow-400' :
                                member.role === 'Admin' ? 'bg-purple-500/20 text-purple-400' :
                                'bg-blue-500/20 text-blue-400'
                              }`}
                            >
                              {member.role}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground">{member.email}</div>
                        </div>

                        <div className="text-right">
                          <div className="text-sm text-white">{member.lastActive}</div>
                          <div className="text-xs text-muted-foreground">{member.activity}</div>
                        </div>

                        <Button variant="ghost" size="icon" className="rounded-full">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pending Invites */}
              {pendingInvites.length > 0 && (
                <div className="glass-card mt-6 overflow-hidden">
                  <div className="p-6 border-b border-white/[0.06]">
                    <h3 className="text-lg font-semibold text-white">Pending Invites</h3>
                  </div>
                  <div className="divide-y divide-white/[0.04]">
                    {pendingInvites.map((invite, i) => (
                      <div key={i} className="p-5 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-full bg-white/[0.04] flex items-center justify-center">
                            <Mail className="w-5 h-5 text-muted-foreground" />
                          </div>
                          <div>
                            <div className="font-medium text-white">{invite.email}</div>
                            <div className="text-sm text-muted-foreground">
                              Invited as {invite.role} - {invite.sentAt}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm" className="rounded-full border-white/[0.08]">
                            Resend
                          </Button>
                          <Button variant="ghost" size="icon" className="rounded-full text-red-400">
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Roles Panel */}
            <div className="space-y-6">
              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Roles & Permissions</h3>
                <div className="space-y-3">
                  {roles.map((role, i) => (
                    <div 
                      key={i}
                      className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:border-white/[0.1] transition-all cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <role.icon className={`w-5 h-5 ${role.color}`} />
                        <div>
                          <div className="font-medium text-white">{role.name}</div>
                          <div className="text-xs text-muted-foreground">{role.description}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start rounded-xl border-white/[0.08]">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Invite via Email
                  </Button>
                  <Button variant="outline" className="w-full justify-start rounded-xl border-white/[0.08]">
                    <Settings className="w-4 h-4 mr-2" />
                    Manage Permissions
                  </Button>
                  <Button variant="outline" className="w-full justify-start rounded-xl border-white/[0.08]">
                    <Activity className="w-4 h-4 mr-2" />
                    View Activity Log
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
