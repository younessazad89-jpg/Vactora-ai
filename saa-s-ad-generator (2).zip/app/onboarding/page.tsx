'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Bot, 
  MessageSquare, 
  Building2, 
  Check, 
  ArrowRight, 
  ArrowLeft,
  Sparkles,
  Smartphone,
  Loader2
} from 'lucide-react'
import { toast } from 'sonner'

const steps = [
  { id: 1, title: 'Connect WhatsApp', description: 'Link your business WhatsApp' },
  { id: 2, title: 'Business Info', description: 'Tell us about your business' },
  { id: 3, title: 'AI Agent Setup', description: 'Configure your AI assistant' },
]

const industries = [
  'Marketing Agency',
  'Real Estate',
  'Dental/Medical',
  'Coaching/Consulting',
  'E-commerce',
  'SaaS/Tech',
  'Legal Services',
  'Financial Services',
  'Other',
]

export default function OnboardingPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)
  const [isConnecting, setIsConnecting] = useState(false)
  const [whatsappConnected, setWhatsappConnected] = useState(false)
  const [businessInfo, setBusinessInfo] = useState({
    name: '',
    industry: '',
    website: '',
  })
  const [agentConfig, setAgentConfig] = useState({
    name: '',
    greeting: '',
    personality: 'professional',
  })

  const progress = (currentStep / steps.length) * 100

  const connectWhatsApp = () => {
    setIsConnecting(true)
    // Simulate connection
    setTimeout(() => {
      setWhatsappConnected(true)
      setIsConnecting(false)
      toast.success('WhatsApp connected successfully!')
    }, 2000)
  }

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = () => {
    toast.success('Onboarding complete! Your AI agent is ready.')
    router.push('/')
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-accent glow-primary">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold gradient-text">Vactora AI</span>
          </div>
          <Badge variant="secondary">Setup Wizard</Badge>
        </div>
      </header>

      {/* Progress */}
      <div className="border-b border-border">
        <div className="max-w-4xl mx-auto p-4">
          <div className="flex items-center justify-between mb-2">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium ${
                  currentStep > step.id 
                    ? 'bg-success text-success-foreground' 
                    : currentStep === step.id 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {currentStep > step.id ? <Check className="w-4 h-4" /> : step.id}
                </div>
                {index < steps.length - 1 && (
                  <div className={`hidden sm:block w-24 lg:w-32 h-0.5 mx-2 ${
                    currentStep > step.id ? 'bg-success' : 'bg-muted'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <Progress value={progress} className="h-1" />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-xl">
          {/* Step 1: Connect WhatsApp */}
          {currentStep === 1 && (
            <Card className="glass-card border-border/50">
              <CardHeader className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500/20 to-green-600/10 flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="w-8 h-8 text-green-500" />
                </div>
                <CardTitle className="text-2xl">Connect Your WhatsApp</CardTitle>
                <CardDescription>
                  Link your WhatsApp Business account to start automating your sales
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!whatsappConnected ? (
                  <>
                    <div className="glass rounded-xl p-6 text-center">
                      <div className="w-48 h-48 bg-white rounded-xl mx-auto mb-4 flex items-center justify-center">
                        <div className="text-black text-xs">QR Code Placeholder</div>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Scan this QR code with your WhatsApp Business app
                      </p>
                    </div>
                    <div className="text-center">
                      <span className="text-sm text-muted-foreground">or</span>
                    </div>
                    <Button 
                      onClick={connectWhatsApp} 
                      className="w-full bg-green-600 hover:bg-green-700"
                      disabled={isConnecting}
                    >
                      {isConnecting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Connecting...
                        </>
                      ) : (
                        <>
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Connect with Phone Number
                        </>
                      )}
                    </Button>
                  </>
                ) : (
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-success/20 flex items-center justify-center mx-auto">
                      <Check className="w-8 h-8 text-success" />
                    </div>
                    <div>
                      <p className="font-medium">WhatsApp Connected!</p>
                      <p className="text-sm text-muted-foreground">+1 (555) 123-4567</p>
                    </div>
                    <Button onClick={handleNext} className="bg-primary hover:bg-primary/90">
                      Continue <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Step 2: Business Info */}
          {currentStep === 2 && (
            <Card className="glass-card border-border/50">
              <CardHeader className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center mx-auto mb-4">
                  <Building2 className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl">Tell Us About Your Business</CardTitle>
                <CardDescription>
                  This helps us customize your AI agent for your industry
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Business Name</Label>
                  <Input 
                    placeholder="Acme Marketing Agency"
                    value={businessInfo.name}
                    onChange={(e) => setBusinessInfo({ ...businessInfo, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Industry</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {industries.map((industry) => (
                      <Button
                        key={industry}
                        variant={businessInfo.industry === industry ? 'default' : 'outline'}
                        size="sm"
                        className={businessInfo.industry === industry ? 'bg-primary' : ''}
                        onClick={() => setBusinessInfo({ ...businessInfo, industry })}
                      >
                        {industry}
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Website (optional)</Label>
                  <Input 
                    placeholder="https://yourwebsite.com"
                    value={businessInfo.website}
                    onChange={(e) => setBusinessInfo({ ...businessInfo, website: e.target.value })}
                  />
                </div>
                <div className="flex gap-3 pt-4">
                  <Button variant="outline" onClick={handleBack}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                  </Button>
                  <Button 
                    onClick={handleNext} 
                    className="flex-1 bg-primary hover:bg-primary/90"
                    disabled={!businessInfo.name || !businessInfo.industry}
                  >
                    Continue <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: AI Agent Setup */}
          {currentStep === 3 && (
            <Card className="glass-card border-border/50">
              <CardHeader className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent/20 to-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-accent" />
                </div>
                <CardTitle className="text-2xl">Configure Your AI Agent</CardTitle>
                <CardDescription>
                  Set up how your AI assistant will interact with leads
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Agent Name</Label>
                  <Input 
                    placeholder="Sarah (Sales AI)"
                    value={agentConfig.name}
                    onChange={(e) => setAgentConfig({ ...agentConfig, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Greeting Message</Label>
                  <Input 
                    placeholder="Hi! I'm Sarah from Acme. How can I help you today?"
                    value={agentConfig.greeting}
                    onChange={(e) => setAgentConfig({ ...agentConfig, greeting: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Personality</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {['Professional', 'Friendly', 'Casual'].map((p) => (
                      <Button
                        key={p}
                        variant={agentConfig.personality === p.toLowerCase() ? 'default' : 'outline'}
                        size="sm"
                        className={agentConfig.personality === p.toLowerCase() ? 'bg-primary' : ''}
                        onClick={() => setAgentConfig({ ...agentConfig, personality: p.toLowerCase() })}
                      >
                        {p}
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="glass rounded-xl p-4 border border-accent/20 bg-accent/5">
                  <div className="flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-accent mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">AI will auto-generate</p>
                      <p className="text-xs text-muted-foreground">
                        Based on your industry, we&apos;ll create objection handlers, follow-up sequences, and booking scripts.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 pt-4">
                  <Button variant="outline" onClick={handleBack}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                  </Button>
                  <Button 
                    onClick={handleComplete} 
                    className="flex-1 bg-gradient-to-r from-primary to-accent hover:opacity-90"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Launch AI Agent
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
