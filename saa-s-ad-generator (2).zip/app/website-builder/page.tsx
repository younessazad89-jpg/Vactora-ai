'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Globe, 
  Sparkles, 
  Layout, 
  Type, 
  Image as ImageIcon, 
  Square, 
  MousePointer2,
  Monitor,
  Tablet,
  Smartphone,
  Eye,
  Save,
  Undo,
  Redo,
  Code,
  Palette,
  Layers,
  Plus,
  GripVertical,
  Settings,
  Rocket,
  Zap,
  CheckCircle2,
  ArrowRight
} from 'lucide-react'

const templates = [
  { id: 1, name: 'SaaS Landing', category: 'Landing Page', image: '/templates/saas.jpg', popular: true },
  { id: 2, name: 'Agency Pro', category: 'Business', image: '/templates/agency.jpg', popular: true },
  { id: 3, name: 'Dental Clinic', category: 'Healthcare', image: '/templates/dental.jpg', popular: false },
  { id: 4, name: 'Real Estate', category: 'Property', image: '/templates/realestate.jpg', popular: true },
  { id: 5, name: 'Fitness Coach', category: 'Health', image: '/templates/fitness.jpg', popular: false },
  { id: 6, name: 'E-commerce', category: 'Store', image: '/templates/ecommerce.jpg', popular: true },
]

const components = [
  { name: 'Hero Section', icon: Layout, category: 'Sections' },
  { name: 'Features Grid', icon: Square, category: 'Sections' },
  { name: 'Testimonials', icon: Type, category: 'Sections' },
  { name: 'Pricing Table', icon: Layers, category: 'Sections' },
  { name: 'CTA Banner', icon: Rocket, category: 'Sections' },
  { name: 'FAQ Accordion', icon: Plus, category: 'Sections' },
  { name: 'Text Block', icon: Type, category: 'Basic' },
  { name: 'Image', icon: ImageIcon, category: 'Basic' },
  { name: 'Button', icon: MousePointer2, category: 'Basic' },
  { name: 'Form', icon: Square, category: 'Basic' },
]

const websites = [
  { id: 1, name: 'Main Landing Page', domain: 'acme.vactora.site', status: 'Published', visits: 2453, conversions: 127, lastEdited: '2 hours ago' },
  { id: 2, name: 'Product Launch', domain: 'launch.acme.com', status: 'Draft', visits: 0, conversions: 0, lastEdited: '1 day ago' },
  { id: 3, name: 'Webinar Registration', domain: 'webinar.acme.com', status: 'Published', visits: 891, conversions: 234, lastEdited: '3 days ago' },
]

export default function WebsiteBuilderPage() {
  const [activeTab, setActiveTab] = useState('websites')
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null)
  const [viewMode, setViewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop')
  const [showBuilder, setShowBuilder] = useState(false)

  return (
    <div className="flex min-h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 p-8 ml-64">
        {!showBuilder ? (
          <>
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2">AI Website Builder</h1>
                <p className="text-gray-400">Create stunning websites and landing pages with AI</p>
              </div>
              <Button 
                onClick={() => setShowBuilder(true)}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create New Website
              </Button>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="glass-card border-white/10 p-1">
                <TabsTrigger value="websites" className="data-[state=active]:bg-white/10">
                  My Websites
                </TabsTrigger>
                <TabsTrigger value="templates" className="data-[state=active]:bg-white/10">
                  Templates
                </TabsTrigger>
                <TabsTrigger value="ai-generate" className="data-[state=active]:bg-white/10">
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI Generate
                </TabsTrigger>
              </TabsList>

              <TabsContent value="websites" className="space-y-4">
                {websites.map((site) => (
                  <div key={site.id} className="glass-card rounded-[18px] p-6 border border-white/5 hover:border-indigo-500/30 transition-all duration-300 group">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-indigo-600/20 to-purple-600/20 flex items-center justify-center border border-white/10">
                          <Globe className="w-8 h-8 text-indigo-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-white">{site.name}</h3>
                          <p className="text-sm text-gray-400">{site.domain}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-8">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-white">{site.visits.toLocaleString()}</p>
                          <p className="text-xs text-gray-400">Visits</p>
                        </div>
                        <div className="text-center">
                          <p className="text-2xl font-bold text-cyan-400">{site.conversions}</p>
                          <p className="text-xs text-gray-400">Conversions</p>
                        </div>
                        <Badge variant={site.status === 'Published' ? 'default' : 'secondary'} className={site.status === 'Published' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : ''}>
                          {site.status}
                        </Badge>
                        <p className="text-sm text-gray-500">{site.lastEdited}</p>
                        <Button variant="outline" size="sm" className="border-white/10 hover:bg-white/5" onClick={() => setShowBuilder(true)}>
                          Edit
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="templates" className="space-y-6">
                <div className="flex items-center gap-4 mb-6">
                  <Input placeholder="Search templates..." className="max-w-xs bg-white/5 border-white/10" />
                  <div className="flex gap-2">
                    {['All', 'Landing Page', 'Business', 'E-commerce', 'Healthcare'].map((cat) => (
                      <Button key={cat} variant="outline" size="sm" className="border-white/10 hover:bg-white/5">
                        {cat}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-6">
                  {templates.map((template) => (
                    <div 
                      key={template.id} 
                      className={`glass-card rounded-[18px] overflow-hidden border transition-all duration-300 cursor-pointer group ${
                        selectedTemplate === template.id ? 'border-indigo-500 ring-2 ring-indigo-500/20' : 'border-white/5 hover:border-indigo-500/30'
                      }`}
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <div className="aspect-[16/10] bg-gradient-to-br from-indigo-900/50 to-purple-900/50 relative">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Globe className="w-16 h-16 text-white/20" />
                        </div>
                        {template.popular && (
                          <Badge className="absolute top-3 right-3 bg-gradient-to-r from-amber-500 to-orange-500">
                            Popular
                          </Badge>
                        )}
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                          <Button size="sm" variant="secondary">
                            <Eye className="w-4 h-4 mr-2" />
                            Preview
                          </Button>
                          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowBuilder(true)}>
                            Use Template
                          </Button>
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-white">{template.name}</h3>
                        <p className="text-sm text-gray-400">{template.category}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="ai-generate" className="space-y-6">
                <div className="glass-card rounded-[18px] p-8 border border-white/5 max-w-2xl mx-auto">
                  <div className="text-center mb-8">
                    <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mx-auto mb-4 ai-glow">
                      <Sparkles className="w-10 h-10 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Generate with AI</h2>
                    <p className="text-gray-400">Describe your business and let AI create a stunning website for you</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Business Description</label>
                      <textarea 
                        className="w-full h-32 bg-white/5 border border-white/10 rounded-xl p-4 text-white placeholder-gray-500 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                        placeholder="e.g., A premium dental clinic in Dubai offering cosmetic dentistry, teeth whitening, and implants. Target audience is high-income professionals aged 30-55..."
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Industry</label>
                        <select className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white">
                          <option>Healthcare</option>
                          <option>Real Estate</option>
                          <option>Agency</option>
                          <option>E-commerce</option>
                          <option>SaaS</option>
                          <option>Coaching</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Style</label>
                        <select className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white">
                          <option>Modern & Minimal</option>
                          <option>Bold & Vibrant</option>
                          <option>Luxury & Premium</option>
                          <option>Friendly & Warm</option>
                          <option>Corporate & Professional</option>
                        </select>
                      </div>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 h-12 text-lg" onClick={() => setShowBuilder(true)}>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Generate Website
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </>
        ) : (
          /* Website Builder Interface */
          <div className="fixed inset-0 bg-[#050816] z-50 flex flex-col">
            {/* Builder Header */}
            <div className="h-16 border-b border-white/10 flex items-center justify-between px-4 bg-[#030712]">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="sm" onClick={() => setShowBuilder(false)}>
                  <ArrowRight className="w-4 h-4 rotate-180 mr-2" />
                  Back
                </Button>
                <div className="h-6 w-px bg-white/10" />
                <Input defaultValue="My Landing Page" className="w-48 bg-transparent border-transparent hover:border-white/10 focus:border-indigo-500 text-white font-medium" />
              </div>
              
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
                  <Button variant="ghost" size="sm" className={viewMode === 'desktop' ? 'bg-white/10' : ''} onClick={() => setViewMode('desktop')}>
                    <Monitor className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className={viewMode === 'tablet' ? 'bg-white/10' : ''} onClick={() => setViewMode('tablet')}>
                    <Tablet className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className={viewMode === 'mobile' ? 'bg-white/10' : ''} onClick={() => setViewMode('mobile')}>
                    <Smartphone className="w-4 h-4" />
                  </Button>
                </div>
                <div className="h-6 w-px bg-white/10" />
                <Button variant="ghost" size="sm"><Undo className="w-4 h-4" /></Button>
                <Button variant="ghost" size="sm"><Redo className="w-4 h-4" /></Button>
                <div className="h-6 w-px bg-white/10" />
                <Button variant="outline" size="sm" className="border-white/10">
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </Button>
                <Button variant="outline" size="sm" className="border-white/10">
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
                <Button size="sm" className="bg-gradient-to-r from-emerald-600 to-cyan-600">
                  <Rocket className="w-4 h-4 mr-2" />
                  Publish
                </Button>
              </div>
            </div>

            {/* Builder Body */}
            <div className="flex-1 flex">
              {/* Left Panel - Components */}
              <div className="w-64 border-r border-white/10 bg-[#030712] p-4 overflow-y-auto">
                <div className="mb-4">
                  <Button className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 mb-4">
                    <Sparkles className="w-4 h-4 mr-2" />
                    AI Generate Section
                  </Button>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xs font-semibold text-gray-400 uppercase mb-2">Sections</h3>
                    <div className="space-y-1">
                      {components.filter(c => c.category === 'Sections').map((comp) => (
                        <div key={comp.name} className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 cursor-grab transition-colors group">
                          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-indigo-500/20">
                            <comp.icon className="w-4 h-4 text-gray-400 group-hover:text-indigo-400" />
                          </div>
                          <span className="text-sm text-gray-300">{comp.name}</span>
                          <GripVertical className="w-4 h-4 text-gray-600 ml-auto opacity-0 group-hover:opacity-100" />
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-xs font-semibold text-gray-400 uppercase mb-2">Basic Elements</h3>
                    <div className="space-y-1">
                      {components.filter(c => c.category === 'Basic').map((comp) => (
                        <div key={comp.name} className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 cursor-grab transition-colors group">
                          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-indigo-500/20">
                            <comp.icon className="w-4 h-4 text-gray-400 group-hover:text-indigo-400" />
                          </div>
                          <span className="text-sm text-gray-300">{comp.name}</span>
                          <GripVertical className="w-4 h-4 text-gray-600 ml-auto opacity-0 group-hover:opacity-100" />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Center - Canvas */}
              <div className="flex-1 bg-[#0a0a1a] p-8 overflow-auto">
                <div className={`mx-auto bg-white rounded-xl shadow-2xl transition-all duration-300 ${
                  viewMode === 'desktop' ? 'w-full max-w-5xl' : viewMode === 'tablet' ? 'w-[768px]' : 'w-[375px]'
                }`} style={{ minHeight: '80vh' }}>
                  {/* Preview Content */}
                  <div className="p-8">
                    {/* Hero Section Preview */}
                    <div className="border-2 border-dashed border-gray-200 rounded-xl p-12 text-center hover:border-indigo-400 hover:bg-indigo-50/50 transition-colors cursor-pointer group">
                      <div className="text-6xl font-bold text-gray-900 mb-4">Your Amazing Headline</div>
                      <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">A compelling subheadline that explains your value proposition and gets visitors excited about your product or service.</p>
                      <button className="bg-indigo-600 text-white px-8 py-4 rounded-xl text-lg font-semibold">Get Started</button>
                      <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-sm text-indigo-600">Click to edit</span>
                      </div>
                    </div>

                    {/* Features Section Preview */}
                    <div className="mt-8 border-2 border-dashed border-gray-200 rounded-xl p-8 hover:border-indigo-400 hover:bg-indigo-50/50 transition-colors cursor-pointer">
                      <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">Features</h2>
                      <div className="grid grid-cols-3 gap-6">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="text-center p-6">
                            <div className="w-16 h-16 rounded-2xl bg-indigo-100 flex items-center justify-center mx-auto mb-4">
                              <Zap className="w-8 h-8 text-indigo-600" />
                            </div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-2">Feature {i}</h3>
                            <p className="text-gray-600">Description of this amazing feature.</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Drop Zone */}
                    <div className="mt-8 border-2 border-dashed border-gray-300 rounded-xl p-12 text-center text-gray-400">
                      <Plus className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p>Drag & drop components here</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Panel - Settings */}
              <div className="w-72 border-l border-white/10 bg-[#030712] p-4 overflow-y-auto">
                <Tabs defaultValue="style" className="space-y-4">
                  <TabsList className="w-full bg-white/5">
                    <TabsTrigger value="style" className="flex-1 data-[state=active]:bg-white/10">
                      <Palette className="w-4 h-4 mr-2" />
                      Style
                    </TabsTrigger>
                    <TabsTrigger value="settings" className="flex-1 data-[state=active]:bg-white/10">
                      <Settings className="w-4 h-4 mr-2" />
                      Settings
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="style" className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Background Color</label>
                      <div className="flex gap-2">
                        {['#ffffff', '#f8fafc', '#0f172a', '#1e1b4b', '#14532d'].map((color) => (
                          <button
                            key={color}
                            className="w-8 h-8 rounded-lg border-2 border-white/20 hover:border-indigo-500 transition-colors"
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Primary Color</label>
                      <div className="flex gap-2">
                        {['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'].map((color) => (
                          <button
                            key={color}
                            className="w-8 h-8 rounded-lg border-2 border-white/20 hover:border-white transition-colors"
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Font Family</label>
                      <select className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white text-sm">
                        <option>Inter</option>
                        <option>Poppins</option>
                        <option>DM Sans</option>
                        <option>Plus Jakarta Sans</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Border Radius</label>
                      <input type="range" className="w-full" min="0" max="24" defaultValue="12" />
                    </div>
                  </TabsContent>

                  <TabsContent value="settings" className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Page Title</label>
                      <Input defaultValue="My Landing Page" className="bg-white/5 border-white/10" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Meta Description</label>
                      <textarea className="w-full h-20 bg-white/5 border border-white/10 rounded-xl p-3 text-white text-sm" placeholder="SEO description..." />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Custom Domain</label>
                      <Input placeholder="www.yourdomain.com" className="bg-white/5 border-white/10" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Favicon</label>
                      <div className="w-full h-20 border-2 border-dashed border-white/10 rounded-xl flex items-center justify-center text-gray-400 text-sm hover:border-indigo-500/50 transition-colors cursor-pointer">
                        Click to upload
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
