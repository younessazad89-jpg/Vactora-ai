'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Workflow, 
  Plus, 
  ArrowRight, 
  Users, 
  CreditCard, 
  Calendar,
  Mail,
  MessageSquare,
  Eye,
  Copy,
  MoreVertical,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Play,
  Pause,
  BarChart3,
  MousePointer,
  DollarSign,
  Target
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const funnels = [
  {
    id: 1,
    name: 'High-Ticket Coaching Funnel',
    status: 'Active',
    visitors: 4521,
    conversions: 234,
    revenue: 47800,
    conversionRate: 5.2,
    trend: 'up',
    steps: ['Landing Page', 'Application Form', 'Thank You', 'Booking Page'],
  },
  {
    id: 2,
    name: 'Webinar Registration Funnel',
    status: 'Active',
    visitors: 2890,
    conversions: 567,
    revenue: 15600,
    conversionRate: 19.6,
    trend: 'up',
    steps: ['Opt-in Page', 'Confirmation', 'Webinar Room', 'Offer Page'],
  },
  {
    id: 3,
    name: 'Lead Magnet Funnel',
    status: 'Paused',
    visitors: 1234,
    conversions: 312,
    revenue: 0,
    conversionRate: 25.3,
    trend: 'down',
    steps: ['Squeeze Page', 'Download Page', 'Upsell'],
  },
  {
    id: 4,
    name: 'Product Launch Funnel',
    status: 'Draft',
    visitors: 0,
    conversions: 0,
    revenue: 0,
    conversionRate: 0,
    trend: 'neutral',
    steps: ['Coming Soon', 'Early Access', 'Sales Page', 'Checkout'],
  },
]

const funnelTemplates = [
  { id: 1, name: 'Lead Magnet', description: 'Capture leads with a free resource', steps: 3, popular: true },
  { id: 2, name: 'Webinar', description: 'Registration to replay to offer', steps: 4, popular: true },
  { id: 3, name: 'High-Ticket Sales', description: 'Application to call to close', steps: 5, popular: false },
  { id: 4, name: 'Product Launch', description: 'Build hype and launch', steps: 6, popular: true },
  { id: 5, name: 'Tripwire', description: 'Low-ticket to high-ticket', steps: 4, popular: false },
  { id: 6, name: 'Membership', description: 'Free trial to paid membership', steps: 4, popular: false },
]

export default function FunnelsPage() {
  const [activeTab, setActiveTab] = useState('funnels')
  const [showBuilder, setShowBuilder] = useState(false)
  const [selectedFunnel, setSelectedFunnel] = useState<typeof funnels[0] | null>(null)

  const totalRevenue = funnels.reduce((acc, f) => acc + f.revenue, 0)
  const totalVisitors = funnels.reduce((acc, f) => acc + f.visitors, 0)
  const totalConversions = funnels.reduce((acc, f) => acc + f.conversions, 0)

  return (
    <div className="flex min-h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Sales Funnels</h1>
            <p className="text-gray-400">Build high-converting funnels with AI</p>
          </div>
          <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
            <Plus className="w-4 h-4 mr-2" />
            Create Funnel
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                <Workflow className="w-5 h-5 text-indigo-400" />
              </div>
              <span className="text-gray-400">Active Funnels</span>
            </div>
            <p className="text-3xl font-bold text-white">{funnels.filter(f => f.status === 'Active').length}</p>
          </div>
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                <Eye className="w-5 h-5 text-cyan-400" />
              </div>
              <span className="text-gray-400">Total Visitors</span>
            </div>
            <p className="text-3xl font-bold text-white">{totalVisitors.toLocaleString()}</p>
          </div>
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                <Target className="w-5 h-5 text-emerald-400" />
              </div>
              <span className="text-gray-400">Conversions</span>
            </div>
            <p className="text-3xl font-bold text-white">{totalConversions.toLocaleString()}</p>
          </div>
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-amber-400" />
              </div>
              <span className="text-gray-400">Total Revenue</span>
            </div>
            <p className="text-3xl font-bold text-white">${totalRevenue.toLocaleString()}</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="glass-card border-white/10 p-1">
            <TabsTrigger value="funnels" className="data-[state=active]:bg-white/10">
              My Funnels
            </TabsTrigger>
            <TabsTrigger value="templates" className="data-[state=active]:bg-white/10">
              Templates
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-white/10">
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="funnels" className="space-y-4">
            {funnels.map((funnel) => (
              <div 
                key={funnel.id} 
                className="glass-card rounded-[18px] p-6 border border-white/5 hover:border-indigo-500/30 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedFunnel(funnel)}
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-indigo-600/20 to-purple-600/20 flex items-center justify-center border border-white/10">
                      <Workflow className="w-7 h-7 text-indigo-400" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">{funnel.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge 
                          variant="outline" 
                          className={
                            funnel.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                            funnel.status === 'Paused' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                            'bg-gray-500/20 text-gray-400 border-gray-500/30'
                          }
                        >
                          {funnel.status === 'Active' && <Play className="w-3 h-3 mr-1" />}
                          {funnel.status === 'Paused' && <Pause className="w-3 h-3 mr-1" />}
                          {funnel.status}
                        </Badge>
                        <span className="text-sm text-gray-500">{funnel.steps.length} steps</span>
                      </div>
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="hover:bg-white/5">
                        <MoreVertical className="w-5 h-5 text-gray-400" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-[#0a0a1a] border-white/10">
                      <DropdownMenuItem className="hover:bg-white/5">
                        <Eye className="w-4 h-4 mr-2" /> View
                      </DropdownMenuItem>
                      <DropdownMenuItem className="hover:bg-white/5">
                        <Copy className="w-4 h-4 mr-2" /> Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuItem className="hover:bg-white/5 text-red-400">
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Funnel Steps Visualization */}
                <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
                  {funnel.steps.map((step, idx) => (
                    <div key={idx} className="flex items-center">
                      <div className="px-4 py-2 bg-white/5 rounded-lg border border-white/10 text-sm text-gray-300 whitespace-nowrap">
                        {step}
                      </div>
                      {idx < funnel.steps.length - 1 && (
                        <ArrowRight className="w-4 h-4 text-gray-600 mx-2 flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>

                {/* Funnel Stats */}
                <div className="grid grid-cols-4 gap-4">
                  <div className="bg-white/5 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                      <Eye className="w-4 h-4" />
                      Visitors
                    </div>
                    <p className="text-xl font-semibold text-white">{funnel.visitors.toLocaleString()}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                      <MousePointer className="w-4 h-4" />
                      Conversions
                    </div>
                    <p className="text-xl font-semibold text-white">{funnel.conversions.toLocaleString()}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                      <Target className="w-4 h-4" />
                      Conv. Rate
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="text-xl font-semibold text-white">{funnel.conversionRate}%</p>
                      {funnel.trend === 'up' && <TrendingUp className="w-4 h-4 text-emerald-400" />}
                      {funnel.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-400" />}
                    </div>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
                      <DollarSign className="w-4 h-4" />
                      Revenue
                    </div>
                    <p className="text-xl font-semibold text-emerald-400">${funnel.revenue.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="templates" className="space-y-6">
            <div className="glass-card rounded-[18px] p-6 border border-white/5 mb-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center ai-glow">
                  <Sparkles className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white">AI Funnel Generator</h3>
                  <p className="text-gray-400">Describe your goal and let AI build a complete funnel</p>
                </div>
                <Button className="bg-gradient-to-r from-indigo-600 to-purple-600">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate with AI
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-6">
              {funnelTemplates.map((template) => (
                <div 
                  key={template.id}
                  className="glass-card rounded-[18px] p-6 border border-white/5 hover:border-indigo-500/30 transition-all duration-300 cursor-pointer group"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600/20 to-purple-600/20 flex items-center justify-center">
                      <Workflow className="w-6 h-6 text-indigo-400" />
                    </div>
                    {template.popular && (
                      <Badge className="bg-gradient-to-r from-amber-500 to-orange-500">Popular</Badge>
                    )}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{template.name}</h3>
                  <p className="text-gray-400 text-sm mb-4">{template.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">{template.steps} steps</span>
                    <Button size="sm" variant="outline" className="border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                      Use Template
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="glass-card rounded-[18px] p-6 border border-white/5">
              <h3 className="text-lg font-semibold text-white mb-6">Funnel Performance Comparison</h3>
              <div className="space-y-4">
                {funnels.filter(f => f.status === 'Active').map((funnel) => (
                  <div key={funnel.id} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-300">{funnel.name}</span>
                      <span className="text-white font-medium">{funnel.conversionRate}%</span>
                    </div>
                    <div className="h-3 bg-white/5 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(funnel.conversionRate * 4, 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="glass-card rounded-[18px] p-6 border border-white/5">
                <h3 className="text-lg font-semibold text-white mb-4">Top Performing Steps</h3>
                <div className="space-y-3">
                  {[
                    { step: 'Webinar Opt-in Page', rate: 45.2 },
                    { step: 'Lead Magnet Squeeze', rate: 38.7 },
                    { step: 'Application Form', rate: 22.1 },
                    { step: 'Checkout Page', rate: 12.4 },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-white/5 rounded-xl">
                      <span className="text-gray-300">{item.step}</span>
                      <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                        {item.rate}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-card rounded-[18px] p-6 border border-white/5">
                <h3 className="text-lg font-semibold text-white mb-4">AI Recommendations</h3>
                <div className="space-y-3">
                  {[
                    { text: 'Add urgency timer to coaching funnel checkout', impact: 'High' },
                    { text: 'A/B test webinar headline variations', impact: 'Medium' },
                    { text: 'Add testimonials to lead magnet page', impact: 'High' },
                  ].map((rec, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 bg-white/5 rounded-xl">
                      <Sparkles className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-gray-300 text-sm">{rec.text}</p>
                        <Badge variant="outline" className={`mt-2 ${rec.impact === 'High' ? 'text-emerald-400 border-emerald-500/30' : 'text-amber-400 border-amber-500/30'}`}>
                          {rec.impact} Impact
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
