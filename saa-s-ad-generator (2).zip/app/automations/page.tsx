'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { 
  Plus,
  Play,
  Pause,
  MoreHorizontal,
  Zap,
  MessageSquare,
  Mail,
  Calendar,
  CreditCard,
  Bot,
  Users,
  Clock,
  GitBranch,
  ArrowRight,
  Filter,
  Search,
  Sparkles,
  TrendingUp,
  Target,
  Activity
} from 'lucide-react'

const automations = [
  {
    id: '1',
    name: 'New Lead Welcome Sequence',
    description: 'Automatically welcome new leads and qualify them with AI',
    trigger: 'New Lead',
    actions: ['WhatsApp Message', 'AI Qualification', 'CRM Update'],
    status: 'active',
    runs: 1247,
    successRate: 94,
    lastRun: '2 min ago',
  },
  {
    id: '2',
    name: 'Abandoned Cart Recovery',
    description: 'Send follow-up messages for abandoned carts',
    trigger: 'Cart Abandoned',
    actions: ['Wait 1 hour', 'Email', 'WhatsApp Reminder'],
    status: 'active',
    runs: 856,
    successRate: 32,
    lastRun: '15 min ago',
  },
  {
    id: '3',
    name: 'Meeting Reminder Flow',
    description: 'Send reminders before scheduled meetings',
    trigger: 'Meeting Scheduled',
    actions: ['Wait 24h', 'WhatsApp Reminder', 'Wait 1h', 'SMS Reminder'],
    status: 'active',
    runs: 2134,
    successRate: 98,
    lastRun: '1 hour ago',
  },
  {
    id: '4',
    name: 'Post-Purchase Upsell',
    description: 'Upsell related products after purchase',
    trigger: 'Payment Received',
    actions: ['Wait 3 days', 'AI Product Recommendation', 'Email Offer'],
    status: 'paused',
    runs: 432,
    successRate: 18,
    lastRun: '3 days ago',
  },
  {
    id: '5',
    name: 'Lead Nurturing Sequence',
    description: '7-day nurturing sequence for cold leads',
    trigger: 'Lead Tagged Cold',
    actions: ['Day 1 Email', 'Day 3 WhatsApp', 'Day 5 Email', 'Day 7 Call'],
    status: 'active',
    runs: 678,
    successRate: 45,
    lastRun: '30 min ago',
  },
]

const triggerTypes = [
  { name: 'New Lead', icon: Users, color: 'bg-blue-500/20 text-blue-400' },
  { name: 'Message Received', icon: MessageSquare, color: 'bg-green-500/20 text-green-400' },
  { name: 'Payment', icon: CreditCard, color: 'bg-purple-500/20 text-purple-400' },
  { name: 'Booking', icon: Calendar, color: 'bg-yellow-500/20 text-yellow-400' },
  { name: 'Tag Added', icon: Filter, color: 'bg-pink-500/20 text-pink-400' },
  { name: 'Time Based', icon: Clock, color: 'bg-orange-500/20 text-orange-400' },
]

const actionTypes = [
  { name: 'Send WhatsApp', icon: MessageSquare, color: 'text-[#25D366]' },
  { name: 'Send Email', icon: Mail, color: 'text-blue-400' },
  { name: 'AI Response', icon: Bot, color: 'text-primary' },
  { name: 'Update CRM', icon: Users, color: 'text-purple-400' },
  { name: 'Book Meeting', icon: Calendar, color: 'text-yellow-400' },
  { name: 'Wait/Delay', icon: Clock, color: 'text-muted-foreground' },
  { name: 'Condition', icon: GitBranch, color: 'text-orange-400' },
  { name: 'Stripe Payment', icon: CreditCard, color: 'text-green-400' },
]

const stats = [
  { label: 'Active Automations', value: '12', icon: Zap, trend: '+2' },
  { label: 'Total Runs Today', value: '3,847', icon: Activity, trend: '+18%' },
  { label: 'Success Rate', value: '94%', icon: Target, trend: '+2%' },
  { label: 'Time Saved', value: '127h', icon: Clock, trend: 'this month' },
]

export default function AutomationsPage() {
  const [automationStates, setAutomationStates] = useState<Record<string, boolean>>(
    automations.reduce((acc, a) => ({ ...acc, [a.id]: a.status === 'active' }), {})
  )

  return (
    <div className="flex h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Automations</h1>
              <p className="text-muted-foreground">Build powerful AI-driven workflows</p>
            </div>
            <Button className="rounded-xl bg-primary hover:bg-primary/90 glow-primary">
              <Plus className="w-4 h-4 mr-2" />
              Create Automation
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat, i) => (
              <div key={i} className="glass-card-hover p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2.5 rounded-xl bg-primary/10">
                    <stat.icon className="w-5 h-5 text-primary" />
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-0 text-xs">
                    {stat.trend}
                  </Badge>
                </div>
                <div className="text-2xl font-bold text-white mb-0.5">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Quick Create Section */}
          <div className="glass-card p-6 mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-semibold text-white">Quick Create with AI</h3>
            </div>
            <div className="flex gap-3">
              <Input 
                placeholder="Describe your automation in plain English... e.g., 'Send a WhatsApp reminder 1 hour before meetings'"
                className="flex-1 bg-white/[0.04] border-white/[0.08] rounded-xl"
              />
              <Button className="rounded-xl bg-gradient-to-r from-primary to-accent">
                <Zap className="w-4 h-4 mr-2" />
                Generate
              </Button>
            </div>
          </div>

          {/* Trigger & Action Types */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div className="glass-card p-6">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                Triggers
              </h3>
              <div className="grid grid-cols-3 gap-3">
                {triggerTypes.map((trigger, i) => (
                  <button
                    key={i}
                    className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:bg-white/[0.04] hover:border-white/[0.1] transition-all text-center"
                  >
                    <div className={`w-10 h-10 rounded-xl ${trigger.color.split(' ')[0]} flex items-center justify-center mx-auto mb-2`}>
                      <trigger.icon className={`w-5 h-5 ${trigger.color.split(' ')[1]}`} />
                    </div>
                    <span className="text-xs text-muted-foreground">{trigger.name}</span>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="glass-card p-6">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <ArrowRight className="w-4 h-4 text-green-400" />
                Actions
              </h3>
              <div className="grid grid-cols-4 gap-3">
                {actionTypes.map((action, i) => (
                  <button
                    key={i}
                    className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:bg-white/[0.04] hover:border-white/[0.1] transition-all text-center"
                  >
                    <action.icon className={`w-5 h-5 ${action.color} mx-auto mb-2`} />
                    <span className="text-[10px] text-muted-foreground">{action.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Automations List */}
          <div className="glass-card overflow-hidden">
            <div className="p-6 border-b border-white/[0.06]">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">Your Automations</h3>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input 
                      placeholder="Search..." 
                      className="pl-10 w-64 bg-white/[0.04] border-white/[0.08] rounded-xl"
                    />
                  </div>
                  <Button variant="outline" size="icon" className="rounded-xl border-white/[0.08]">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="divide-y divide-white/[0.04]">
              {automations.map((automation) => (
                <div key={automation.id} className="p-6 hover:bg-white/[0.02] transition-colors">
                  <div className="flex items-center gap-6">
                    <Switch
                      checked={automationStates[automation.id]}
                      onCheckedChange={(checked) => 
                        setAutomationStates(prev => ({ ...prev, [automation.id]: checked }))
                      }
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h4 className="font-medium text-white">{automation.name}</h4>
                        <Badge 
                          className={`text-[10px] ${
                            automationStates[automation.id]
                              ? 'bg-green-500/20 text-green-400' 
                              : 'bg-muted text-muted-foreground'
                          } border-0`}
                        >
                          {automationStates[automation.id] ? 'Active' : 'Paused'}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{automation.description}</p>
                      
                      {/* Flow Preview */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="border-yellow-500/30 text-yellow-400 bg-yellow-500/10">
                          <Zap className="w-3 h-3 mr-1" />
                          {automation.trigger}
                        </Badge>
                        {automation.actions.map((action, i) => (
                          <div key={i} className="flex items-center gap-2">
                            <ArrowRight className="w-3 h-3 text-muted-foreground" />
                            <Badge variant="outline" className="border-white/10 text-muted-foreground">
                              {action}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center gap-8">
                      <div className="text-center">
                        <div className="text-lg font-semibold text-white">{automation.runs.toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">Total Runs</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-white">{automation.successRate}%</div>
                        <div className="text-xs text-muted-foreground">Success Rate</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground">{automation.lastRun}</div>
                        <div className="text-xs text-muted-foreground">Last Run</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon" className="rounded-full">
                          {automationStates[automation.id] ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4" />
                          )}
                        </Button>
                        <Button variant="ghost" size="icon" className="rounded-full">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
