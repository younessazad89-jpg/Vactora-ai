'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Search, 
  Filter, 
  Star, 
  Archive, 
  Trash2, 
  MoreHorizontal,
  Phone,
  Video,
  Send,
  Paperclip,
  Smile,
  Mic,
  Bot,
  User,
  Clock,
  CheckCheck,
  MessageSquare,
  Mail,
  Instagram,
  Sparkles,
  Globe,
  Zap,
  AlertCircle
} from 'lucide-react'

// Channel icons
const channelIcons: Record<string, { icon: React.ReactNode; color: string; bg: string }> = {
  whatsapp: { 
    icon: <MessageSquare className="w-4 h-4" />, 
    color: 'text-[#25D366]', 
    bg: 'bg-[#25D366]/10' 
  },
  instagram: { 
    icon: <Instagram className="w-4 h-4" />, 
    color: 'text-[#E4405F]', 
    bg: 'bg-[#E4405F]/10' 
  },
  email: { 
    icon: <Mail className="w-4 h-4" />, 
    color: 'text-[#6366f1]', 
    bg: 'bg-[#6366f1]/10' 
  },
  sms: { 
    icon: <MessageSquare className="w-4 h-4" />, 
    color: 'text-[#22d3ee]', 
    bg: 'bg-[#22d3ee]/10' 
  },
  messenger: { 
    icon: <MessageSquare className="w-4 h-4" />, 
    color: 'text-[#0084FF]', 
    bg: 'bg-[#0084FF]/10' 
  },
  telegram: { 
    icon: <Send className="w-4 h-4" />, 
    color: 'text-[#0088cc]', 
    bg: 'bg-[#0088cc]/10' 
  },
}

const conversations = [
  {
    id: '1',
    name: 'Sarah Mitchell',
    avatar: 'SM',
    channel: 'whatsapp',
    lastMessage: 'I am interested in your premium package. Can you tell me more about the pricing?',
    time: '2 min ago',
    unread: 3,
    status: 'hot',
    aiHandled: true,
    priority: 'high',
  },
  {
    id: '2',
    name: 'James Wilson',
    avatar: 'JW',
    channel: 'instagram',
    lastMessage: 'Do you offer payment plans for the enterprise tier?',
    time: '15 min ago',
    unread: 1,
    status: 'warm',
    aiHandled: true,
    priority: 'medium',
  },
  {
    id: '3',
    name: 'Emily Chen',
    avatar: 'EC',
    channel: 'email',
    lastMessage: 'Thank you for the detailed proposal. I will review it with my team.',
    time: '1 hour ago',
    unread: 0,
    status: 'warm',
    aiHandled: false,
    priority: 'low',
  },
  {
    id: '4',
    name: 'Michael Brown',
    avatar: 'MB',
    channel: 'messenger',
    lastMessage: 'Can we schedule a demo for next Tuesday?',
    time: '2 hours ago',
    unread: 2,
    status: 'hot',
    aiHandled: true,
    priority: 'high',
  },
  {
    id: '5',
    name: 'Lisa Anderson',
    avatar: 'LA',
    channel: 'sms',
    lastMessage: 'Please send me the contract when ready.',
    time: '3 hours ago',
    unread: 0,
    status: 'cold',
    aiHandled: false,
    priority: 'low',
  },
  {
    id: '6',
    name: 'David Kim',
    avatar: 'DK',
    channel: 'telegram',
    lastMessage: 'What integrations do you support?',
    time: '5 hours ago',
    unread: 1,
    status: 'warm',
    aiHandled: true,
    priority: 'medium',
  },
]

const messages = [
  {
    id: '1',
    sender: 'customer',
    content: 'Hi! I saw your ad on Instagram and I am interested in learning more about Vactora AI.',
    time: '10:30 AM',
    status: 'read',
  },
  {
    id: '2',
    sender: 'ai',
    content: 'Hello Sarah! Thank you for reaching out. I am Vactora AI, your personal sales assistant. I would be happy to help you learn more about our platform. What specific features are you most interested in?',
    time: '10:30 AM',
    status: 'read',
    aiConfidence: 95,
  },
  {
    id: '3',
    sender: 'customer',
    content: 'I run a marketing agency and we need something to automate our WhatsApp and Instagram responses. Do you support that?',
    time: '10:32 AM',
    status: 'read',
  },
  {
    id: '4',
    sender: 'ai',
    content: 'Absolutely! Vactora AI specializes in omni-channel automation. We support WhatsApp, Instagram, Email, SMS, Messenger, and Telegram - all from one unified inbox. Our AI agents can handle customer inquiries 24/7, qualify leads, and even book appointments automatically.',
    time: '10:32 AM',
    status: 'read',
    aiConfidence: 98,
  },
  {
    id: '5',
    sender: 'customer',
    content: 'That sounds perfect! I am interested in your premium package. Can you tell me more about the pricing?',
    time: '10:35 AM',
    status: 'read',
  },
]

const aiSuggestions = [
  'Our Pro plan at $297/mo includes unlimited AI agents and priority support.',
  'Would you like me to schedule a demo call to discuss your specific needs?',
  'I can send you a detailed comparison of our plans if that helps.',
]

export default function InboxPage() {
  const [selectedConversation, setSelectedConversation] = useState(conversations[0])
  const [messageInput, setMessageInput] = useState('')
  const [activeChannel, setActiveChannel] = useState('all')

  const filteredConversations = activeChannel === 'all' 
    ? conversations 
    : conversations.filter(c => c.channel === activeChannel)

  return (
    <div className="flex h-screen bg-[#050816]">
      <Sidebar />
      
      <div className="flex-1 flex overflow-hidden">
        {/* Conversations List */}
        <div className="w-[380px] border-r border-white/[0.06] flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-white/[0.06]">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-xl font-semibold text-white">Inbox</h1>
              <div className="flex items-center gap-2">
                <Badge className="bg-primary/20 text-primary border-0">
                  <Bot className="w-3 h-3 mr-1" />
                  AI Active
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {conversations.filter(c => c.unread > 0).length} unread
                </span>
              </div>
            </div>
            
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search conversations..." 
                className="pl-10 bg-white/[0.04] border-white/[0.08] rounded-xl"
              />
            </div>
          </div>

          {/* Channel Tabs */}
          <div className="px-4 py-3 border-b border-white/[0.06]">
            <div className="flex gap-2 overflow-x-auto scrollbar-hide">
              <Button
                variant={activeChannel === 'all' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveChannel('all')}
                className="rounded-full text-xs"
              >
                All
              </Button>
              {Object.entries(channelIcons).map(([key, { icon, color }]) => (
                <Button
                  key={key}
                  variant={activeChannel === key ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveChannel(key)}
                  className={`rounded-full text-xs ${activeChannel !== key ? color : ''}`}
                >
                  {icon}
                </Button>
              ))}
            </div>
          </div>

          {/* Conversations */}
          <div className="flex-1 overflow-y-auto">
            {filteredConversations.map((conv) => (
              <div
                key={conv.id}
                onClick={() => setSelectedConversation(conv)}
                className={`p-4 border-b border-white/[0.04] cursor-pointer transition-all hover:bg-white/[0.02] ${
                  selectedConversation?.id === conv.id ? 'bg-white/[0.04]' : ''
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-gradient-to-br from-primary/40 to-accent/40 text-white text-sm">
                        {conv.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-1 -right-1 p-1 rounded-full ${channelIcons[conv.channel].bg}`}>
                      <span className={channelIcons[conv.channel].color}>
                        {channelIcons[conv.channel].icon}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-white truncate">{conv.name}</span>
                        {conv.aiHandled && (
                          <Bot className="w-3.5 h-3.5 text-primary" />
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground">{conv.time}</span>
                    </div>
                    
                    <p className="text-sm text-muted-foreground truncate mb-2">
                      {conv.lastMessage}
                    </p>
                    
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="outline" 
                        className={`text-[10px] px-1.5 py-0 ${
                          conv.status === 'hot' 
                            ? 'border-red-500/50 text-red-400 bg-red-500/10' 
                            : conv.status === 'warm'
                            ? 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10'
                            : 'border-blue-500/50 text-blue-400 bg-blue-500/10'
                        }`}
                      >
                        {conv.status}
                      </Badge>
                      {conv.unread > 0 && (
                        <Badge className="bg-primary text-white text-[10px] px-1.5 py-0 h-4 min-w-4 flex items-center justify-center">
                          {conv.unread}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <div className="h-16 px-6 border-b border-white/[0.06] flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-gradient-to-br from-primary/40 to-accent/40 text-white">
                  {selectedConversation?.avatar}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-white">{selectedConversation?.name}</span>
                  <div className={`w-2 h-2 rounded-full ${
                    selectedConversation?.status === 'hot' ? 'bg-red-500' : 'bg-green-500'
                  }`} />
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className={channelIcons[selectedConversation?.channel || 'whatsapp'].color}>
                    {selectedConversation?.channel}
                  </span>
                  <span>Last active 2 min ago</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="rounded-full">
                <Phone className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Video className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Star className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Archive className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'customer' ? 'justify-start' : 'justify-end'}`}
              >
                <div className={`max-w-[70%] ${msg.sender === 'customer' ? '' : 'order-2'}`}>
                  <div
                    className={`rounded-2xl px-4 py-3 ${
                      msg.sender === 'customer'
                        ? 'bg-white/[0.06] text-white'
                        : msg.sender === 'ai'
                        ? 'bg-gradient-to-r from-primary/20 to-accent/20 text-white border border-primary/20'
                        : 'bg-primary text-white'
                    }`}
                  >
                    {msg.sender === 'ai' && (
                      <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/10">
                        <Bot className="w-4 h-4 text-primary" />
                        <span className="text-xs text-primary">AI Assistant</span>
                        {msg.aiConfidence && (
                          <Badge className="bg-primary/20 text-primary text-[10px] px-1.5 py-0 ml-auto">
                            {msg.aiConfidence}% confident
                          </Badge>
                        )}
                      </div>
                    )}
                    <p className="text-sm leading-relaxed">{msg.content}</p>
                  </div>
                  <div className={`flex items-center gap-2 mt-1 text-xs text-muted-foreground ${
                    msg.sender === 'customer' ? '' : 'justify-end'
                  }`}>
                    <span>{msg.time}</span>
                    {msg.sender !== 'customer' && (
                      <CheckCheck className="w-3.5 h-3.5 text-primary" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* AI Suggestions */}
          <div className="px-6 py-3 border-t border-white/[0.06] bg-white/[0.02]">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium text-primary">AI Suggestions</span>
            </div>
            <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
              {aiSuggestions.map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => setMessageInput(suggestion)}
                  className="flex-shrink-0 px-3 py-1.5 rounded-full bg-white/[0.04] border border-white/[0.08] text-xs text-muted-foreground hover:bg-white/[0.08] hover:text-white transition-all"
                >
                  {suggestion.substring(0, 50)}...
                </button>
              ))}
            </div>
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-white/[0.06]">
            <div className="flex items-end gap-3">
              <div className="flex-1 relative">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder="Type a message..."
                  className="pr-24 py-6 bg-white/[0.04] border-white/[0.08] rounded-2xl"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                    <Smile className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                    <Mic className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <Button className="h-12 w-12 rounded-full bg-primary hover:bg-primary/90">
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Right Panel - Contact Info */}
        <div className="w-[320px] border-l border-white/[0.06] p-6 overflow-y-auto">
          <div className="text-center mb-6">
            <Avatar className="w-20 h-20 mx-auto mb-4">
              <AvatarFallback className="bg-gradient-to-br from-primary/40 to-accent/40 text-white text-xl">
                {selectedConversation?.avatar}
              </AvatarFallback>
            </Avatar>
            <h3 className="text-lg font-semibold text-white">{selectedConversation?.name}</h3>
            <p className="text-sm text-muted-foreground">Marketing Agency Owner</p>
          </div>

          <div className="space-y-4">
            {/* Lead Score */}
            <div className="glass-card p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">AI Lead Score</span>
                <Badge className="bg-green-500/20 text-green-400 border-0">Hot Lead</Badge>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1 h-2 bg-white/[0.06] rounded-full overflow-hidden">
                  <div className="h-full w-[85%] bg-gradient-to-r from-primary to-accent rounded-full" />
                </div>
                <span className="text-lg font-bold text-white">85</span>
              </div>
            </div>

            {/* Quick Info */}
            <div className="glass-card p-4 space-y-3">
              <h4 className="text-sm font-medium text-white">Contact Info</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Phone</span>
                  <span className="text-white">+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Email</span>
                  <span className="text-white truncate ml-2">sarah@agency.com</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Location</span>
                  <span className="text-white">New York, USA</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Timezone</span>
                  <span className="text-white">EST (UTC-5)</span>
                </div>
              </div>
            </div>

            {/* AI Insights */}
            <div className="glass-card p-4">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-primary" />
                <h4 className="text-sm font-medium text-white">AI Insights</h4>
              </div>
              <div className="space-y-2">
                <div className="flex items-start gap-2 text-xs">
                  <Zap className="w-3.5 h-3.5 text-yellow-400 mt-0.5" />
                  <span className="text-muted-foreground">High buying intent detected in last 3 messages</span>
                </div>
                <div className="flex items-start gap-2 text-xs">
                  <Globe className="w-3.5 h-3.5 text-blue-400 mt-0.5" />
                  <span className="text-muted-foreground">Interested in Pro plan features</span>
                </div>
                <div className="flex items-start gap-2 text-xs">
                  <Clock className="w-3.5 h-3.5 text-green-400 mt-0.5" />
                  <span className="text-muted-foreground">Best time to contact: 10 AM - 2 PM EST</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2">
              <Button className="w-full rounded-xl bg-primary hover:bg-primary/90">
                <Phone className="w-4 h-4 mr-2" />
                Schedule Call
              </Button>
              <Button variant="outline" className="w-full rounded-xl border-white/[0.08]">
                <User className="w-4 h-4 mr-2" />
                View in CRM
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
