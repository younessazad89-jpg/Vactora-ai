'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Upload,
  FileText,
  Globe,
  Youtube,
  Mic,
  Database,
  Book,
  FileSpreadsheet,
  Brain,
  Sparkles,
  CheckCircle2,
  Clock,
  AlertCircle,
  Trash2,
  RefreshCw,
  Plus,
  Zap,
  BarChart3,
  TrendingUp,
  Target
} from 'lucide-react'

const dataSources = [
  {
    id: '1',
    name: 'Product Catalog 2024.pdf',
    type: 'pdf',
    size: '2.4 MB',
    status: 'trained',
    trainedAt: '2 days ago',
    confidence: 98,
  },
  {
    id: '2',
    name: 'https://vactora.ai/pricing',
    type: 'url',
    size: '156 KB',
    status: 'trained',
    trainedAt: '1 day ago',
    confidence: 95,
  },
  {
    id: '3',
    name: 'FAQ Document.docx',
    type: 'document',
    size: '890 KB',
    status: 'training',
    progress: 67,
    trainedAt: 'In progress',
    confidence: null,
  },
  {
    id: '4',
    name: 'Sales Call Recording.mp3',
    type: 'audio',
    size: '45 MB',
    status: 'queued',
    trainedAt: 'Pending',
    confidence: null,
  },
  {
    id: '5',
    name: 'CRM Export - Leads.csv',
    type: 'csv',
    size: '1.2 MB',
    status: 'trained',
    trainedAt: '3 days ago',
    confidence: 92,
  },
]

const typeIcons: Record<string, { icon: React.ReactNode; color: string }> = {
  pdf: { icon: <FileText className="w-5 h-5" />, color: 'text-red-400' },
  url: { icon: <Globe className="w-5 h-5" />, color: 'text-blue-400' },
  document: { icon: <Book className="w-5 h-5" />, color: 'text-purple-400' },
  audio: { icon: <Mic className="w-5 h-5" />, color: 'text-green-400' },
  csv: { icon: <FileSpreadsheet className="w-5 h-5" />, color: 'text-yellow-400' },
  youtube: { icon: <Youtube className="w-5 h-5" />, color: 'text-red-500' },
  notion: { icon: <Database className="w-5 h-5" />, color: 'text-white' },
}

const trainingStats = [
  { label: 'Knowledge Score', value: 94, icon: Brain, color: 'from-primary to-accent', trend: '+5%' },
  { label: 'AI Confidence', value: 96, icon: Target, color: 'from-green-500 to-emerald-500', trend: '+3%' },
  { label: 'Sources Trained', value: 12, icon: Database, color: 'from-purple-500 to-pink-500', trend: '+2' },
  { label: 'Response Accuracy', value: 98, icon: CheckCircle2, color: 'from-yellow-500 to-orange-500', trend: '+1%' },
]

export default function TrainingPage() {
  const [dragActive, setDragActive] = useState(false)

  return (
    <div className="flex h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">AI Training Center</h1>
              <p className="text-muted-foreground">Train your AI agents with your business knowledge</p>
            </div>
            <Button className="rounded-xl bg-primary hover:bg-primary/90">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retrain All Agents
            </Button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {trainingStats.map((stat, i) => (
              <div key={i} className="glass-card-hover p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.color} bg-opacity-20`}>
                    <stat.icon className="w-5 h-5 text-white" />
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-0 text-xs">
                    {stat.trend}
                  </Badge>
                </div>
                <div className="text-3xl font-bold text-white mb-1">
                  {stat.value}{typeof stat.value === 'number' && stat.label !== 'Sources Trained' ? '%' : ''}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Upload Section */}
          <div 
            className={`glass-card p-8 mb-8 border-2 border-dashed transition-all ${
              dragActive ? 'border-primary bg-primary/5' : 'border-white/10'
            }`}
            onDragOver={(e) => { e.preventDefault(); setDragActive(true) }}
            onDragLeave={() => setDragActive(false)}
            onDrop={() => setDragActive(false)}
          >
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-4">
                <Upload className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Upload Training Data</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Drag and drop files here, or click to browse. Supported formats: PDF, DOCX, TXT, CSV, MP3, MP4
              </p>
              <div className="flex items-center justify-center gap-3">
                <Button className="rounded-xl bg-primary hover:bg-primary/90">
                  <Plus className="w-4 h-4 mr-2" />
                  Upload Files
                </Button>
                <Button variant="outline" className="rounded-xl border-white/10">
                  <Globe className="w-4 h-4 mr-2" />
                  Add URL
                </Button>
                <Button variant="outline" className="rounded-xl border-white/10">
                  <Youtube className="w-4 h-4 mr-2" />
                  YouTube Link
                </Button>
              </div>
            </div>
          </div>

          {/* Quick Connect Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="glass-card-hover p-5 cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                  <Database className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Connect Notion</h4>
                  <p className="text-sm text-muted-foreground">Sync your Notion workspace</p>
                </div>
              </div>
            </div>
            <div className="glass-card-hover p-5 cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                  <FileSpreadsheet className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Google Docs</h4>
                  <p className="text-sm text-muted-foreground">Import from Google Drive</p>
                </div>
              </div>
            </div>
            <div className="glass-card-hover p-5 cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center">
                  <Database className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h4 className="font-medium text-white">CRM Data</h4>
                  <p className="text-sm text-muted-foreground">Train from your CRM</p>
                </div>
              </div>
            </div>
          </div>

          {/* Data Sources Table */}
          <div className="glass-card overflow-hidden">
            <div className="p-6 border-b border-white/[0.06]">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">Training Data Sources</h3>
                <div className="flex items-center gap-2">
                  <Input 
                    placeholder="Search sources..." 
                    className="w-64 bg-white/[0.04] border-white/[0.08] rounded-xl"
                  />
                </div>
              </div>
            </div>
            
            <div className="divide-y divide-white/[0.04]">
              {dataSources.map((source) => (
                <div key={source.id} className="p-5 flex items-center gap-4 hover:bg-white/[0.02] transition-colors">
                  <div className={`w-12 h-12 rounded-xl bg-white/[0.04] flex items-center justify-center ${typeIcons[source.type].color}`}>
                    {typeIcons[source.type].icon}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-white truncate">{source.name}</span>
                      <Badge variant="outline" className="text-[10px] border-white/10">
                        {source.type.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{source.size}</span>
                      <span>Trained: {source.trainedAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {source.status === 'trained' && source.confidence && (
                      <div className="text-right">
                        <div className="text-sm font-medium text-white">{source.confidence}%</div>
                        <div className="text-xs text-muted-foreground">Confidence</div>
                      </div>
                    )}
                    
                    {source.status === 'training' && source.progress && (
                      <div className="w-32">
                        <Progress value={source.progress} className="h-2" />
                        <div className="text-xs text-muted-foreground mt-1 text-center">{source.progress}%</div>
                      </div>
                    )}

                    <Badge 
                      className={`${
                        source.status === 'trained' 
                          ? 'bg-green-500/20 text-green-400' 
                          : source.status === 'training'
                          ? 'bg-yellow-500/20 text-yellow-400'
                          : 'bg-blue-500/20 text-blue-400'
                      } border-0`}
                    >
                      {source.status === 'trained' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                      {source.status === 'training' && <RefreshCw className="w-3 h-3 mr-1 animate-spin" />}
                      {source.status === 'queued' && <Clock className="w-3 h-3 mr-1" />}
                      {source.status}
                    </Badge>

                    <Button variant="ghost" size="icon" className="rounded-full text-muted-foreground hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Recommendations */}
          <div className="mt-8 glass-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-semibold text-white">AI Recommendations</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-yellow-500/10">
                    <AlertCircle className="w-4 h-4 text-yellow-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-white mb-1">Add Pricing Data</h4>
                    <p className="text-xs text-muted-foreground">Your AI has limited knowledge about pricing. Upload your pricing sheet for better responses.</p>
                  </div>
                </div>
              </div>
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-blue-500/10">
                    <TrendingUp className="w-4 h-4 text-blue-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-white mb-1">Train on Success Stories</h4>
                    <p className="text-xs text-muted-foreground">Add customer testimonials and case studies to improve conversion handling.</p>
                  </div>
                </div>
              </div>
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-green-500/10">
                    <Zap className="w-4 h-4 text-green-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-white mb-1">Update FAQ Data</h4>
                    <p className="text-xs text-muted-foreground">Your FAQ document is 30 days old. Consider updating it with recent questions.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
