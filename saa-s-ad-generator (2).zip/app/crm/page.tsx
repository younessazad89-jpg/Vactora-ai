'use client'

import { Sidebar } from '@/components/Sidebar'
import { dummyLeads } from '@/lib/data'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import {
  Kanban,
  Plus,
  MoreHorizontal,
  Phone,
  MessageSquare,
  Sparkles,
  Flame,
  ThermometerSun,
  ThermometerSnowflake,
} from 'lucide-react'
import { useState } from 'react'

// Supabase table: leads { id, workspace_id, name, phone, email, interest, status, source, deal_value, ai_score, temperature, notes, created_at }

type PipelineStage = 'new' | 'qualified' | 'interested' | 'booked' | 'closed' | 'lost'

const stages: { key: PipelineStage; label: string; color: string; dotColor: string }[] = [
  { key: 'new', label: 'New Lead', color: 'border-t-primary', dotColor: 'bg-primary' },
  { key: 'qualified', label: 'Qualified', color: 'border-t-chart-2', dotColor: 'bg-chart-2' },
  { key: 'interested', label: 'Interested', color: 'border-t-chart-3', dotColor: 'bg-chart-3' },
  { key: 'booked', label: 'Booked', color: 'border-t-chart-5', dotColor: 'bg-chart-5' },
  { key: 'closed', label: 'Won', color: 'border-t-success', dotColor: 'bg-success' },
  { key: 'lost', label: 'Lost', color: 'border-t-destructive', dotColor: 'bg-destructive' },
]

const dealValues: Record<string, number> = {
  'Starter Plan': 97,
  'Pro Plan': 297,
  'Agency Plan': 997,
  'Enterprise Plan': 2997,
}

const temperatureIcons = {
  hot: { icon: Flame, color: 'text-destructive', label: 'Hot' },
  warm: { icon: ThermometerSun, color: 'text-warning', label: 'Warm' },
  cold: { icon: ThermometerSnowflake, color: 'text-chart-5', label: 'Cold' },
}

function getTemperature(status: string): 'hot' | 'warm' | 'cold' {
  if (status === 'booked' || status === 'closed') return 'hot'
  if (status === 'qualified' || status === 'interested') return 'warm'
  return 'cold'
}

function getAiScore(status: string): number {
  const scores: Record<string, number> = {
    new: 35,
    qualified: 58,
    interested: 72,
    booked: 88,
    closed: 95,
    lost: 12,
  }
  return scores[status] || 50
}

export default function CRMPage() {
  const [leads] = useState(dummyLeads)

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">CRM Pipeline</h1>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 text-xs">
                {leads.length} Deals
              </Badge>
            </div>
            <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4" />
              Add Deal
            </Button>
          </div>
        </header>

        <div className="p-4 lg:p-6 pb-24 lg:pb-6">
          {/* Pipeline Summary */}
          <div className="grid grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
            {stages.map((stage) => {
              const count = leads.filter(l => l.status === stage.key).length
              const value = leads
                .filter(l => l.status === stage.key)
                .reduce((sum, l) => sum + (dealValues[l.interest] || 297), 0)
              return (
                <div key={stage.key} className="glass-card rounded-lg p-3 text-center">
                  <div className={cn("w-2 h-2 rounded-full mx-auto mb-2", stage.dotColor)} />
                  <p className="text-xs text-muted-foreground">{stage.label}</p>
                  <p className="font-bold text-sm">{count}</p>
                  <p className="text-[10px] text-muted-foreground">${value.toLocaleString()}</p>
                </div>
              )
            })}
          </div>

          {/* Kanban Board */}
          <div className="overflow-x-auto">
            <div className="flex gap-4 min-w-[1200px]">
              {stages.map((stage) => {
                const stageLeads = leads.filter(l => l.status === stage.key)
                return (
                  <div key={stage.key} className="flex-1 min-w-[220px]">
                    <div className={cn(
                      "glass-card rounded-xl border-t-2 overflow-hidden",
                      stage.color
                    )}>
                      <div className="flex items-center justify-between p-3 border-b border-border">
                        <div className="flex items-center gap-2">
                          <div className={cn("w-2 h-2 rounded-full", stage.dotColor)} />
                          <span className="text-sm font-medium">{stage.label}</span>
                        </div>
                        <Badge variant="secondary" className="text-[10px] h-5">{stageLeads.length}</Badge>
                      </div>

                      <div className="p-2 space-y-2 min-h-[300px]">
                        {stageLeads.map((lead) => {
                          const temp = getTemperature(lead.status)
                          const TempIcon = temperatureIcons[temp].icon
                          const aiScore = getAiScore(lead.status)
                          const value = dealValues[lead.interest] || 297

                          return (
                            <div
                              key={lead.id}
                              className="p-3 rounded-lg bg-muted/40 border border-border hover:border-primary/30 hover:bg-muted/60 transition-all duration-200 cursor-pointer group"
                            >
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <Avatar className="w-7 h-7">
                                    <AvatarFallback className="bg-gradient-to-br from-primary/20 to-accent/20 text-[10px] font-medium">
                                      {lead.name.split(' ').map(n => n[0]).join('')}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <p className="text-xs font-medium leading-tight">{lead.name}</p>
                                    <p className="text-[10px] text-muted-foreground">{lead.source}</p>
                                  </div>
                                </div>
                                <TempIcon className={cn("w-3.5 h-3.5", temperatureIcons[temp].color)} />
                              </div>

                              <p className="text-[10px] text-muted-foreground mb-2 line-clamp-2">{lead.lastMessage}</p>

                              <div className="flex items-center justify-between">
                                <span className="text-xs font-semibold text-success">${value}/mo</span>
                                <div className="flex items-center gap-1">
                                  <Sparkles className="w-3 h-3 text-primary" />
                                  <span className="text-[10px] text-primary font-medium">{aiScore}%</span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1 mt-2 pt-2 border-t border-border opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button variant="ghost" size="icon" className="h-6 w-6">
                                  <Phone className="w-3 h-3" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6">
                                  <MessageSquare className="w-3 h-3" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6 ml-auto">
                                  <MoreHorizontal className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          )
                        })}

                        {stageLeads.length === 0 && (
                          <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                            <Kanban className="w-8 h-8 mb-2 opacity-30" />
                            <p className="text-xs">No deals</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
