'use client'

import { Sidebar } from '@/components/Sidebar'
import { StatCard } from '@/components/StatCard'
import { LeadsTable } from '@/components/LeadsTable'
import { RecentConversations } from '@/components/RecentConversations'
import { ActivityFeed } from '@/components/ActivityFeed'
import { Notifications } from '@/components/Notifications'
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import { RevenuePredictorWidget } from '@/components/RevenuePredictorWidget'
import { ThemeToggle } from '@/components/ThemeToggle'
import { dummyStats } from '@/lib/data'
import { Button } from '@/components/ui/button'
import { Plus, Search } from 'lucide-react'
import { Input } from '@/components/ui/input'

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <main className="flex-1 lg:ml-0">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">Dashboard</h1>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden md:flex relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Search..." 
                  className="w-64 pl-9 bg-muted/50 border-transparent focus:border-primary"
                />
              </div>
              <LanguageSwitcher />
              <ThemeToggle />
              <Notifications />
              <Button size="sm" className="hidden sm:flex gap-2 bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4" />
                New Lead
              </Button>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="p-4 lg:p-6 space-y-6 pb-24 lg:pb-6">
          {/* Welcome message */}
          <div className="glass-card rounded-xl p-6 bg-gradient-to-r from-primary/10 via-accent/5 to-transparent border-primary/20">
            <h2 className="text-2xl font-bold mb-1">Welcome back!</h2>
            <p className="text-muted-foreground">Here&apos;s what&apos;s happening with your AI sales agents today.</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            <StatCard
              title="Total Leads"
              value={dummyStats.totalLeads.toLocaleString()}
              icon="leads"
              change={18.2}
              changeLabel="vs last month"
            />
            <StatCard
              title="Active Chats"
              value={dummyStats.activeConversations}
              icon="conversations"
              change={12.5}
              changeLabel="vs last month"
            />
            <StatCard
              title="Booked Calls"
              value={dummyStats.bookedCalls}
              icon="bookings"
              change={24.3}
              changeLabel="vs last month"
            />
            <StatCard
              title="Revenue"
              value={`$${(dummyStats.monthlyRevenue / 1000).toFixed(1)}k`}
              icon="revenue"
              change={15.8}
              changeLabel="vs last month"
            />
            <StatCard
              title="Conversion"
              value={`${dummyStats.conversionRate}%`}
              icon="conversion"
              change={8.4}
              changeLabel="vs last month"
            />
            <StatCard
              title="Response Time"
              value={dummyStats.avgResponseTime}
              icon="response"
              change={-15}
              changeLabel="faster"
            />
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Leads Table - Takes 2 columns */}
            <div className="xl:col-span-2">
              <LeadsTable limit={6} />
            </div>
            
            {/* Activity Feed - Takes 1 column */}
            <div className="xl:col-span-1">
              <ActivityFeed />
            </div>
          </div>

          {/* Secondary Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <RecentConversations />
            <RevenuePredictorWidget />
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Quick Actions</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" className="h-auto py-4 flex-col gap-2 hover:bg-primary/10 hover:border-primary/30">
                  <Plus className="w-5 h-5 text-primary" />
                  <span className="text-xs">Add Lead</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2 hover:bg-accent/10 hover:border-accent/30">
                  <Search className="w-5 h-5 text-accent" />
                  <span className="text-xs">Search CRM</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
