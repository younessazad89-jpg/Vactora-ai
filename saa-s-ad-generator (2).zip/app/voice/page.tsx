'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { 
  Mic, 
  Phone, 
  PhoneCall,
  PhoneOff,
  Play,
  Pause,
  Square,
  Upload,
  Volume2,
  VolumeX,
  AudioLines,
  Clock,
  Users,
  CheckCircle2,
  AlertCircle,
  Settings,
  Sparkles,
  Globe,
  Bot,
  Headphones,
  Radio,
  MessageSquare,
  Calendar,
  TrendingUp
} from 'lucide-react'

const voiceProfiles = [
  { id: 1, name: 'Sarah (Sales)', voice: 'Professional Female', language: 'English', status: 'Active', calls: 234, successRate: 87 },
  { id: 2, name: 'James (Support)', voice: 'Friendly Male', language: 'English', status: 'Active', calls: 156, successRate: 92 },
  { id: 3, name: 'Sofia (Spanish)', voice: 'Warm Female', language: 'Spanish', status: 'Active', calls: 89, successRate: 85 },
  { id: 4, name: 'Owner Clone', voice: 'Custom Clone', language: 'English', status: 'Training', calls: 0, successRate: 0 },
]

const recentCalls = [
  { id: 1, lead: 'John Smith', phone: '+1 555-0123', duration: '4:32', outcome: 'Booked', agent: 'Sarah', timestamp: '10 min ago' },
  { id: 2, lead: 'Emma Wilson', phone: '+1 555-0456', duration: '2:15', outcome: 'Follow-up', agent: 'James', timestamp: '25 min ago' },
  { id: 3, lead: 'Michael Brown', phone: '+1 555-0789', duration: '6:48', outcome: 'Converted', agent: 'Sarah', timestamp: '1 hour ago' },
  { id: 4, lead: 'Lisa Garcia', phone: '+1 555-0321', duration: '1:23', outcome: 'No Answer', agent: 'Sofia', timestamp: '2 hours ago' },
]

const callStats = {
  totalCalls: 1247,
  avgDuration: '3:42',
  successRate: 78,
  appointmentsBooked: 234,
}

export default function VoicePage() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [isRecording, setIsRecording] = useState(false)
  const [selectedProfile, setSelectedProfile] = useState<number | null>(null)
  const [volume, setVolume] = useState([75])

  return (
    <div className="flex min-h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">AI Voice System</h1>
            <p className="text-gray-400">Voice cloning, AI calls, and voice automation</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 px-4 py-2">
              <Radio className="w-4 h-4 mr-2 animate-pulse" />
              System Active
            </Badge>
            <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
              <Phone className="w-4 h-4 mr-2" />
              Start AI Call
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                <PhoneCall className="w-5 h-5 text-indigo-400" />
              </div>
              <span className="text-gray-400">Total Calls</span>
            </div>
            <p className="text-3xl font-bold text-white">{callStats.totalCalls.toLocaleString()}</p>
            <p className="text-sm text-emerald-400 mt-1">+12% this week</p>
          </div>
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                <Clock className="w-5 h-5 text-cyan-400" />
              </div>
              <span className="text-gray-400">Avg Duration</span>
            </div>
            <p className="text-3xl font-bold text-white">{callStats.avgDuration}</p>
            <p className="text-sm text-gray-500 mt-1">minutes</p>
          </div>
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
              </div>
              <span className="text-gray-400">Success Rate</span>
            </div>
            <p className="text-3xl font-bold text-white">{callStats.successRate}%</p>
            <p className="text-sm text-emerald-400 mt-1">+5% improvement</p>
          </div>
          <div className="glass-card rounded-[18px] p-6 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-purple-400" />
              </div>
              <span className="text-gray-400">Appointments</span>
            </div>
            <p className="text-3xl font-bold text-white">{callStats.appointmentsBooked}</p>
            <p className="text-sm text-gray-500 mt-1">booked this month</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="glass-card border-white/10 p-1">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-white/10">
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="voices" className="data-[state=active]:bg-white/10">
              Voice Profiles
            </TabsTrigger>
            <TabsTrigger value="clone" className="data-[state=active]:bg-white/10">
              <Sparkles className="w-4 h-4 mr-2" />
              Voice Cloning
            </TabsTrigger>
            <TabsTrigger value="receptionist" className="data-[state=active]:bg-white/10">
              AI Receptionist
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              {/* Live Calls */}
              <div className="glass-card rounded-[18px] p-6 border border-white/5">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-white">Live Calls</h3>
                  <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                    3 Active
                  </Badge>
                </div>
                <div className="space-y-4">
                  {[
                    { lead: 'David Chen', duration: '2:34', status: 'Talking' },
                    { lead: 'Anna Martinez', duration: '0:45', status: 'Ringing' },
                    { lead: 'Robert Kim', duration: '5:12', status: 'Closing' },
                  ].map((call, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${call.status === 'Talking' ? 'bg-emerald-400' : call.status === 'Ringing' ? 'bg-amber-400 animate-pulse' : 'bg-indigo-400'}`} />
                        <div>
                          <p className="text-white font-medium">{call.lead}</p>
                          <p className="text-sm text-gray-400">{call.status}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-gray-400 font-mono">{call.duration}</span>
                        <Button size="icon" variant="ghost" className="hover:bg-white/5">
                          <Headphones className="w-4 h-4 text-gray-400" />
                        </Button>
                        <Button size="icon" variant="ghost" className="hover:bg-red-500/20">
                          <PhoneOff className="w-4 h-4 text-red-400" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Calls */}
              <div className="glass-card rounded-[18px] p-6 border border-white/5">
                <h3 className="text-lg font-semibold text-white mb-6">Recent Calls</h3>
                <div className="space-y-3">
                  {recentCalls.map((call) => (
                    <div key={call.id} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                          <Phone className="w-5 h-5 text-gray-400" />
                        </div>
                        <div>
                          <p className="text-white font-medium">{call.lead}</p>
                          <p className="text-sm text-gray-500">{call.phone}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-gray-400">{call.duration}</span>
                        <Badge variant="outline" className={
                          call.outcome === 'Booked' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                          call.outcome === 'Converted' ? 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30' :
                          call.outcome === 'Follow-up' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                          'bg-gray-500/20 text-gray-400 border-gray-500/30'
                        }>
                          {call.outcome}
                        </Badge>
                        <span className="text-sm text-gray-500">{call.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="voices" className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              {voiceProfiles.map((profile) => (
                <div 
                  key={profile.id}
                  className={`glass-card rounded-[18px] p-6 border transition-all duration-300 cursor-pointer ${
                    selectedProfile === profile.id ? 'border-indigo-500 ring-2 ring-indigo-500/20' : 'border-white/5 hover:border-indigo-500/30'
                  }`}
                  onClick={() => setSelectedProfile(profile.id)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-indigo-600/20 to-purple-600/20 flex items-center justify-center border border-white/10">
                        <Mic className="w-7 h-7 text-indigo-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">{profile.name}</h3>
                        <p className="text-sm text-gray-400">{profile.voice}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className={
                      profile.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                      'bg-amber-500/20 text-amber-400 border-amber-500/30'
                    }>
                      {profile.status}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-2 mb-4">
                    <Globe className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-400">{profile.language}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-white/5 rounded-xl p-3 text-center">
                      <p className="text-2xl font-bold text-white">{profile.calls}</p>
                      <p className="text-xs text-gray-400">Calls Made</p>
                    </div>
                    <div className="bg-white/5 rounded-xl p-3 text-center">
                      <p className="text-2xl font-bold text-emerald-400">{profile.successRate}%</p>
                      <p className="text-xs text-gray-400">Success Rate</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" className="flex-1 border-white/10">
                      <Play className="w-4 h-4 mr-2" />
                      Preview
                    </Button>
                    <Button size="sm" variant="outline" className="border-white/10">
                      <Settings className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="clone" className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              {/* Voice Cloning Interface */}
              <div className="glass-card rounded-[18px] p-6 border border-white/5">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center ai-glow">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Clone Your Voice</h3>
                    <p className="text-sm text-gray-400">Create a custom AI voice from recordings</p>
                  </div>
                </div>

                <div className="space-y-6">
                  {/* Recording Interface */}
                  <div className="bg-white/5 rounded-xl p-6 border border-white/10">
                    <div className="flex flex-col items-center">
                      <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-4 transition-all duration-300 ${
                        isRecording ? 'bg-red-500/20 border-2 border-red-500 animate-pulse' : 'bg-white/10 border-2 border-white/20'
                      }`}>
                        <Mic className={`w-10 h-10 ${isRecording ? 'text-red-400' : 'text-gray-400'}`} />
                      </div>
                      
                      {isRecording && (
                        <div className="flex items-center gap-2 mb-4">
                          <div className="flex gap-1">
                            {[...Array(5)].map((_, i) => (
                              <div 
                                key={i} 
                                className="w-1 bg-red-400 rounded-full animate-pulse"
                                style={{ 
                                  height: `${Math.random() * 20 + 10}px`,
                                  animationDelay: `${i * 0.1}s`
                                }}
                              />
                            ))}
                          </div>
                          <span className="text-red-400 font-mono">00:42</span>
                        </div>
                      )}

                      <Button 
                        size="lg"
                        className={isRecording ? 'bg-red-600 hover:bg-red-700' : 'bg-gradient-to-r from-indigo-600 to-purple-600'}
                        onClick={() => setIsRecording(!isRecording)}
                      >
                        {isRecording ? (
                          <>
                            <Square className="w-4 h-4 mr-2" />
                            Stop Recording
                          </>
                        ) : (
                          <>
                            <Mic className="w-4 h-4 mr-2" />
                            Start Recording
                          </>
                        )}
                      </Button>
                    </div>
                  </div>

                  {/* Upload Option */}
                  <div className="text-center">
                    <span className="text-gray-500">or</span>
                  </div>

                  <div className="border-2 border-dashed border-white/10 rounded-xl p-8 text-center hover:border-indigo-500/50 transition-colors cursor-pointer">
                    <Upload className="w-10 h-10 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-400 mb-2">Upload voice samples</p>
                    <p className="text-sm text-gray-500">MP3, WAV, M4A (min 30 seconds)</p>
                  </div>

                  {/* Voice Settings */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Voice Name</label>
                      <Input placeholder="My Custom Voice" className="bg-white/5 border-white/10" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Volume</label>
                      <div className="flex items-center gap-4">
                        <VolumeX className="w-4 h-4 text-gray-400" />
                        <Slider value={volume} onValueChange={setVolume} max={100} className="flex-1" />
                        <Volume2 className="w-4 h-4 text-gray-400" />
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-indigo-600 to-purple-600">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Voice Clone
                  </Button>
                </div>
              </div>

              {/* Training Progress */}
              <div className="glass-card rounded-[18px] p-6 border border-white/5">
                <h3 className="text-lg font-semibold text-white mb-6">Voice Training Progress</h3>
                
                <div className="space-y-6">
                  <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl">
                    <div className="flex items-center gap-3 mb-3">
                      <AlertCircle className="w-5 h-5 text-amber-400" />
                      <span className="text-amber-400 font-medium">Owner Clone Training</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Progress</span>
                        <span className="text-white">67%</span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full w-[67%] bg-gradient-to-r from-amber-500 to-orange-500 rounded-full" />
                      </div>
                      <p className="text-xs text-gray-500">Estimated: 15 minutes remaining</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium text-gray-300">Training Samples</h4>
                    {[
                      { name: 'intro_sample.mp3', duration: '1:23', status: 'Processed' },
                      { name: 'greeting.wav', duration: '0:45', status: 'Processed' },
                      { name: 'sales_pitch.mp3', duration: '2:15', status: 'Processing' },
                    ].map((sample, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-white/5 rounded-xl">
                        <div className="flex items-center gap-3">
                          <AudioLines className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-sm text-white">{sample.name}</p>
                            <p className="text-xs text-gray-500">{sample.duration}</p>
                          </div>
                        </div>
                        <Badge variant="outline" className={
                          sample.status === 'Processed' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                          'bg-amber-500/20 text-amber-400 border-amber-500/30'
                        }>
                          {sample.status}
                        </Badge>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 bg-white/5 rounded-xl">
                    <h4 className="text-sm font-medium text-gray-300 mb-3">Tips for Better Voice Cloning</h4>
                    <ul className="space-y-2 text-sm text-gray-400">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                        Record in a quiet environment
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                        Speak clearly at a consistent pace
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                        Provide at least 3 minutes of audio
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                        Include varied sentence types
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="receptionist" className="space-y-6">
            <div className="grid grid-cols-3 gap-6">
              {/* Receptionist Config */}
              <div className="col-span-2 glass-card rounded-[18px] p-6 border border-white/5">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-600/20 to-cyan-600/20 flex items-center justify-center">
                      <Bot className="w-6 h-6 text-emerald-400" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">AI Receptionist</h3>
                      <p className="text-sm text-gray-400">24/7 automated phone answering</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-gray-400">Active</span>
                    <Switch defaultChecked />
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Business Name</label>
                      <Input defaultValue="Acme Dental Clinic" className="bg-white/5 border-white/10" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Phone Number</label>
                      <Input defaultValue="+1 (555) 123-4567" className="bg-white/5 border-white/10" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Greeting Message</label>
                    <textarea 
                      className="w-full h-24 bg-white/5 border border-white/10 rounded-xl p-4 text-white text-sm"
                      defaultValue="Thank you for calling Acme Dental Clinic. I'm your AI assistant and I'm here to help you with appointments, questions, or connecting you with our team. How can I assist you today?"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Voice Profile</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white">
                      <option>Sarah (Sales) - Professional Female</option>
                      <option>James (Support) - Friendly Male</option>
                      <option>Owner Clone - Custom</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                      <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-indigo-400" />
                        <span className="text-gray-300">Book Appointments</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                      <div className="flex items-center gap-3">
                        <MessageSquare className="w-5 h-5 text-cyan-400" />
                        <span className="text-gray-300">Take Messages</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                      <div className="flex items-center gap-3">
                        <Users className="w-5 h-5 text-emerald-400" />
                        <span className="text-gray-300">Transfer to Human</span>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                      <div className="flex items-center gap-3">
                        <Globe className="w-5 h-5 text-purple-400" />
                        <span className="text-gray-300">Multi-language</span>
                      </div>
                      <Switch />
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-emerald-600 to-cyan-600">
                    Save Receptionist Settings
                  </Button>
                </div>
              </div>

              {/* Stats */}
              <div className="space-y-6">
                <div className="glass-card rounded-[18px] p-6 border border-white/5">
                  <h3 className="text-lg font-semibold text-white mb-4">Today&apos;s Stats</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Calls Answered</span>
                      <span className="text-xl font-bold text-white">47</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Appointments Booked</span>
                      <span className="text-xl font-bold text-emerald-400">12</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Messages Taken</span>
                      <span className="text-xl font-bold text-cyan-400">23</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Transferred</span>
                      <span className="text-xl font-bold text-amber-400">8</span>
                    </div>
                  </div>
                </div>

                <div className="glass-card rounded-[18px] p-6 border border-white/5">
                  <h3 className="text-lg font-semibold text-white mb-4">Business Hours</h3>
                  <div className="space-y-3 text-sm">
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day) => (
                      <div key={day} className="flex items-center justify-between">
                        <span className="text-gray-400">{day}</span>
                        <span className="text-white">9:00 AM - 6:00 PM</span>
                      </div>
                    ))}
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Sat-Sun</span>
                      <span className="text-gray-500">AI Only</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
