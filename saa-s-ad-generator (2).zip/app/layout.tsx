import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from 'sonner'
import { AICopilot } from '@/components/AICopilot'
import { CommandPalette } from '@/components/CommandPalette'
import './globals.css'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter'
})

export const metadata: Metadata = {
  title: 'Vactora AI | AI Sales Automation & WhatsApp CRM',
  description: 'Automate your sales with AI-powered WhatsApp automation. Generate leads, manage conversations, book calls, and close deals on autopilot.',
  generator: 'v0.app',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body className={`${inter.variable} font-sans antialiased`}>
        {children}
        <AICopilot />
        <CommandPalette />
        <Toaster position="top-right" theme="dark" richColors />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
