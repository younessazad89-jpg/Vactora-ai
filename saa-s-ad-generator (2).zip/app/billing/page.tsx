'use client'

import { Sidebar } from '@/components/Sidebar'
import { pricingPlans } from '@/lib/data'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import {
  CreditCard,
  Check,
  Sparkles,
  DollarSign,
  TrendingUp,
  Users,
  Link2,
  Copy,
  ArrowUpRight,
  Zap,
  Crown,
  Gift,
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'

// Supabase tables:
// subscriptions { id, workspace_id, stripe_customer_id, stripe_subscription_id, plan, status, current_period_end }
// affiliates { id, user_id, referral_code, commission_rate, total_earned, total_referrals, tier }

const affiliateTiers = [
  {
    name: 'Referral Partner',
    commission: '20% lifetime',
    desc: 'Share your link and earn recurring commissions on every referral.',
    example: '$997 client = $199/mo for you',
    color: 'from-primary/20 to-primary/5 border-primary/20',
  },
  {
    name: 'Agency Partner',
    commission: '30% + White Label',
    desc: 'White-label Vactora for your agency clients with premium margins.',
    example: '10 clients = $2,991/mo passive',
    color: 'from-accent/20 to-accent/5 border-accent/20',
  },
  {
    name: 'Reseller',
    commission: '50% month 1, then 20%',
    desc: 'High upfront earnings plus ongoing recurring revenue.',
    example: '5 clients month 1 = $2,492 + $997/mo',
    color: 'from-success/20 to-success/5 border-success/20',
  },
]

export default function BillingPage() {
  const [referralLink] = useState('https://vactora.ai/ref/abc123')

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink)
    toast.success('Referral link copied!')
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">Billing</h1>
            </div>
          </div>
        </header>

        <div className="p-4 lg:p-6 space-y-6 pb-24 lg:pb-6">
          <Tabs defaultValue="plans" className="space-y-6">
            <TabsList className="bg-muted/50 border border-border">
              <TabsTrigger value="plans" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <CreditCard className="w-4 h-4 mr-2" />
                Plans
              </TabsTrigger>
              <TabsTrigger value="usage" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <Zap className="w-4 h-4 mr-2" />
                Usage
              </TabsTrigger>
              <TabsTrigger value="affiliate" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <Gift className="w-4 h-4 mr-2" />
                Vactora Partners
              </TabsTrigger>
            </TabsList>

            {/* Plans Tab */}
            <TabsContent value="plans" className="space-y-6">
              {/* ROI Banner */}
              <div className="glass-card rounded-xl p-6 bg-gradient-to-r from-success/10 via-success/5 to-transparent border-success/20">
                <div className="flex items-center gap-3 mb-2">
                  <TrendingUp className="w-5 h-5 text-success" />
                  <h3 className="font-semibold">Your AI ROI This Month</h3>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Revenue Generated</p>
                    <p className="text-2xl font-bold text-success">$47,500</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">AI Savings</p>
                    <p className="text-2xl font-bold text-success">$12,300</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Hours Saved</p>
                    <p className="text-2xl font-bold">340</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">ROI</p>
                    <p className="text-2xl font-bold text-success">4,750%</p>
                  </div>
                </div>
              </div>

              {/* Pricing Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {pricingPlans.map((plan) => (
                  <div
                    key={plan.id}
                    className={cn(
                      "glass-card rounded-xl p-6 relative transition-all duration-300 hover:scale-[1.02]",
                      plan.popular && "ring-2 ring-primary glow-primary"
                    )}
                  >
                    {plan.popular && (
                      <Badge className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[10px]">
                        Most Popular
                      </Badge>
                    )}
                    <div className="mb-6">
                      <h3 className="font-bold text-lg mb-1">{plan.name}</h3>
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-bold">${plan.price}</span>
                        <span className="text-sm text-muted-foreground">/mo</span>
                      </div>
                    </div>
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <Check className="w-4 h-4 text-success shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      className={cn(
                        "w-full",
                        plan.popular
                          ? "bg-primary hover:bg-primary/90"
                          : "bg-muted hover:bg-muted/80 text-foreground"
                      )}
                    >
                      {plan.id === 'pro' ? 'Current Plan' : 'Upgrade'}
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Usage Tab */}
            <TabsContent value="usage" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass-card rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-sm">AI Messages</h3>
                    <Badge variant="outline" className="text-[10px]">Pro Plan</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">7,842 / 10,000 used</span>
                      <span className="font-medium">78%</span>
                    </div>
                    <Progress value={78} className="h-2" />
                    <p className="text-xs text-muted-foreground">Resets in 14 days</p>
                  </div>
                </div>
                <div className="glass-card rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-sm">WhatsApp Numbers</h3>
                    <Badge variant="outline" className="text-[10px]">Pro Plan</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">2 / 3 connected</span>
                      <span className="font-medium">67%</span>
                    </div>
                    <Progress value={67} className="h-2" />
                    <p className="text-xs text-muted-foreground">Upgrade to Agency for unlimited</p>
                  </div>
                </div>
                <div className="glass-card rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-sm">AI Agent Responses</h3>
                    <Badge variant="outline" className="text-success/80 border-success/30 text-[10px]">Unlimited</Badge>
                  </div>
                  <div className="space-y-3">
                    <p className="text-2xl font-bold">24,682</p>
                    <p className="text-xs text-muted-foreground">Total responses this billing period</p>
                  </div>
                </div>
                <div className="glass-card rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-sm">API Calls</h3>
                    <Badge variant="outline" className="text-[10px]">Pro Plan</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">4,521 / 50,000</span>
                      <span className="font-medium">9%</span>
                    </div>
                    <Progress value={9} className="h-2" />
                    <p className="text-xs text-muted-foreground">Plenty of capacity remaining</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Affiliate Tab */}
            <TabsContent value="affiliate" className="space-y-6">
              {/* Affiliate Hero */}
              <div className="glass-card rounded-xl p-6 bg-gradient-to-r from-primary/10 via-accent/5 to-transparent border-primary/20">
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-6 h-6 text-primary" />
                  <h2 className="text-xl font-bold gradient-text">Vactora Partners Program</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-4 max-w-xl">
                  Refer agencies and earn up to 50% commissions. Build a passive income stream by sharing the future of AI sales automation.
                </p>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-muted/50 rounded-lg px-4 py-2.5 text-sm font-mono text-muted-foreground border border-border">
                    {referralLink}
                  </div>
                  <Button onClick={copyLink} className="gap-2 bg-primary hover:bg-primary/90 shrink-0">
                    <Copy className="w-4 h-4" />
                    Copy Link
                  </Button>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="glass-card rounded-xl p-4 text-center">
                  <Users className="w-5 h-5 text-primary mx-auto mb-2" />
                  <p className="text-2xl font-bold">12</p>
                  <p className="text-xs text-muted-foreground">Total Referrals</p>
                </div>
                <div className="glass-card rounded-xl p-4 text-center">
                  <DollarSign className="w-5 h-5 text-success mx-auto mb-2" />
                  <p className="text-2xl font-bold text-success">$3,564</p>
                  <p className="text-xs text-muted-foreground">Total Earned</p>
                </div>
                <div className="glass-card rounded-xl p-4 text-center">
                  <TrendingUp className="w-5 h-5 text-accent mx-auto mb-2" />
                  <p className="text-2xl font-bold">$891</p>
                  <p className="text-xs text-muted-foreground">This Month</p>
                </div>
                <div className="glass-card rounded-xl p-4 text-center">
                  <Link2 className="w-5 h-5 text-chart-3 mx-auto mb-2" />
                  <p className="text-2xl font-bold">347</p>
                  <p className="text-xs text-muted-foreground">Link Clicks</p>
                </div>
              </div>

              {/* Tiers */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {affiliateTiers.map((tier, i) => (
                  <div key={i} className={cn("glass-card rounded-xl p-6 bg-gradient-to-br border", tier.color)}>
                    <h3 className="font-bold mb-1">{tier.name}</h3>
                    <Badge variant="outline" className="mb-3 text-[10px]">{tier.commission}</Badge>
                    <p className="text-sm text-muted-foreground mb-3">{tier.desc}</p>
                    <div className="p-2 rounded-lg bg-muted/30 border border-border">
                      <p className="text-xs font-medium text-success">{tier.example}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
