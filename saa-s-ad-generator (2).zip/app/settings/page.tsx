'use client'

import { Sidebar } from '@/components/Sidebar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { ConnectionStatus } from '@/components/ConnectionStatus'

export default function SettingsPage() {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b border-border">
          <div className="flex items-center justify-between px-6 h-14">
            <h1 className="text-lg font-semibold text-foreground">Settings</h1>
          </div>
        </header>

        {/* Content */}
        <div className="p-6 max-w-3xl space-y-6">
          {/* WhatsApp Connection */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground">WhatsApp Connection</CardTitle>
              <CardDescription>Manage your WhatsApp Business API connection</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-foreground">Connection Status</p>
                  <p className="text-sm text-muted-foreground">Your WhatsApp Business account</p>
                </div>
                <ConnectionStatus connected={true} />
              </div>
              <Separator className="bg-border" />
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-foreground">Phone Number</Label>
                <Input 
                  id="phone" 
                  value="+1 555 123 4567" 
                  disabled 
                  className="bg-muted border-border"
                />
              </div>
              <Button variant="outline" className="border-border text-foreground hover:bg-muted">
                Reconnect WhatsApp
              </Button>
            </CardContent>
          </Card>

          {/* AI Agent Settings */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground">AI Agent Settings</CardTitle>
              <CardDescription>Configure how your AI sales agent behaves</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium text-foreground">Auto-reply</p>
                  <p className="text-sm text-muted-foreground">Automatically respond to incoming messages</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator className="bg-border" />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium text-foreground">Lead Qualification</p>
                  <p className="text-sm text-muted-foreground">Automatically qualify leads based on conversation</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator className="bg-border" />
              <div className="space-y-2">
                <Label htmlFor="greeting" className="text-foreground">Greeting Message</Label>
                <Textarea 
                  id="greeting"
                  defaultValue="Hi! Thanks for reaching out. I'm here to help you find the perfect solution. What are you looking for today?"
                  className="bg-card border-border min-h-[100px]"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="instructions" className="text-foreground">AI Instructions</Label>
                <Textarea 
                  id="instructions"
                  placeholder="Add specific instructions for your AI agent..."
                  defaultValue="Be friendly and professional. Focus on understanding customer needs before pitching products. Always try to schedule a call for high-value leads."
                  className="bg-card border-border min-h-[100px]"
                />
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground">Notifications</CardTitle>
              <CardDescription>Choose what you want to be notified about</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium text-foreground">New Leads</p>
                  <p className="text-sm text-muted-foreground">Get notified when a new lead is captured</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator className="bg-border" />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium text-foreground">Qualified Leads</p>
                  <p className="text-sm text-muted-foreground">Get notified when a lead is qualified</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator className="bg-border" />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-medium text-foreground">Daily Summary</p>
                  <p className="text-sm text-muted-foreground">Receive a daily summary of activity</p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button>Save Changes</Button>
          </div>
        </div>
      </main>
    </div>
  )
}
