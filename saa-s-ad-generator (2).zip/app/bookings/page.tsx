'use client'

import { Sidebar } from '@/components/Sidebar'
import { dummyBookings } from '@/lib/data'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import {
  Calendar as CalendarIcon,
  Plus,
  Clock,
  Video,
  Phone,
  Users,
  Headphones,
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
} from 'lucide-react'
import { useState } from 'react'

// Supabase table: bookings { id, workspace_id, lead_id, type, date, time, status, notes, google_calendar_id, zoom_link, created_at }

const typeConfig = {
  demo: { label: 'Demo', icon: Video, color: 'bg-primary/10 text-primary border-primary/20' },
  sales_call: { label: 'Sales Call', icon: Phone, color: 'bg-chart-2/10 text-chart-2 border-chart-2/20' },
  onboarding: { label: 'Onboarding', icon: Users, color: 'bg-success/10 text-success border-success/20' },
  support: { label: 'Support', icon: Headphones, color: 'bg-chart-3/10 text-chart-3 border-chart-3/20' },
}

const statusConfig = {
  upcoming: 'bg-primary/10 text-primary border-primary/30',
  completed: 'bg-success/10 text-success border-success/30',
  cancelled: 'bg-destructive/10 text-destructive border-destructive/30',
}

const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

function generateCalendarDays() {
  const days = []
  for (let i = 1; i <= 31; i++) {
    const hasEvent = [15, 16, 17, 18, 22, 25].includes(i)
    const eventCount = i === 16 ? 2 : i === 17 ? 2 : hasEvent ? 1 : 0
    days.push({ day: i, hasEvent, eventCount, isToday: i === 16 })
  }
  return days
}

export default function BookingsPage() {
  const [selectedDate, setSelectedDate] = useState('2024-01-16')
  const calendarDays = generateCalendarDays()
  const todayBookings = dummyBookings.filter(b => b.date === selectedDate || selectedDate === '2024-01-16')

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">Bookings</h1>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 text-xs">
                {dummyBookings.filter(b => b.status === 'upcoming').length} Upcoming
              </Badge>
            </div>
            <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4" />
              New Booking
            </Button>
          </div>
        </header>

        <div className="p-4 lg:p-6 pb-24 lg:pb-6">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Calendar */}
            <div className="xl:col-span-2">
              <div className="glass-card rounded-xl overflow-hidden">
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <h3 className="font-semibold">January 2024</h3>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-xs">Today</Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="p-4">
                  {/* Week days header */}
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {weekDays.map(day => (
                      <div key={day} className="text-center text-xs text-muted-foreground font-medium py-2">
                        {day}
                      </div>
                    ))}
                  </div>

                  {/* Calendar grid */}
                  <div className="grid grid-cols-7 gap-1">
                    {/* Empty cells for offset (January 2024 starts on Monday) */}
                    {calendarDays.map(({ day, hasEvent, eventCount, isToday }) => (
                      <button
                        key={day}
                        onClick={() => setSelectedDate(`2024-01-${day.toString().padStart(2, '0')}`)}
                        className={cn(
                          "relative aspect-square flex flex-col items-center justify-center rounded-lg text-sm transition-all",
                          isToday && "bg-primary/20 border border-primary/40 font-bold text-primary",
                          !isToday && hasEvent && "bg-muted/50 hover:bg-muted",
                          !isToday && !hasEvent && "hover:bg-muted/30",
                          selectedDate === `2024-01-${day.toString().padStart(2, '0')}` && !isToday && "ring-1 ring-primary/50"
                        )}
                      >
                        {day}
                        {hasEvent && (
                          <div className="flex gap-0.5 mt-0.5">
                            {Array.from({ length: Math.min(eventCount, 3) }).map((_, i) => (
                              <div key={i} className="w-1 h-1 rounded-full bg-primary" />
                            ))}
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Upcoming Bookings */}
            <div className="xl:col-span-1">
              <div className="glass-card rounded-xl">
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4 text-primary" />
                    <h3 className="font-semibold text-sm">Upcoming</h3>
                  </div>
                </div>
                <div className="divide-y divide-border">
                  {dummyBookings.filter(b => b.status === 'upcoming').map((booking) => {
                    const config = typeConfig[booking.type]
                    const TypeIcon = config.icon
                    return (
                      <div key={booking.id} className="p-4 hover:bg-muted/20 transition-colors">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="bg-gradient-to-br from-primary/20 to-accent/20 text-[10px] font-medium">
                                {booking.leadName.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-sm font-medium">{booking.leadName}</p>
                              <p className="text-[10px] text-muted-foreground">{booking.leadPhone}</p>
                            </div>
                          </div>
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <MoreHorizontal className="w-3.5 h-3.5" />
                          </Button>
                        </div>

                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className={cn("text-[10px] gap-1", config.color)}>
                            <TypeIcon className="w-3 h-3" />
                            {config.label}
                          </Badge>
                          <Badge variant="outline" className={cn("text-[10px]", statusConfig[booking.status])}>
                            {booking.status}
                          </Badge>
                        </div>

                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <CalendarIcon className="w-3 h-3" />
                            {new Date(booking.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {booking.time}
                          </div>
                        </div>

                        {booking.notes && (
                          <p className="text-[10px] text-muted-foreground mt-2 italic">{booking.notes}</p>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
