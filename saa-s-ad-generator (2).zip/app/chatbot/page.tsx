'use client'

import { useState, useRef, useEffect } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Bot,
  MessageSquare,
  Sparkles,
  Settings,
  Palette,
  Code,
  Eye,
  Copy,
  Check,
  Send,
  Smile,
  Mic,
  MicOff,
  Image as ImageIcon,
  ThumbsUp,
  ThumbsDown,
  User,
  Calendar,
  CreditCard,
  Zap,
  Brain,
  Heart,
  Gauge,
  Globe,
  Play,
  Pause,
  Volume2,
  Upload,
  FileText,
  RefreshCw,
  ChevronRight,
  X,
  ArrowUp,
  Loader2,
  TrendingUp,
  Target,
  Clock,
  AlertCircle,
  CheckCircle2,
  Phone,
  Mail,
  ShoppingCart,
  DollarSign
} from 'lucide-react'

interface Message {
  id: string
  role: 'bot' | 'user'
  content: string
  timestamp: Date
  confidence?: number
  intent?: string
  sentiment?: 'positive' | 'neutral' | 'negative'
  buyingIntent?: number
  isTyping?: boolean
  actions?: { label: string; icon: any }[]
  voiceNote?: boolean
}

interface LeadContext {
  name: string
  email: string
  phone: string
  leadScore: number
  temperature: 'hot' | 'warm' | 'cold'
  sentiment: 'positive' | 'neutral' | 'negative'
  previousPurchases: number
  lastActivity: string
  tags: string[]
  notes: string[]
  buyingIntent: number
}

const demoMessages: Message[] = [
  { 
    id: '1', 
    role: 'bot', 
    content: "Hi there! Welcome to Acme Dental. I'm your AI assistant and I'm here to help you with appointments, questions, or anything else you need. How can I assist you today?", 
    timestamp: new Date(Date.now() - 300000),
    confidence: 98, 
    intent: 'greeting',
    sentiment: 'positive'
  },
  { 
    id: '2', 
    role: 'user', 
    content: "I'd like to book a teeth cleaning appointment",
    timestamp: new Date(Date.now() - 240000)
  },
  { 
    id: '3', 
    role: 'bot', 
    content: "I'd be happy to help you book a teeth cleaning! We have several openings this week. Do you prefer mornings or afternoons?", 
    timestamp: new Date(Date.now() - 180000),
    confidence: 95, 
    intent: 'booking_request',
    sentiment: 'positive',
    buyingIntent: 78,
    actions: [
      { label: 'Show Calendar', icon: Calendar },
      { label: 'Morning Slots', icon: Clock },
      { label: 'Afternoon Slots', icon: Clock },
    ]
  },
  { 
    id: '4', 
    role: 'user', 
    content: "Afternoons work better for me. Also, how much does it cost?",
    timestamp: new Date(Date.now() - 120000)
  },
  { 
    id: '5', 
    role: 'bot', 
    content: "Perfect! Our professional teeth cleaning is $150, which includes a thorough examination and fluoride treatment.\n\nI have these afternoon slots available:\n\n• Tuesday at 2:00 PM\n• Wednesday at 3:30 PM\n• Friday at 4:00 PM\n\nWhich one works best for you?", 
    timestamp: new Date(Date.now() - 60000),
    confidence: 97, 
    intent: 'pricing_inquiry',
    sentiment: 'positive',
    buyingIntent: 85,
    actions: [
      { label: 'Book Tuesday 2PM', icon: CheckCircle2 },
      { label: 'Book Wednesday 3:30PM', icon: CheckCircle2 },
      { label: 'Book Friday 4PM', icon: CheckCircle2 },
      { label: 'Send Payment Link', icon: DollarSign },
    ]
  },
]

const leadContext: LeadContext = {
  name: 'Sarah Johnson',
  email: 'sarah.j@email.com',
  phone: '+1 (555) 123-4567',
  leadScore: 85,
  temperature: 'hot',
  sentiment: 'positive',
  previousPurchases: 3,
  lastActivity: '2 minutes ago',
  tags: ['returning customer', 'teeth cleaning', 'high value'],
  notes: [
    'Prefers afternoon appointments',
    'Has dental insurance',
    'Referred by John Smith'
  ],
  buyingIntent: 85
}

const aiActions = [
  { id: 'draft', label: 'Draft Response', icon: MessageSquare, color: 'indigo' },
  { id: 'analyze', label: 'Analyze Lead', icon: Brain, color: 'cyan' },
  { id: 'book', label: 'Book Meeting', icon: Calendar, color: 'emerald' },
  { id: 'automation', label: 'Create Automation', icon: Zap, color: 'amber' },
  { id: 'followup', label: 'Generate Follow-up', icon: RefreshCw, color: 'purple' },
  { id: 'script', label: 'Sales Script', icon: FileText, color: 'pink' },
  { id: 'summarize', label: 'Summarize', icon: FileText, color: 'blue' },
  { id: 'escalate', label: 'Escalate to Human', icon: User, color: 'orange' },
  { id: 'payment', label: 'Send Payment Link', icon: CreditCard, color: 'green' },
]

const botPersonalities = [
  { id: 'professional', name: 'Professional', description: 'Formal and business-focused', emoji: '👔' },
  { id: 'friendly', name: 'Friendly', description: 'Warm and approachable', emoji: '😊' },
  { id: 'enthusiastic', name: 'Enthusiastic', description: 'Energetic and excited', emoji: '🎉' },
  { id: 'empathetic', name: 'Empathetic', description: 'Understanding and caring', emoji: '💙' },
]

export default function ChatbotPage() {
  const [activeTab, setActiveTab] = useState('preview')
  const [messages, setMessages] = useState<Message[]>(demoMessages)
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [selectedPersonality, setSelectedPersonality] = useState('friendly')
  const [copied, setCopied] = useState(false)
  const [responseDelay, setResponseDelay] = useState([1.5])
  const [confidenceThreshold, setConfidenceThreshold] = useState([85])
  const [showMemoryPanel, setShowMemoryPanel] = useState(true)
  const [aiThinking, setAiThinking] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsTyping(true)

    // Simulate AI thinking states
    const thinkingStates = [
      'Analyzing customer intent...',
      'Searching CRM memory...',
      'Generating optimized response...',
    ]

    let stateIndex = 0
    setAiThinking(thinkingStates[0])

    const thinkingInterval = setInterval(() => {
      stateIndex++
      if (stateIndex < thinkingStates.length) {
        setAiThinking(thinkingStates[stateIndex])
      }
    }, 600)

    setTimeout(() => {
      clearInterval(thinkingInterval)
      setAiThinking(null)
      setIsTyping(false)
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'bot',
        content: "That's a great question! I've analyzed your request and here's what I recommend based on your needs and our current offerings. Would you like me to proceed with booking, or do you have any other questions?",
        timestamp: new Date(),
        confidence: 94,
        intent: 'inquiry_response',
        sentiment: 'positive',
        buyingIntent: 82,
        actions: [
          { label: 'Proceed with Booking', icon: Calendar },
          { label: 'More Information', icon: FileText },
        ]
      }
      setMessages(prev => [...prev, botMessage])
    }, 2000)
  }

  const handleCopy = () => {
    navigator.clipboard.writeText('<script src="https://vactora.ai/chatbot/abc123"></script>')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const getTemperatureColor = (temp: string) => {
    switch (temp) {
      case 'hot': return 'text-red-400 bg-red-400/20'
      case 'warm': return 'text-amber-400 bg-amber-400/20'
      case 'cold': return 'text-blue-400 bg-blue-400/20'
      default: return 'text-gray-400 bg-gray-400/20'
    }
  }

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-emerald-400'
      case 'negative': return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  return (
    <div className="flex min-h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              AI Sales Chatbot
            </h1>
            <p className="text-gray-400">Your 24/7 AI sales agent that sells, books, and supports automatically</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 px-4 py-2">
              <div className="w-2 h-2 rounded-full bg-emerald-400 mr-2 animate-pulse" />
              Live
            </Badge>
            <Button variant="outline" className="border-white/10 hover:bg-white/5">
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </Button>
            <Button className="bg-gradient-to-r from-indigo-600 to-cyan-600 hover:opacity-90">
              <Sparkles className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Main Chat Area */}
          <div className="col-span-8 space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="glass-card border-white/10 p-1 mb-6">
                <TabsTrigger value="preview" className="data-[state=active]:bg-white/10">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Live Preview
                </TabsTrigger>
                <TabsTrigger value="personality" className="data-[state=active]:bg-white/10">
                  <Smile className="w-4 h-4 mr-2" />
                  Personality
                </TabsTrigger>
                <TabsTrigger value="appearance" className="data-[state=active]:bg-white/10">
                  <Palette className="w-4 h-4 mr-2" />
                  Appearance
                </TabsTrigger>
                <TabsTrigger value="embed" className="data-[state=active]:bg-white/10">
                  <Code className="w-4 h-4 mr-2" />
                  Embed
                </TabsTrigger>
              </TabsList>

              <TabsContent value="preview">
                <div className="glass-card rounded-[18px] border border-white/5 overflow-hidden">
                  {/* Chat Header with Glow */}
                  <div className="p-4 border-b border-white/10 bg-gradient-to-r from-indigo-600/20 via-purple-600/10 to-cyan-600/20 relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 to-cyan-500/5 animate-pulse" />
                    <div className="flex items-center justify-between relative">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center ring-2 ring-indigo-500/30 ring-offset-2 ring-offset-[#0a0a1a]">
                            <Bot className="w-6 h-6 text-white" />
                          </div>
                          <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-[#0a0a1a] animate-pulse" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-white">Acme AI Assistant</h3>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-emerald-400">Online</span>
                            <span className="text-xs text-gray-500">•</span>
                            <span className="text-xs text-gray-400">Avg. response: 1.2s</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="bg-indigo-500/20 text-indigo-400 border-indigo-500/30 text-xs">
                          <Brain className="w-3 h-3 mr-1" />
                          GPT-4 Turbo
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Messages Area */}
                  <div className="p-4 space-y-4 h-[500px] overflow-y-auto bg-gradient-to-b from-transparent to-indigo-500/[0.02]">
                    <AnimatePresence>
                      {messages.map((msg, idx) => (
                        <motion.div
                          key={msg.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[80%] ${msg.role === 'user' ? 'order-2' : ''}`}>
                            {msg.role === 'bot' && (
                              <div className="flex items-center gap-2 mb-2">
                                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center">
                                  <Sparkles className="w-3 h-3 text-white" />
                                </div>
                                <span className="text-xs text-gray-400">AI Assistant</span>
                                {msg.confidence && (
                                  <Badge variant="outline" className="text-[10px] h-5 bg-indigo-500/20 text-indigo-400 border-indigo-500/30">
                                    <Gauge className="w-2.5 h-2.5 mr-1" />
                                    {msg.confidence}%
                                  </Badge>
                                )}
                                {msg.intent && (
                                  <Badge variant="outline" className="text-[10px] h-5 bg-purple-500/20 text-purple-400 border-purple-500/30">
                                    {msg.intent.replace('_', ' ')}
                                  </Badge>
                                )}
                                {msg.buyingIntent && msg.buyingIntent > 70 && (
                                  <Badge variant="outline" className="text-[10px] h-5 bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                                    <TrendingUp className="w-2.5 h-2.5 mr-1" />
                                    {msg.buyingIntent}% intent
                                  </Badge>
                                )}
                              </div>
                            )}
                            <div className={`rounded-2xl px-4 py-3 ${
                              msg.role === 'user' 
                                ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-lg shadow-indigo-500/20' 
                                : 'bg-white/5 backdrop-blur-sm border border-white/10 text-gray-100 hover:border-white/20 transition-colors'
                            }`}>
                              <p className="text-sm whitespace-pre-line leading-relaxed">{msg.content}</p>
                            </div>
                            
                            {/* Bot Actions */}
                            {msg.role === 'bot' && msg.actions && (
                              <div className="flex flex-wrap items-center gap-2 mt-2">
                                {msg.actions.map((action, i) => (
                                  <Button
                                    key={i}
                                    variant="outline"
                                    size="sm"
                                    className="h-7 text-xs border-white/10 hover:bg-indigo-500/20 hover:border-indigo-500/30 hover:text-indigo-400 transition-colors"
                                  >
                                    <action.icon className="w-3 h-3 mr-1.5" />
                                    {action.label}
                                  </Button>
                                ))}
                              </div>
                            )}

                            {/* Bot Feedback */}
                            {msg.role === 'bot' && (
                              <div className="flex items-center gap-1 mt-2 opacity-0 hover:opacity-100 transition-opacity">
                                <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-white/5">
                                  <ThumbsUp className="w-3 h-3 text-gray-500 hover:text-emerald-400" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-white/5">
                                  <ThumbsDown className="w-3 h-3 text-gray-500 hover:text-red-400" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-white/5">
                                  <Copy className="w-3 h-3 text-gray-500 hover:text-indigo-400" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-white/5">
                                  <RefreshCw className="w-3 h-3 text-gray-500 hover:text-cyan-400" />
                                </Button>
                              </div>
                            )}

                            {/* Timestamp */}
                            <p className="text-[10px] text-gray-500 mt-1">
                              {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>

                    {/* AI Typing Indicator */}
                    {isTyping && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-start gap-3"
                      >
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center">
                          <Sparkles className="w-3 h-3 text-white" />
                        </div>
                        <div className="bg-white/5 border border-white/10 rounded-2xl px-4 py-3">
                          <div className="flex items-center gap-2">
                            <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
                            <span className="text-sm text-gray-400">
                              {aiThinking || 'Thinking...'}
                            </span>
                          </div>
                          <div className="flex gap-1 mt-2">
                            <div className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                            <div className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                            <div className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                          </div>
                        </div>
                      </motion.div>
                    )}

                    <div ref={messagesEndRef} />
                  </div>

                  {/* AI Actions Bar */}
                  <div className="px-4 py-3 border-t border-white/10 bg-white/[0.02]">
                    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                      {aiActions.map((action) => (
                        <Button
                          key={action.id}
                          variant="outline"
                          size="sm"
                          className="h-8 text-xs border-white/10 hover:bg-white/5 whitespace-nowrap"
                        >
                          <action.icon className="w-3.5 h-3.5 mr-1.5" />
                          {action.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Chat Input */}
                  <div className="p-4 border-t border-white/10 bg-gradient-to-r from-indigo-600/5 to-cyan-600/5">
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="hover:bg-white/5">
                        <ImageIcon className="w-5 h-5 text-gray-400" />
                      </Button>
                      <Button variant="ghost" size="icon" className="hover:bg-white/5">
                        <Upload className="w-5 h-5 text-gray-400" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className={`hover:bg-white/5 ${isRecording ? 'bg-red-500/20 text-red-400' : ''}`}
                        onClick={() => setIsRecording(!isRecording)}
                      >
                        {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 text-gray-400" />}
                      </Button>
                      <div className="flex-1 relative">
                        <Input 
                          value={input}
                          onChange={(e) => setInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                          placeholder="Type a message or / for commands..." 
                          className="bg-white/5 border-white/10 pr-12"
                        />
                        {input.startsWith('/') && (
                          <div className="absolute bottom-full left-0 mb-2 w-full bg-[#0a0a1a] border border-white/10 rounded-xl p-2 shadow-xl">
                            <p className="text-xs text-gray-500 px-2 mb-1">Commands</p>
                            {['/book', '/analyze', '/reply', '/followup', '/email', '/automation'].map(cmd => (
                              <button
                                key={cmd}
                                onClick={() => setInput(cmd + ' ')}
                                className="w-full text-left px-2 py-1.5 text-sm text-gray-300 hover:bg-white/5 rounded"
                              >
                                {cmd}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      <Button 
                        size="icon" 
                        onClick={handleSend}
                        disabled={!input.trim()}
                        className="bg-gradient-to-r from-indigo-600 to-cyan-600 hover:opacity-90 disabled:opacity-50"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="personality">
                <div className="glass-card rounded-[18px] p-6 border border-white/5 space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Bot Personality</h3>
                    <div className="grid grid-cols-2 gap-4">
                      {botPersonalities.map((personality) => (
                        <div 
                          key={personality.id}
                          className={`p-4 rounded-xl border cursor-pointer transition-all duration-200 ${
                            selectedPersonality === personality.id 
                              ? 'border-indigo-500 bg-indigo-500/10' 
                              : 'border-white/10 hover:border-white/20 bg-white/5'
                          }`}
                          onClick={() => setSelectedPersonality(personality.id)}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{personality.emoji}</span>
                            <div>
                              <p className="font-medium text-white">{personality.name}</p>
                              <p className="text-sm text-gray-400">{personality.description}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Response Settings</h3>
                    <div className="space-y-6">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="text-sm font-medium text-gray-300">Human-like Delay</label>
                          <span className="text-sm text-gray-400">{responseDelay[0]}s</span>
                        </div>
                        <Slider value={responseDelay} onValueChange={setResponseDelay} max={5} step={0.5} />
                        <p className="text-xs text-gray-500 mt-1">Adds realistic typing delay before responses</p>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="text-sm font-medium text-gray-300">Confidence Threshold</label>
                          <span className="text-sm text-gray-400">{confidenceThreshold[0]}%</span>
                        </div>
                        <Slider value={confidenceThreshold} onValueChange={setConfidenceThreshold} max={100} />
                        <p className="text-xs text-gray-500 mt-1">Escalate to human when below this threshold</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Capabilities</h3>
                    <div className="space-y-3">
                      {[
                        { id: 'booking', name: 'Book Appointments', icon: Calendar, enabled: true },
                        { id: 'payments', name: 'Send Payment Links', icon: CreditCard, enabled: true },
                        { id: 'objections', name: 'Handle Objections', icon: Zap, enabled: true },
                        { id: 'escalate', name: 'Escalate to Human', icon: User, enabled: true },
                        { id: 'emotions', name: 'Smart Emotions', icon: Heart, enabled: false },
                        { id: 'memory', name: 'AI Memory', icon: Brain, enabled: true },
                      ].map((cap) => (
                        <div key={cap.id} className="flex items-center justify-between p-3 rounded-xl bg-white/5">
                          <div className="flex items-center gap-3">
                            <cap.icon className="w-4 h-4 text-gray-400" />
                            <span className="text-sm text-white">{cap.name}</span>
                          </div>
                          <Switch defaultChecked={cap.enabled} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="appearance">
                <div className="glass-card rounded-[18px] p-6 border border-white/5 space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Chat Widget Colors</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Primary Color</label>
                        <div className="flex gap-2">
                          {['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#06b6d4'].map((color) => (
                            <button
                              key={color}
                              className="w-10 h-10 rounded-xl border-2 border-white/20 hover:border-white transition-colors"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Background</label>
                        <div className="flex gap-2">
                          {['#ffffff', '#f8fafc', '#1e1e2e', '#0f0f1a', '#1a1a2e'].map((color) => (
                            <button
                              key={color}
                              className="w-10 h-10 rounded-xl border-2 border-white/20 hover:border-white transition-colors"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Bot Avatar</h3>
                    <div className="flex items-center gap-4">
                      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center ring-4 ring-indigo-500/20">
                        <Bot className="w-10 h-10 text-white" />
                      </div>
                      <div className="space-y-2">
                        <Button variant="outline" className="border-white/10">
                          Upload Custom Avatar
                        </Button>
                        <p className="text-xs text-gray-500">Recommended: 200x200px PNG</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Widget Position</h3>
                    <div className="flex gap-4">
                      {['Bottom Right', 'Bottom Left'].map((pos) => (
                        <div 
                          key={pos}
                          className={`flex-1 p-4 rounded-xl border cursor-pointer transition-all ${
                            pos === 'Bottom Right' 
                              ? 'border-indigo-500 bg-indigo-500/10' 
                              : 'border-white/10 hover:border-white/20 bg-white/5'
                          }`}
                        >
                          <p className="text-center text-white">{pos}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="embed">
                <div className="glass-card rounded-[18px] p-6 border border-white/5 space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Embed Code</h3>
                    <div className="bg-[#0a0a1a] rounded-xl p-4 font-mono text-sm">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-400">HTML</span>
                        <Button variant="ghost" size="sm" onClick={handleCopy} className="hover:bg-white/5">
                          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
                        </Button>
                      </div>
                      <code className="text-indigo-400">
                        {'<script src="https://vactora.ai/chatbot/abc123"></script>'}
                      </code>
                    </div>
                    <p className="text-sm text-gray-400 mt-2">Add this code before the closing {'</body>'} tag</p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Allowed Domains</h3>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Input defaultValue="acmedental.com" className="bg-white/5 border-white/10" />
                        <Button variant="ghost" size="icon" className="hover:bg-white/5">
                          <Check className="w-4 h-4 text-emerald-400" />
                        </Button>
                      </div>
                      <Button variant="outline" className="border-white/10 border-dashed w-full">
                        + Add Domain
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* AI Memory Panel */}
          <div className="col-span-4 space-y-6">
            {/* Lead Context Card */}
            <div className="glass-card rounded-[18px] p-6 border border-white/5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Brain className="w-5 h-5 text-indigo-400" />
                  AI Memory
                </h3>
                <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                  Active
                </Badge>
              </div>

              {/* Customer Info */}
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center text-white font-semibold">
                    {leadContext.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="font-medium text-white">{leadContext.name}</p>
                    <p className="text-sm text-gray-400">{leadContext.email}</p>
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-white/5">
                    <p className="text-xs text-gray-400 mb-1">Lead Score</p>
                    <p className="text-xl font-bold text-white">{leadContext.leadScore}</p>
                    <div className="w-full h-1.5 bg-white/10 rounded-full mt-2">
                      <div 
                        className="h-full bg-gradient-to-r from-indigo-500 to-cyan-500 rounded-full"
                        style={{ width: `${leadContext.leadScore}%` }}
                      />
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5">
                    <p className="text-xs text-gray-400 mb-1">Buying Intent</p>
                    <p className="text-xl font-bold text-emerald-400">{leadContext.buyingIntent}%</p>
                    <div className="flex items-center gap-1 mt-2">
                      <TrendingUp className="w-3 h-3 text-emerald-400" />
                      <span className="text-xs text-emerald-400">High</span>
                    </div>
                  </div>
                </div>

                {/* Temperature & Sentiment */}
                <div className="flex items-center gap-2">
                  <Badge className={`${getTemperatureColor(leadContext.temperature)}`}>
                    {leadContext.temperature.toUpperCase()} LEAD
                  </Badge>
                  <Badge variant="outline" className={`border-current ${getSentimentColor(leadContext.sentiment)}`}>
                    <Heart className="w-3 h-3 mr-1" />
                    {leadContext.sentiment}
                  </Badge>
                </div>

                {/* Tags */}
                <div>
                  <p className="text-xs text-gray-400 mb-2">Tags</p>
                  <div className="flex flex-wrap gap-2">
                    {leadContext.tags.map(tag => (
                      <Badge key={tag} variant="outline" className="bg-white/5 border-white/10 text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Contact Info */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <Phone className="w-4 h-4" />
                    {leadContext.phone}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <Mail className="w-4 h-4" />
                    {leadContext.email}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <ShoppingCart className="w-4 h-4" />
                    {leadContext.previousPurchases} previous purchases
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <Clock className="w-4 h-4" />
                    Last active: {leadContext.lastActivity}
                  </div>
                </div>

                {/* AI Notes */}
                <div>
                  <p className="text-xs text-gray-400 mb-2">AI Notes</p>
                  <div className="space-y-2">
                    {leadContext.notes.map((note, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm text-gray-300">
                        <CheckCircle2 className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
                        {note}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* AI Recommendations */}
            <div className="glass-card rounded-[18px] p-6 border border-white/5">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                AI Recommendations
              </h3>
              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                  <div className="flex items-center gap-2 text-emerald-400 text-sm font-medium mb-1">
                    <Target className="w-4 h-4" />
                    High Conversion Opportunity
                  </div>
                  <p className="text-xs text-gray-300">Customer shows strong buying signals. Recommend sending appointment confirmation with payment link.</p>
                </div>
                <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                  <div className="flex items-center gap-2 text-indigo-400 text-sm font-medium mb-1">
                    <Zap className="w-4 h-4" />
                    Upsell Opportunity
                  </div>
                  <p className="text-xs text-gray-300">Based on history, suggest teeth whitening package (+$99).</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
