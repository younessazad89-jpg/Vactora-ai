'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Shield,
  Key,
  Lock,
  Eye,
  EyeOff,
  Copy,
  RefreshCw,
  Plus,
  Trash2,
  Activity,
  Globe,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Smartphone,
  Monitor,
  MapPin,
  MoreHorizontal
} from 'lucide-react'

const apiKeys = [
  {
    id: '1',
    name: 'Production API Key',
    key: 'vac_live_sk_1234567890abcdef',
    created: 'Jan 15, 2024',
    lastUsed: '2 min ago',
    status: 'active',
  },
  {
    id: '2',
    name: 'Development API Key',
    key: 'vac_test_sk_abcdef1234567890',
    created: 'Feb 20, 2024',
    lastUsed: '3 days ago',
    status: 'active',
  },
  {
    id: '3',
    name: 'Webhook Secret',
    key: 'whsec_9876543210fedcba',
    created: 'Mar 10, 2024',
    lastUsed: 'Never',
    status: 'inactive',
  },
]

const activityLogs = [
  {
    id: '1',
    action: 'Login successful',
    user: 'ahmed@vactora.ai',
    ip: '192.168.1.1',
    device: 'Chrome on MacOS',
    location: 'New York, USA',
    time: '2 min ago',
    type: 'success',
  },
  {
    id: '2',
    action: 'API key created',
    user: 'sarah@vactora.ai',
    ip: '10.0.0.1',
    device: 'Firefox on Windows',
    location: 'London, UK',
    time: '1 hour ago',
    type: 'info',
  },
  {
    id: '3',
    action: 'Failed login attempt',
    user: 'unknown@email.com',
    ip: '203.45.67.89',
    device: 'Unknown',
    location: 'Unknown',
    time: '3 hours ago',
    type: 'warning',
  },
  {
    id: '4',
    action: 'Password changed',
    user: 'michael@vactora.ai',
    ip: '172.16.0.1',
    device: 'Safari on iOS',
    location: 'San Francisco, USA',
    time: '1 day ago',
    type: 'success',
  },
  {
    id: '5',
    action: 'Team member invited',
    user: 'ahmed@vactora.ai',
    ip: '192.168.1.1',
    device: 'Chrome on MacOS',
    location: 'New York, USA',
    time: '2 days ago',
    type: 'info',
  },
]

const sessions = [
  {
    id: '1',
    device: 'Chrome on MacOS',
    location: 'New York, USA',
    ip: '192.168.1.1',
    lastActive: 'Active now',
    current: true,
  },
  {
    id: '2',
    device: 'Safari on iPhone',
    location: 'New York, USA',
    ip: '192.168.1.2',
    lastActive: '1 hour ago',
    current: false,
  },
  {
    id: '3',
    device: 'Firefox on Windows',
    location: 'Los Angeles, USA',
    ip: '10.0.0.5',
    lastActive: '3 days ago',
    current: false,
  },
]

export default function SecurityPage() {
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)

  const toggleKeyVisibility = (id: string) => {
    setShowKeys(prev => ({ ...prev, [id]: !prev[id] }))
  }

  const maskKey = (key: string) => {
    return key.substring(0, 12) + '••••••••••••'
  }

  return (
    <div className="flex h-screen bg-[#050816]">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Security</h1>
              <p className="text-muted-foreground">Manage API keys, sessions, and audit logs</p>
            </div>
            <Badge className="bg-green-500/20 text-green-400 border-0">
              <Shield className="w-3 h-3 mr-1" />
              All Systems Secure
            </Badge>
          </div>

          <Tabs defaultValue="api-keys" className="space-y-6">
            <TabsList className="bg-white/[0.04] border border-white/[0.08] p-1 rounded-xl">
              <TabsTrigger value="api-keys" className="rounded-lg data-[state=active]:bg-primary">
                <Key className="w-4 h-4 mr-2" />
                API Keys
              </TabsTrigger>
              <TabsTrigger value="sessions" className="rounded-lg data-[state=active]:bg-primary">
                <Monitor className="w-4 h-4 mr-2" />
                Sessions
              </TabsTrigger>
              <TabsTrigger value="audit" className="rounded-lg data-[state=active]:bg-primary">
                <Activity className="w-4 h-4 mr-2" />
                Audit Log
              </TabsTrigger>
              <TabsTrigger value="settings" className="rounded-lg data-[state=active]:bg-primary">
                <Lock className="w-4 h-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>

            {/* API Keys Tab */}
            <TabsContent value="api-keys">
              <div className="glass-card overflow-hidden">
                <div className="p-6 border-b border-white/[0.06]">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-white">API Keys</h3>
                      <p className="text-sm text-muted-foreground">Manage your API keys for integrations</p>
                    </div>
                    <Button className="rounded-xl bg-primary hover:bg-primary/90">
                      <Plus className="w-4 h-4 mr-2" />
                      Create New Key
                    </Button>
                  </div>
                </div>

                <div className="divide-y divide-white/[0.04]">
                  {apiKeys.map((key) => (
                    <div key={key.id} className="p-6 hover:bg-white/[0.02] transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-primary/10">
                          <Key className="w-5 h-5 text-primary" />
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-white">{key.name}</span>
                            <Badge 
                              className={`text-[10px] border-0 ${
                                key.status === 'active' 
                                  ? 'bg-green-500/20 text-green-400' 
                                  : 'bg-muted text-muted-foreground'
                              }`}
                            >
                              {key.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <code className="font-mono">
                              {showKeys[key.id] ? key.key : maskKey(key.key)}
                            </code>
                          </div>
                        </div>

                        <div className="text-right text-sm">
                          <div className="text-muted-foreground">Last used: {key.lastUsed}</div>
                          <div className="text-muted-foreground/60">Created: {key.created}</div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="rounded-full"
                            onClick={() => toggleKeyVisibility(key.id)}
                          >
                            {showKeys[key.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </Button>
                          <Button variant="ghost" size="icon" className="rounded-full">
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="rounded-full">
                            <RefreshCw className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="rounded-full text-red-400">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Sessions Tab */}
            <TabsContent value="sessions">
              <div className="glass-card overflow-hidden">
                <div className="p-6 border-b border-white/[0.06]">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-white">Active Sessions</h3>
                      <p className="text-sm text-muted-foreground">Devices currently logged into your account</p>
                    </div>
                    <Button variant="outline" className="rounded-xl border-white/[0.08] text-red-400">
                      Sign Out All Devices
                    </Button>
                  </div>
                </div>

                <div className="divide-y divide-white/[0.04]">
                  {sessions.map((session) => (
                    <div key={session.id} className="p-6 hover:bg-white/[0.02] transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-xl ${session.current ? 'bg-green-500/10' : 'bg-white/[0.04]'}`}>
                          {session.device.includes('iPhone') || session.device.includes('iOS') ? (
                            <Smartphone className={`w-5 h-5 ${session.current ? 'text-green-400' : 'text-muted-foreground'}`} />
                          ) : (
                            <Monitor className={`w-5 h-5 ${session.current ? 'text-green-400' : 'text-muted-foreground'}`} />
                          )}
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-white">{session.device}</span>
                            {session.current && (
                              <Badge className="bg-green-500/20 text-green-400 border-0 text-[10px]">
                                Current
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {session.location}
                            </span>
                            <span>{session.ip}</span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className={`text-sm ${session.current ? 'text-green-400' : 'text-muted-foreground'}`}>
                            {session.lastActive}
                          </div>
                        </div>

                        {!session.current && (
                          <Button variant="ghost" size="sm" className="rounded-full text-red-400">
                            Sign Out
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Audit Log Tab */}
            <TabsContent value="audit">
              <div className="glass-card overflow-hidden">
                <div className="p-6 border-b border-white/[0.06]">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-white">Audit Log</h3>
                      <p className="text-sm text-muted-foreground">Track all security-related activities</p>
                    </div>
                    <Button variant="outline" className="rounded-xl border-white/[0.08]">
                      Export Logs
                    </Button>
                  </div>
                </div>

                <div className="divide-y divide-white/[0.04]">
                  {activityLogs.map((log) => (
                    <div key={log.id} className="p-5 hover:bg-white/[0.02] transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`p-2.5 rounded-xl ${
                          log.type === 'success' ? 'bg-green-500/10' :
                          log.type === 'warning' ? 'bg-yellow-500/10' :
                          'bg-blue-500/10'
                        }`}>
                          {log.type === 'success' ? (
                            <CheckCircle2 className="w-5 h-5 text-green-400" />
                          ) : log.type === 'warning' ? (
                            <AlertTriangle className="w-5 h-5 text-yellow-400" />
                          ) : (
                            <Activity className="w-5 h-5 text-blue-400" />
                          )}
                        </div>

                        <div className="flex-1">
                          <div className="font-medium text-white mb-0.5">{log.action}</div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>{log.user}</span>
                            <span>{log.ip}</span>
                            <span>{log.device}</span>
                          </div>
                        </div>

                        <div className="text-sm text-muted-foreground">
                          <Clock className="w-3.5 h-3.5 inline mr-1" />
                          {log.time}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <div className="space-y-6">
                <div className="glass-card p-6">
                  <h3 className="text-lg font-semibold text-white mb-6">Security Settings</h3>
                  
                  <div className="space-y-6">
                    <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-primary/10">
                          <Smartphone className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium text-white">Two-Factor Authentication</div>
                          <div className="text-sm text-muted-foreground">Add an extra layer of security to your account</div>
                        </div>
                      </div>
                      <Switch 
                        checked={twoFactorEnabled}
                        onCheckedChange={setTwoFactorEnabled}
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-yellow-500/10">
                          <AlertTriangle className="w-5 h-5 text-yellow-400" />
                        </div>
                        <div>
                          <div className="font-medium text-white">Login Alerts</div>
                          <div className="text-sm text-muted-foreground">Get notified of new sign-ins</div>
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-green-500/10">
                          <Globe className="w-5 h-5 text-green-400" />
                        </div>
                        <div>
                          <div className="font-medium text-white">IP Allowlist</div>
                          <div className="text-sm text-muted-foreground">Restrict access to specific IP addresses</div>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="rounded-full border-white/[0.08]">
                        Configure
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
