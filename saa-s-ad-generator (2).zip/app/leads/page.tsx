'use client'

import { Sidebar } from '@/components/Sidebar'
import { LeadsTable } from '@/components/LeadsTable'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Plus, Search, Filter } from 'lucide-react'
import { dummyLeads } from '@/lib/data'

// Supabase table: leads { id, workspace_id, name, phone, email, interest, status, source, last_message, created_at }

export default function LeadsPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 lg:px-6 h-16">
            <div className="flex items-center gap-4 pl-12 lg:pl-0">
              <h1 className="text-xl font-bold">Leads</h1>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 text-xs">
                {dummyLeads.length} Total
              </Badge>
            </div>
            <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4" />
              Add Lead
            </Button>
          </div>
        </header>

        <div className="p-4 lg:p-6 space-y-6 pb-24 lg:pb-6">
          {/* Search & Filters */}
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search leads..."
                className="pl-9 bg-muted/50 border-border"
              />
            </div>
            <Button variant="outline" size="sm" className="gap-2">
              <Filter className="w-4 h-4" />
              Filters
            </Button>
          </div>

          {/* Table */}
          <LeadsTable limit={100} showHeader={false} />
        </div>
      </main>
    </div>
  )
}
