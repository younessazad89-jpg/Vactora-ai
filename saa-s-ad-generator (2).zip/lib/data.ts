// Types
export interface Lead {
  id: string
  name: string
  phone: string
  email: string
  interest: string
  status: 'new' | 'qualified' | 'interested' | 'booked' | 'closed' | 'lost'
  source: string
  lastMessage: string
  createdAt: string
  avatar?: string
}

export interface Conversation {
  id: string
  leadId: string
  leadName: string
  leadPhone: string
  avatar?: string
  messages: Message[]
  lastMessage: string
  timestamp: string
  unread: boolean
  status: 'active' | 'resolved' | 'pending'
}

export interface Message {
  id: string
  content: string
  sender: 'ai' | 'user' | 'human'
  timestamp: string
}

export interface Stats {
  totalLeads: number
  activeConversations: number
  bookedCalls: number
  monthlyRevenue: number
  conversionRate: number
  avgResponseTime: string
}

export interface Activity {
  id: string
  type: 'lead_captured' | 'call_booked' | 'message_sent' | 'payment_received' | 'followup_sent'
  description: string
  timestamp: string
  leadName?: string
  amount?: number
}

export interface AIAgent {
  id: string
  name: string
  description: string
  status: 'active' | 'paused' | 'inactive'
  messagesHandled: number
  successRate: number
  icon: string
}

export interface Booking {
  id: string
  leadName: string
  leadPhone: string
  type: 'demo' | 'sales_call' | 'onboarding' | 'support'
  date: string
  time: string
  status: 'upcoming' | 'completed' | 'cancelled'
  notes?: string
}

export interface Plan {
  id: string
  name: string
  price: number
  interval: 'month' | 'year'
  features: string[]
  popular?: boolean
  current?: boolean
}

// Dummy Data
export const dummyStats: Stats = {
  totalLeads: 2847,
  activeConversations: 156,
  bookedCalls: 89,
  monthlyRevenue: 47500,
  conversionRate: 18.4,
  avgResponseTime: '< 30s'
}

export const dummyLeads: Lead[] = [
  {
    id: '1',
    name: 'James Mitchell',
    phone: '+1 (555) 123-4567',
    email: 'james@techcorp.com',
    interest: 'Enterprise Plan',
    status: 'qualified',
    source: 'WhatsApp Ad',
    lastMessage: 'Yes, I want to schedule a demo for our team',
    createdAt: '2024-01-15T10:30:00Z'
  },
  {
    id: '2',
    name: 'Sarah Williams',
    phone: '+44 7911 234567',
    email: 'sarah@marketing.co.uk',
    interest: 'Pro Plan',
    status: 'interested',
    source: 'Website',
    lastMessage: 'How does the AI handle complex questions?',
    createdAt: '2024-01-15T14:22:00Z'
  },
  {
    id: '3',
    name: 'Michael Brown',
    phone: '+1 (415) 555-0123',
    email: 'michael@startup.io',
    interest: 'Starter Plan',
    status: 'new',
    source: 'Referral',
    lastMessage: 'Can you tell me more about pricing?',
    createdAt: '2024-01-15T16:45:00Z'
  },
  {
    id: '4',
    name: 'Emma Thompson',
    phone: '+353 89 123 4567',
    email: 'emma@sales.ie',
    interest: 'Agency Plan',
    status: 'booked',
    source: 'LinkedIn',
    lastMessage: 'Perfect, see you tomorrow at 3pm!',
    createdAt: '2024-01-14T09:15:00Z'
  },
  {
    id: '5',
    name: 'David Chen',
    phone: '+61 412 345 678',
    email: 'david@ecommerce.au',
    interest: 'Pro Plan',
    status: 'closed',
    source: 'WhatsApp Ad',
    lastMessage: 'Payment completed. Thank you!',
    createdAt: '2024-01-13T11:20:00Z'
  },
  {
    id: '6',
    name: 'Sophie Martin',
    phone: '+352 691 234 567',
    email: 'sophie@fintech.lu',
    interest: 'Enterprise Plan',
    status: 'qualified',
    source: 'Trade Show',
    lastMessage: 'We need a solution for 200+ agents',
    createdAt: '2024-01-15T08:00:00Z'
  },
  {
    id: '7',
    name: 'Robert Taylor',
    phone: '+1 (647) 555-0198',
    email: 'robert@consulting.ca',
    interest: 'Agency Plan',
    status: 'interested',
    source: 'Google Ads',
    lastMessage: 'Can I white-label this for my clients?',
    createdAt: '2024-01-14T15:30:00Z'
  },
  {
    id: '8',
    name: 'Lisa Anderson',
    phone: '+44 7700 900123',
    email: 'lisa@retail.co.uk',
    interest: 'Pro Plan',
    status: 'lost',
    source: 'Website',
    lastMessage: 'We decided to go with another solution',
    createdAt: '2024-01-12T10:00:00Z'
  }
]

export const dummyConversations: Conversation[] = [
  {
    id: '1',
    leadId: '1',
    leadName: 'James Mitchell',
    leadPhone: '+1 (555) 123-4567',
    messages: [
      { id: '1', content: 'Hi, I saw your ad about AI sales automation', sender: 'user', timestamp: '10:25 AM' },
      { id: '2', content: 'Hello James! Welcome to Vactora AI. We help businesses automate their sales conversations with AI. How can I help you today?', sender: 'ai', timestamp: '10:25 AM' },
      { id: '3', content: 'We have a team of 50 sales reps and want to improve response times', sender: 'user', timestamp: '10:28 AM' },
      { id: '4', content: 'That\'s great! With our Enterprise plan, your team can handle 10x more conversations with AI assistance. Would you like to schedule a demo?', sender: 'ai', timestamp: '10:28 AM' },
      { id: '5', content: 'Yes, I want to schedule a demo for our team', sender: 'user', timestamp: '10:30 AM' },
    ],
    lastMessage: 'Yes, I want to schedule a demo for our team',
    timestamp: '2 min ago',
    unread: true,
    status: 'active'
  },
  {
    id: '2',
    leadId: '2',
    leadName: 'Sarah Williams',
    leadPhone: '+44 7911 234567',
    messages: [
      { id: '1', content: 'Does your AI understand industry-specific terms?', sender: 'user', timestamp: '2:15 PM' },
      { id: '2', content: 'Absolutely! Our AI can be trained on your specific industry terminology and product knowledge. It learns from your conversations to get better over time.', sender: 'ai', timestamp: '2:15 PM' },
      { id: '3', content: 'How does the AI handle complex questions?', sender: 'user', timestamp: '2:22 PM' },
    ],
    lastMessage: 'How does the AI handle complex questions?',
    timestamp: '15 min ago',
    unread: true,
    status: 'active'
  },
  {
    id: '3',
    leadId: '3',
    leadName: 'Michael Brown',
    leadPhone: '+1 (415) 555-0123',
    messages: [
      { id: '1', content: 'What are your pricing plans?', sender: 'user', timestamp: '4:40 PM' },
      { id: '2', content: 'We have 3 plans: Starter at $97/mo, Pro at $297/mo, and Agency at $997/mo. Each comes with different features. Which would you like to know more about?', sender: 'ai', timestamp: '4:40 PM' },
      { id: '3', content: 'Can you tell me more about pricing?', sender: 'user', timestamp: '4:45 PM' },
    ],
    lastMessage: 'Can you tell me more about pricing?',
    timestamp: '1 hour ago',
    unread: false,
    status: 'pending'
  },
  {
    id: '4',
    leadId: '4',
    leadName: 'Emma Thompson',
    leadPhone: '+353 89 123 4567',
    messages: [
      { id: '1', content: 'I run a marketing agency and need AI for multiple clients', sender: 'user', timestamp: '9:00 AM' },
      { id: '2', content: 'Perfect! Our Agency plan allows you to manage multiple client accounts with separate AI agents. Would you like to discuss this further on a call?', sender: 'ai', timestamp: '9:01 AM' },
      { id: '3', content: 'Yes please, when are you available?', sender: 'user', timestamp: '9:10 AM' },
      { id: '4', content: 'I have availability tomorrow at 3pm or 5pm. Which works better for you?', sender: 'ai', timestamp: '9:10 AM' },
      { id: '5', content: 'Perfect, see you tomorrow at 3pm!', sender: 'user', timestamp: '9:15 AM' },
    ],
    lastMessage: 'Perfect, see you tomorrow at 3pm!',
    timestamp: '3 hours ago',
    unread: false,
    status: 'resolved'
  },
  {
    id: '5',
    leadId: '5',
    leadName: 'David Chen',
    leadPhone: '+61 412 345 678',
    messages: [
      { id: '1', content: 'Just completed the payment!', sender: 'user', timestamp: '11:15 AM' },
      { id: '2', content: 'Thank you for choosing Vactora AI! Your account has been activated. Our onboarding team will reach out within 24 hours.', sender: 'ai', timestamp: '11:15 AM' },
      { id: '3', content: 'Payment completed. Thank you!', sender: 'user', timestamp: '11:20 AM' },
    ],
    lastMessage: 'Payment completed. Thank you!',
    timestamp: 'Yesterday',
    unread: false,
    status: 'resolved'
  }
]

export const dummyActivities: Activity[] = [
  {
    id: '1',
    type: 'lead_captured',
    description: 'New lead captured from WhatsApp Ad',
    timestamp: '2 min ago',
    leadName: 'James Mitchell'
  },
  {
    id: '2',
    type: 'call_booked',
    description: 'AI booked a sales demo call',
    timestamp: '15 min ago',
    leadName: 'Emma Thompson'
  },
  {
    id: '3',
    type: 'payment_received',
    description: 'Payment received for Pro Plan',
    timestamp: '1 hour ago',
    leadName: 'David Chen',
    amount: 297
  },
  {
    id: '4',
    type: 'message_sent',
    description: 'AI sent follow-up message',
    timestamp: '2 hours ago',
    leadName: 'Sarah Williams'
  },
  {
    id: '5',
    type: 'followup_sent',
    description: 'Automated follow-up sequence started',
    timestamp: '3 hours ago',
    leadName: 'Michael Brown'
  },
  {
    id: '6',
    type: 'lead_captured',
    description: 'New lead from LinkedIn campaign',
    timestamp: '4 hours ago',
    leadName: 'Sophie Martin'
  },
  {
    id: '7',
    type: 'call_booked',
    description: 'Demo call scheduled for tomorrow',
    timestamp: '5 hours ago',
    leadName: 'Robert Taylor'
  },
  {
    id: '8',
    type: 'payment_received',
    description: 'Agency plan subscription activated',
    timestamp: 'Yesterday',
    leadName: 'Tech Solutions Inc',
    amount: 997
  }
]

export const dummyAgents: AIAgent[] = [
  {
    id: '1',
    name: 'WhatsApp Sales Agent',
    description: 'Handles initial inquiries and qualifies leads via WhatsApp',
    status: 'active',
    messagesHandled: 12450,
    successRate: 94.2,
    icon: 'MessageCircle'
  },
  {
    id: '2',
    name: 'Lead Qualifier Agent',
    description: 'Scores and qualifies leads based on conversation context',
    status: 'active',
    messagesHandled: 8320,
    successRate: 91.8,
    icon: 'UserCheck'
  },
  {
    id: '3',
    name: 'Follow-up Agent',
    description: 'Sends automated follow-up messages to nurture leads',
    status: 'active',
    messagesHandled: 15680,
    successRate: 88.5,
    icon: 'RefreshCw'
  },
  {
    id: '4',
    name: 'Booking Agent',
    description: 'Schedules demos and calls with qualified prospects',
    status: 'paused',
    messagesHandled: 4250,
    successRate: 96.1,
    icon: 'Calendar'
  }
]

export const dummyBookings: Booking[] = [
  {
    id: '1',
    leadName: 'James Mitchell',
    leadPhone: '+1 (555) 123-4567',
    type: 'demo',
    date: '2024-01-16',
    time: '10:00 AM',
    status: 'upcoming',
    notes: 'Enterprise plan demo for 50-person team'
  },
  {
    id: '2',
    leadName: 'Emma Thompson',
    leadPhone: '+353 89 123 4567',
    type: 'sales_call',
    date: '2024-01-16',
    time: '3:00 PM',
    status: 'upcoming',
    notes: 'Discussing Agency plan for marketing agency'
  },
  {
    id: '3',
    leadName: 'Robert Taylor',
    leadPhone: '+1 (647) 555-0198',
    type: 'demo',
    date: '2024-01-17',
    time: '11:00 AM',
    status: 'upcoming',
    notes: 'White-label discussion'
  },
  {
    id: '4',
    leadName: 'David Chen',
    leadPhone: '+61 412 345 678',
    type: 'onboarding',
    date: '2024-01-17',
    time: '2:00 PM',
    status: 'upcoming',
    notes: 'Pro plan onboarding session'
  },
  {
    id: '5',
    leadName: 'Sophie Martin',
    leadPhone: '+352 691 234 567',
    type: 'demo',
    date: '2024-01-18',
    time: '9:00 AM',
    status: 'upcoming',
    notes: 'Enterprise demo - 200+ agents requirement'
  }
]

export const pricingPlans: Plan[] = [
  {
    id: 'starter',
    name: 'Starter',
    price: 97,
    interval: 'month',
    features: [
      '1,000 AI messages/month',
      '1 WhatsApp number',
      'Basic lead capture',
      'Email support',
      'Standard analytics',
      '5 AI agent responses/day'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 297,
    interval: 'month',
    popular: true,
    features: [
      '10,000 AI messages/month',
      '3 WhatsApp numbers',
      'Advanced lead scoring',
      'Priority support',
      'Advanced analytics',
      'Unlimited AI responses',
      'CRM integrations',
      'Custom AI training'
    ]
  },
  {
    id: 'agency',
    name: 'Agency',
    price: 997,
    interval: 'month',
    features: [
      'Unlimited AI messages',
      'Unlimited WhatsApp numbers',
      'White-label solution',
      'Dedicated account manager',
      'API access',
      'Multi-tenant dashboard',
      'Custom integrations',
      'SLA guarantee',
      'Team collaboration'
    ]
  }
]

// Chart data for analytics
export const leadsChartData = [
  { month: 'Aug', leads: 1200 },
  { month: 'Sep', leads: 1450 },
  { month: 'Oct', leads: 1680 },
  { month: 'Nov', leads: 2100 },
  { month: 'Dec', leads: 2400 },
  { month: 'Jan', leads: 2847 },
]

export const revenueChartData = [
  { month: 'Aug', revenue: 28000 },
  { month: 'Sep', revenue: 32000 },
  { month: 'Oct', revenue: 35500 },
  { month: 'Nov', revenue: 41000 },
  { month: 'Dec', revenue: 44500 },
  { month: 'Jan', revenue: 47500 },
]

export const conversionChartData = [
  { month: 'Aug', rate: 12.5 },
  { month: 'Sep', rate: 14.2 },
  { month: 'Oct', rate: 15.8 },
  { month: 'Nov', rate: 16.5 },
  { month: 'Dec', rate: 17.2 },
  { month: 'Jan', rate: 18.4 },
]

export const responseTimeData = [
  { day: 'Mon', time: 28 },
  { day: 'Tue', time: 25 },
  { day: 'Wed', time: 22 },
  { day: 'Thu', time: 30 },
  { day: 'Fri', time: 24 },
  { day: 'Sat', time: 35 },
  { day: 'Sun', time: 32 },
]
