'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Sparkles, 
  X, 
  Send, 
  Mic, 
  MicOff,
  Bot,
  User,
  Zap,
  Calendar,
  FileText,
  Mail,
  MessageSquare,
  BarChart3,
  Settings,
  Brain,
  Loader2,
  ChevronDown,
  Copy,
  RefreshCw,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  confidence?: number
  actions?: { label: string; action: string }[]
}

const quickActions = [
  { icon: Calendar, label: 'Book Meeting', command: '/book' },
  { icon: FileText, label: 'Generate Report', command: '/report' },
  { icon: Mail, label: 'Draft Email', command: '/email' },
  { icon: MessageSquare, label: 'Reply to Lead', command: '/reply' },
  { icon: BarChart3, label: 'Show Analytics', command: '/analytics' },
  { icon: Zap, label: 'Create Automation', command: '/automation' },
]

export function AICopilot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your AI Copilot. I can help you with leads, automations, analytics, and more. What would you like to do?",
      timestamp: new Date(),
      confidence: 98,
    }
  ])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: getAIResponse(input),
        timestamp: new Date(),
        confidence: Math.floor(Math.random() * 15) + 85,
        actions: [
          { label: 'View Details', action: 'view' },
          { label: 'Take Action', action: 'action' },
        ]
      }
      setMessages(prev => [...prev, aiMessage])
      setIsTyping(false)
    }, 1500)
  }

  const getAIResponse = (query: string): string => {
    const q = query.toLowerCase()
    if (q.includes('lead') || q.includes('leads')) {
      return "I found 12 new leads today. 3 are marked as hot leads with high buying intent. Would you like me to prioritize them for follow-up?"
    }
    if (q.includes('book') || q.includes('meeting') || q.includes('calendar')) {
      return "I can schedule a meeting for you. I see you have availability tomorrow at 2 PM and Friday at 10 AM. Which slot would you prefer?"
    }
    if (q.includes('analytics') || q.includes('report')) {
      return "Your conversion rate is up 23% this week! You've closed $45,200 in revenue. Shall I generate a detailed report?"
    }
    if (q.includes('automation') || q.includes('workflow')) {
      return "I can help create an automation. Common workflows include: Lead Follow-up, Booking Reminders, and Payment Collection. Which one interests you?"
    }
    return "I understand you're asking about \"" + query + "\". Let me analyze your data and provide insights. Is there anything specific you'd like to know?"
  }

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-gradient-to-r from-indigo-600 to-cyan-500 shadow-lg shadow-indigo-500/30 flex items-center justify-center hover:shadow-indigo-500/50 transition-all duration-300 group"
          >
            <Sparkles className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full animate-pulse" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Copilot Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className={`fixed bottom-6 right-6 z-50 w-[400px] ${isMinimized ? 'h-14' : 'h-[600px]'} bg-[#0a0a1a]/95 backdrop-blur-xl rounded-[18px] border border-white/10 shadow-2xl shadow-indigo-500/10 flex flex-col overflow-hidden transition-all duration-300`}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/10 bg-gradient-to-r from-indigo-600/10 to-cyan-600/10">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 rounded-full border-2 border-[#0a0a1a]" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">AI Copilot</h3>
                  <p className="text-xs text-gray-400">Always ready to help</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 hover:bg-white/5"
                  onClick={() => setIsMinimized(!isMinimized)}
                >
                  <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isMinimized ? 'rotate-180' : ''}`} />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 hover:bg-white/5"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="w-4 h-4 text-gray-400" />
                </Button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Quick Actions */}
                <div className="p-3 border-b border-white/5">
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
                    {quickActions.map((action) => (
                      <button
                        key={action.command}
                        onClick={() => setInput(action.command + ' ')}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/5 text-xs text-gray-300 whitespace-nowrap transition-colors"
                      >
                        <action.icon className="w-3 h-3" />
                        {action.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((msg) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[85%] ${msg.role === 'user' ? 'order-2' : ''}`}>
                        {msg.role === 'assistant' && (
                          <div className="flex items-center gap-2 mb-1">
                            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center">
                              <Sparkles className="w-2.5 h-2.5 text-white" />
                            </div>
                            <span className="text-[10px] text-gray-500">Copilot</span>
                            {msg.confidence && (
                              <Badge variant="outline" className="text-[9px] h-4 px-1.5 bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
                                {msg.confidence}%
                              </Badge>
                            )}
                          </div>
                        )}
                        <div className={`rounded-2xl px-3 py-2 text-sm ${
                          msg.role === 'user'
                            ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white'
                            : 'bg-white/5 border border-white/5 text-gray-200'
                        }`}>
                          {msg.content}
                        </div>
                        {msg.role === 'assistant' && msg.actions && (
                          <div className="flex items-center gap-2 mt-2">
                            {msg.actions.map((action) => (
                              <Button
                                key={action.action}
                                variant="outline"
                                size="sm"
                                className="h-6 text-[10px] border-white/10 hover:bg-white/5"
                              >
                                {action.label}
                              </Button>
                            ))}
                            <div className="flex items-center gap-1 ml-auto">
                              <Button variant="ghost" size="icon" className="h-5 w-5 hover:bg-white/5">
                                <Copy className="w-2.5 h-2.5 text-gray-500" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-5 w-5 hover:bg-white/5">
                                <RefreshCw className="w-2.5 h-2.5 text-gray-500" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-5 w-5 hover:bg-white/5">
                                <ThumbsUp className="w-2.5 h-2.5 text-gray-500" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}

                  {/* Typing Indicator */}
                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-start gap-2"
                    >
                      <div className="w-5 h-5 rounded-full bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center">
                        <Sparkles className="w-2.5 h-2.5 text-white" />
                      </div>
                      <div className="bg-white/5 border border-white/5 rounded-2xl px-3 py-2">
                        <div className="flex items-center gap-1.5">
                          <Brain className="w-3 h-3 text-indigo-400 animate-pulse" />
                          <span className="text-xs text-gray-400">Thinking...</span>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="p-3 border-t border-white/10 bg-[#050816]/50">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className={`h-9 w-9 ${isRecording ? 'bg-red-500/20 text-red-400' : 'hover:bg-white/5'}`}
                      onClick={() => setIsRecording(!isRecording)}
                    >
                      {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-gray-400" />}
                    </Button>
                    <Input
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                      placeholder="Ask anything or type / for commands..."
                      className="flex-1 h-9 bg-white/5 border-white/10 text-sm placeholder:text-gray-500"
                    />
                    <Button
                      size="icon"
                      onClick={handleSend}
                      disabled={!input.trim()}
                      className="h-9 w-9 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:opacity-90 disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-[10px] text-gray-500 mt-2 text-center">
                    Press <kbd className="px-1 py-0.5 bg-white/5 rounded text-gray-400">Cmd+K</kbd> for command palette
                  </p>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
