'use client'

import { cn } from '@/lib/utils'
import { dummyLeads } from '@/lib/data'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Users, ChevronRight, MoreHorizontal } from 'lucide-react'
import Link from 'next/link'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

const statusStyles = {
  new: 'bg-primary/20 text-primary border-primary/30',
  qualified: 'bg-chart-2/20 text-chart-2 border-chart-2/30',
  interested: 'bg-chart-3/20 text-chart-3 border-chart-3/30',
  booked: 'bg-chart-5/20 text-chart-5 border-chart-5/30',
  closed: 'bg-success/20 text-success border-success/30',
  lost: 'bg-destructive/20 text-destructive border-destructive/30'
}

interface LeadsTableProps {
  limit?: number
  showHeader?: boolean
}

export function LeadsTable({ limit = 6, showHeader = true }: LeadsTableProps) {
  const leads = dummyLeads.slice(0, limit)

  return (
    <div className="glass-card rounded-xl overflow-hidden">
      {showHeader && (
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            <h3 className="font-semibold">Recent Leads</h3>
          </div>
          <Link 
            href="/leads"
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
          >
            View all <ChevronRight className="w-3 h-3" />
          </Link>
        </div>
      )}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-muted-foreground">Name</TableHead>
              <TableHead className="text-muted-foreground hidden md:table-cell">Phone</TableHead>
              <TableHead className="text-muted-foreground hidden lg:table-cell">Interest</TableHead>
              <TableHead className="text-muted-foreground">Status</TableHead>
              <TableHead className="text-muted-foreground hidden xl:table-cell">Last Message</TableHead>
              <TableHead className="text-muted-foreground text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {leads.map((lead) => (
              <TableRow key={lead.id} className="border-border hover:bg-muted/30">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-gradient-to-br from-primary/20 to-accent/20 text-xs font-medium">
                        {lead.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{lead.name}</p>
                      <p className="text-xs text-muted-foreground md:hidden">{lead.phone}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  <span className="text-sm text-muted-foreground">{lead.phone}</span>
                </TableCell>
                <TableCell className="hidden lg:table-cell">
                  <span className="text-sm">{lead.interest}</span>
                </TableCell>
                <TableCell>
                  <Badge 
                    variant="outline" 
                    className={cn("text-[10px] font-medium capitalize", statusStyles[lead.status])}
                  >
                    {lead.status}
                  </Badge>
                </TableCell>
                <TableCell className="hidden xl:table-cell max-w-[200px]">
                  <p className="text-sm text-muted-foreground truncate">{lead.lastMessage}</p>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>View Details</DropdownMenuItem>
                      <DropdownMenuItem>Send Message</DropdownMenuItem>
                      <DropdownMenuItem>Update Status</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
