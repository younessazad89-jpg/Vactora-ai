'use client'

import { cn } from '@/lib/utils'
import { Wifi, WifiOff } from 'lucide-react'

interface ConnectionStatusProps {
  connected: boolean
}

export function ConnectionStatus({ connected }: ConnectionStatusProps) {
  return (
    <div className={cn(
      "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium",
      connected 
        ? "bg-success/10 text-success" 
        : "bg-destructive/10 text-destructive"
    )}>
      {connected ? (
        <>
          <Wifi className="w-4 h-4" />
          <span>WhatsApp Connected</span>
        </>
      ) : (
        <>
          <WifiOff className="w-4 h-4" />
          <span>Disconnected</span>
        </>
      )}
    </div>
  )
}
