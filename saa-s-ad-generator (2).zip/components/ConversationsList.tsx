'use client'

import { cn } from '@/lib/utils'
import { Conversation } from '@/lib/data'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'

interface ConversationsListProps {
  conversations: Conversation[]
}

function getInitials(name: string) {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

export function ConversationsList({ conversations }: ConversationsListProps) {
  return (
    <div className="bg-card rounded-lg border border-border">
      <div className="px-5 py-4 border-b border-border">
        <h3 className="text-sm font-medium text-card-foreground">Recent Conversations</h3>
      </div>
      <div className="divide-y divide-border">
        {conversations.map((conversation) => (
          <div 
            key={conversation.id}
            className="px-5 py-4 hover:bg-muted/50 cursor-pointer transition-colors"
          >
            <div className="flex items-start gap-3">
              <Avatar className="w-9 h-9">
                <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                  {getInitials(conversation.leadName)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className={cn(
                    "text-sm truncate",
                    conversation.unread ? "font-semibold text-card-foreground" : "font-medium text-card-foreground"
                  )}>
                    {conversation.leadName}
                  </p>
                  <span className="text-xs text-muted-foreground flex-shrink-0">
                    {conversation.timestamp}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground truncate mt-0.5">
                  {conversation.lastMessage}
                </p>
              </div>
              {conversation.unread && (
                <div className="w-2 h-2 rounded-full bg-chart-2 flex-shrink-0 mt-2" />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
