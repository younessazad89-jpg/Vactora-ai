'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Sparkles, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Zap,
  Target,
  Users,
  DollarSign,
  Clock,
  ArrowRight,
  Brain,
  RefreshCw
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

const insights = [
  {
    type: 'opportunity',
    icon: Target,
    color: 'emerald',
    title: '3 hot leads ready to close',
    description: 'Sarah J., Michael R., and Emma T. have 85%+ buying intent. AI recommends immediate follow-up.',
    action: 'View Leads',
    metric: '+$7,200 potential'
  },
  {
    type: 'alert',
    icon: AlertTriangle,
    color: 'amber',
    title: 'Response time increased by 12%',
    description: 'Average response time is now 2.4s. Consider enabling AI auto-reply for Instagram DMs.',
    action: 'Fix Now',
    metric: '2.4s avg'
  },
  {
    type: 'win',
    icon: CheckCircle2,
    color: 'cyan',
    title: 'AI booked 8 calls today',
    description: 'Your booking agent converted 8 leads into scheduled demos. 3 are high-value enterprise prospects.',
    action: 'View Calendar',
    metric: '+34% vs avg'
  },
  {
    type: 'prediction',
    icon: Brain,
    color: 'indigo',
    title: 'Revenue forecast: $48.2K this month',
    description: 'Based on current pipeline velocity and AI deal scoring, you\'re on track to exceed target by 12%.',
    action: 'View Forecast',
    metric: '+12% vs target'
  },
]

export function AIExecutiveSummary() {
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => setIsRefreshing(false), 2000)
  }

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; border: string; glow: string }> = {
      emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20', glow: 'shadow-emerald-500/10' },
      amber: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20', glow: 'shadow-amber-500/10' },
      cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/20', glow: 'shadow-cyan-500/10' },
      indigo: { bg: 'bg-indigo-500/10', text: 'text-indigo-400', border: 'border-indigo-500/20', glow: 'shadow-indigo-500/10' },
    }
    return colors[color] || colors.indigo
  }

  return (
    <div className="glass-card rounded-[18px] p-6 border border-white/5 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
      
      <div className="flex items-center justify-between mb-6 relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-cyan-500 flex items-center justify-center ai-glow">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">AI Executive Summary</h3>
            <p className="text-xs text-gray-400">Last updated 2 minutes ago</p>
          </div>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={handleRefresh}
          className="hover:bg-white/5 text-gray-400"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Quick Stats Bar */}
      <div className="grid grid-cols-4 gap-4 mb-6 relative">
        {[
          { label: 'Revenue Today', value: '$3,847', change: '+22%', icon: DollarSign, positive: true },
          { label: 'New Leads', value: '14', change: '+8', icon: Users, positive: true },
          { label: 'AI Messages', value: '342', change: '+18%', icon: Zap, positive: true },
          { label: 'Avg Response', value: '1.2s', change: '-0.3s', icon: Clock, positive: true },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-3 rounded-xl bg-white/[0.03] border border-white/5"
          >
            <div className="flex items-center gap-2 mb-1">
              <stat.icon className="w-3.5 h-3.5 text-gray-500" />
              <span className="text-xs text-gray-400">{stat.label}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-white">{stat.value}</span>
              <span className={`text-xs font-medium ${stat.positive ? 'text-emerald-400' : 'text-red-400'}`}>
                {stat.change}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* AI Insights */}
      <div className="space-y-3 relative">
        <AnimatePresence>
          {insights.map((insight, i) => {
            const colors = getColorClasses(insight.color)
            return (
              <motion.div
                key={insight.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`p-4 rounded-xl ${colors.bg} border ${colors.border} hover:shadow-lg ${colors.glow} transition-all cursor-pointer group`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`w-8 h-8 rounded-lg ${colors.bg} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                      <insight.icon className={`w-4 h-4 ${colors.text}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-sm font-medium text-white">{insight.title}</h4>
                        <Badge variant="outline" className={`text-[10px] h-5 ${colors.text} border-current/30`}>
                          {insight.metric}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-400 leading-relaxed">{insight.description}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`${colors.text} hover:${colors.bg} opacity-0 group-hover:opacity-100 transition-opacity text-xs flex-shrink-0`}
                  >
                    {insight.action}
                    <ArrowRight className="w-3 h-3 ml-1" />
                  </Button>
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>
    </div>
  )
}
