'use client'

import { Sparkles, TrendingUp, DollarSign, Users, Brain } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export function RevenuePredictorWidget() {
  return (
    <div className="glass-card rounded-xl overflow-hidden">
      <div className="p-4 border-b border-border flex items-center gap-2">
        <Brain className="w-4 h-4 text-accent" />
        <h3 className="font-semibold text-sm">AI Revenue Predictor</h3>
        <Badge variant="outline" className="text-[10px] bg-accent/10 text-accent border-accent/30 ml-auto">
          AI Powered
        </Badge>
      </div>
      <div className="p-4 space-y-4">
        <div className="p-4 rounded-lg bg-gradient-to-r from-primary/10 via-accent/5 to-transparent border border-primary/20">
          <div className="flex items-start gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/20 shrink-0">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium mb-1">Weekly Prediction</p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Based on <span className="text-foreground font-medium">12 leads</span> this week, our AI predicts <span className="text-success font-medium">3 will close</span>. Expected revenue: <span className="text-success font-bold">$2,400</span>.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="text-center p-3 rounded-lg bg-muted/30 border border-border">
            <Users className="w-4 h-4 text-primary mx-auto mb-1.5" />
            <p className="text-lg font-bold">12</p>
            <p className="text-[10px] text-muted-foreground">Active Leads</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-muted/30 border border-border">
            <TrendingUp className="w-4 h-4 text-accent mx-auto mb-1.5" />
            <p className="text-lg font-bold">25%</p>
            <p className="text-[10px] text-muted-foreground">Close Probability</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-muted/30 border border-border">
            <DollarSign className="w-4 h-4 text-success mx-auto mb-1.5" />
            <p className="text-lg font-bold text-success">$2.4k</p>
            <p className="text-[10px] text-muted-foreground">Expected</p>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-medium">Prediction factors</p>
          <div className="space-y-1.5">
            {[
              { label: 'Conversation tone analysis', value: 82 },
              { label: 'Response timing patterns', value: 91 },
              { label: 'Historical close rate', value: 74 },
            ].map((factor, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground flex-1">{factor.label}</span>
                <div className="w-20 h-1.5 rounded-full bg-muted/50 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                    style={{ width: `${factor.value}%` }}
                  />
                </div>
                <span className="text-[10px] text-muted-foreground w-8 text-right">{factor.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
