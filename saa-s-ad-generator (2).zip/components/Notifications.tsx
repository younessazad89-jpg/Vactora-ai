'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Bell, UserPlus, DollarSign, Bot, X } from 'lucide-react'

const notifications = [
  {
    id: '1',
    type: 'lead',
    title: 'New Lead Captured',
    description: 'James Mitchell from WhatsApp Ad',
    time: '2 min ago',
    unread: true
  },
  {
    id: '2',
    type: 'payment',
    title: 'Payment Received',
    description: 'David Chen - Pro Plan ($297)',
    time: '1 hour ago',
    unread: true
  },
  {
    id: '3',
    type: 'ai',
    title: 'AI Booked a Demo',
    description: 'Emma Thompson scheduled for 3pm',
    time: '3 hours ago',
    unread: false
  },
  {
    id: '4',
    type: 'lead',
    title: 'Lead Qualified',
    description: 'Sophie Martin marked as qualified',
    time: '5 hours ago',
    unread: false
  }
]

const iconMap = {
  lead: UserPlus,
  payment: DollarSign,
  ai: Bot
}

const colorMap = {
  lead: 'bg-primary/20 text-primary',
  payment: 'bg-success/20 text-success',
  ai: 'bg-accent/20 text-accent'
}

export function Notifications() {
  const [open, setOpen] = useState(false)
  const unreadCount = notifications.filter(n => n.unread).length

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 flex items-center justify-center w-4 h-4 text-[10px] font-bold bg-primary text-primary-foreground rounded-full">
              {unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h4 className="font-semibold">Notifications</h4>
          <Button variant="ghost" size="sm" className="text-xs text-muted-foreground h-auto py-1">
            Mark all read
          </Button>
        </div>
        <div className="max-h-[400px] overflow-y-auto">
          {notifications.map((notification) => {
            const Icon = iconMap[notification.type as keyof typeof iconMap]
            return (
              <div
                key={notification.id}
                className={cn(
                  "flex items-start gap-3 p-4 hover:bg-muted/50 transition-colors cursor-pointer border-b border-border last:border-0",
                  notification.unread && "bg-primary/5"
                )}
              >
                <div className={cn(
                  "flex items-center justify-center w-8 h-8 rounded-lg shrink-0",
                  colorMap[notification.type as keyof typeof colorMap]
                )}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium">{notification.title}</p>
                    {notification.unread && (
                      <div className="w-2 h-2 rounded-full bg-primary" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{notification.description}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">{notification.time}</p>
                </div>
              </div>
            )
          })}
        </div>
        <div className="p-3 border-t border-border">
          <Button variant="ghost" className="w-full text-sm" size="sm">
            View all notifications
          </Button>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
