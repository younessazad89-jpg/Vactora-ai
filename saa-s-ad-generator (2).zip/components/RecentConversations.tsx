'use client'

import { cn } from '@/lib/utils'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { dummyConversations } from '@/lib/data'
import { MessageSquare, ChevronRight } from 'lucide-react'
import Link from 'next/link'

export function RecentConversations() {
  const conversations = dummyConversations.slice(0, 5)

  return (
    <div className="glass-card rounded-xl">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-primary" />
          <h3 className="font-semibold">Recent Conversations</h3>
        </div>
        <Link 
          href="/conversations"
          className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
        >
          View all <ChevronRight className="w-3 h-3" />
        </Link>
      </div>
      <div className="divide-y divide-border">
        {conversations.map((conversation) => (
          <Link
            key={conversation.id}
            href={`/conversations?id=${conversation.id}`}
            className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors"
          >
            <div className="relative">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-gradient-to-br from-primary/20 to-accent/20 text-sm font-medium">
                  {conversation.leadName.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              {conversation.unread && (
                <div className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-primary rounded-full border-2 border-card" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-0.5">
                <span className={cn(
                  "font-medium text-sm",
                  conversation.unread && "text-foreground"
                )}>
                  {conversation.leadName}
                </span>
                <span className="text-xs text-muted-foreground">{conversation.timestamp}</span>
              </div>
              <p className="text-sm text-muted-foreground truncate">
                {conversation.lastMessage.startsWith('AI:') ? (
                  <>
                    <span className="text-primary font-medium">AI:</span>
                    {conversation.lastMessage.replace('AI:', '')}
                  </>
                ) : (
                  conversation.lastMessage
                )}
              </p>
            </div>
            <Badge 
              variant="outline" 
              className={cn(
                "text-[10px] shrink-0",
                conversation.status === 'active' && "border-success/50 text-success",
                conversation.status === 'pending' && "border-warning/50 text-warning",
                conversation.status === 'resolved' && "border-muted-foreground/50"
              )}
            >
              {conversation.status}
            </Badge>
          </Link>
        ))}
      </div>
    </div>
  )
}
