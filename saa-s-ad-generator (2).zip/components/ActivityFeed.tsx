'use client'

import { cn } from '@/lib/utils'
import { dummyActivities } from '@/lib/data'
import { 
  Activity as ActivityIcon, 
  UserPlus, 
  Calendar, 
  MessageSquare, 
  DollarSign, 
  RefreshCw,
  ChevronRight
} from 'lucide-react'
import Link from 'next/link'

const activityIcons = {
  lead_captured: UserPlus,
  call_booked: Calendar,
  message_sent: MessageSquare,
  payment_received: DollarSign,
  followup_sent: RefreshCw
}

const activityColors = {
  lead_captured: 'bg-primary/20 text-primary',
  call_booked: 'bg-chart-3/20 text-chart-3',
  message_sent: 'bg-chart-2/20 text-chart-2',
  payment_received: 'bg-success/20 text-success',
  followup_sent: 'bg-chart-5/20 text-chart-5'
}

export function ActivityFeed() {
  const activities = dummyActivities.slice(0, 8)

  return (
    <div className="glass-card rounded-xl">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <ActivityIcon className="w-4 h-4 text-accent" />
          <h3 className="font-semibold">AI Activity Feed</h3>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
          <span className="text-xs text-muted-foreground">Live</span>
        </div>
      </div>
      <div className="p-4 space-y-3 max-h-[400px] overflow-y-auto">
        {activities.map((activity, index) => {
          const Icon = activityIcons[activity.type]
          return (
            <div 
              key={activity.id}
              className={cn(
                "flex items-start gap-3 p-3 rounded-lg bg-muted/30 transition-all duration-300",
                index === 0 && "ring-1 ring-primary/20 bg-primary/5"
              )}
            >
              <div className={cn(
                "flex items-center justify-center w-8 h-8 rounded-lg shrink-0",
                activityColors[activity.type]
              )}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{activity.description}</p>
                <div className="flex items-center gap-2 mt-1">
                  {activity.leadName && (
                    <span className="text-xs text-muted-foreground">{activity.leadName}</span>
                  )}
                  {activity.amount && (
                    <span className="text-xs font-medium text-success">${activity.amount}</span>
                  )}
                </div>
              </div>
              <span className="text-[10px] text-muted-foreground whitespace-nowrap">{activity.timestamp}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
