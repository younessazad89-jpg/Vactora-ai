'use client'

import { cn } from '@/lib/utils'
import { 
  Users, 
  MessageSquare, 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  Clock,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react'

interface StatCardProps {
  title: string
  value: string | number
  change?: number
  changeLabel?: string
  icon: 'leads' | 'conversations' | 'bookings' | 'revenue' | 'conversion' | 'response'
  loading?: boolean
}

const iconMap = {
  leads: Users,
  conversations: MessageSquare,
  bookings: Calendar,
  revenue: DollarSign,
  conversion: TrendingUp,
  response: Clock
}

const colorMap = {
  leads: 'from-primary/20 to-primary/5 border-primary/20',
  conversations: 'from-chart-2/20 to-chart-2/5 border-chart-2/20',
  bookings: 'from-chart-3/20 to-chart-3/5 border-chart-3/20',
  revenue: 'from-success/20 to-success/5 border-success/20',
  conversion: 'from-chart-4/20 to-chart-4/5 border-chart-4/20',
  response: 'from-chart-5/20 to-chart-5/5 border-chart-5/20'
}

const iconColorMap = {
  leads: 'text-primary',
  conversations: 'text-chart-2',
  bookings: 'text-chart-3',
  revenue: 'text-success',
  conversion: 'text-chart-4',
  response: 'text-chart-5'
}

export function StatCard({ title, value, change, changeLabel, icon, loading }: StatCardProps) {
  const Icon = iconMap[icon]
  const isPositive = change && change > 0
  const isNegative = change && change < 0

  if (loading) {
    return (
      <div className="glass-card rounded-xl p-5 animate-pulse">
        <div className="flex items-start justify-between">
          <div className="space-y-3">
            <div className="h-4 w-24 bg-muted rounded" />
            <div className="h-8 w-32 bg-muted rounded" />
            <div className="h-3 w-20 bg-muted rounded" />
          </div>
          <div className="w-10 h-10 bg-muted rounded-lg" />
        </div>
      </div>
    )
  }

  return (
    <div className={cn(
      "glass-card rounded-xl p-5 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg",
      "bg-gradient-to-br",
      colorMap[icon]
    )}>
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-sm text-muted-foreground font-medium">{title}</p>
          <p className="text-2xl font-bold tracking-tight">{value}</p>
          {change !== undefined && (
            <div className="flex items-center gap-1 pt-1">
              {isPositive && <ArrowUpRight className="w-3 h-3 text-success" />}
              {isNegative && <ArrowDownRight className="w-3 h-3 text-destructive" />}
              <span className={cn(
                "text-xs font-medium",
                isPositive && "text-success",
                isNegative && "text-destructive",
                !isPositive && !isNegative && "text-muted-foreground"
              )}>
                {isPositive && '+'}{change}%
              </span>
              {changeLabel && (
                <span className="text-xs text-muted-foreground">{changeLabel}</span>
              )}
            </div>
          )}
        </div>
        <div className={cn(
          "flex items-center justify-center w-10 h-10 rounded-lg",
          "bg-gradient-to-br from-white/10 to-white/5"
        )}>
          <Icon className={cn("w-5 h-5", iconColorMap[icon])} />
        </div>
      </div>
    </div>
  )
}
