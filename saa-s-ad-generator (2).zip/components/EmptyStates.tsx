'use client'

import { Button } from '@/components/ui/button'
import { 
  Users, 
  MessageSquare, 
  Calendar, 
  Bot, 
  BarChart3, 
  FileText,
  Plus,
  Search,
  Sparkles
} from 'lucide-react'
import { ReactNode } from 'react'

interface EmptyStateProps {
  icon?: ReactNode
  title: string
  description: string
  action?: {
    label: string
    onClick: () => void
    icon?: ReactNode
  }
  secondaryAction?: {
    label: string
    onClick: () => void
  }
}

export function EmptyState({ 
  icon, 
  title, 
  description, 
  action, 
  secondaryAction 
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
      {icon && (
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center mb-4">
          {icon}
        </div>
      )}
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground max-w-sm mb-6">{description}</p>
      <div className="flex flex-col sm:flex-row gap-3">
        {action && (
          <Button onClick={action.onClick} className="bg-primary hover:bg-primary/90">
            {action.icon}
            {action.label}
          </Button>
        )}
        {secondaryAction && (
          <Button variant="outline" onClick={secondaryAction.onClick}>
            {secondaryAction.label}
          </Button>
        )}
      </div>
    </div>
  )
}

// Pre-configured empty states for common pages
export function EmptyLeads({ onAdd }: { onAdd: () => void }) {
  return (
    <EmptyState
      icon={<Users className="w-8 h-8 text-primary" />}
      title="No leads yet"
      description="Start capturing leads from your WhatsApp campaigns or add them manually to begin tracking your sales pipeline."
      action={{
        label: 'Add First Lead',
        onClick: onAdd,
        icon: <Plus className="w-4 h-4 mr-2" />,
      }}
      secondaryAction={{
        label: 'Import CSV',
        onClick: () => {},
      }}
    />
  )
}

export function EmptyConversations({ onStart }: { onStart: () => void }) {
  return (
    <EmptyState
      icon={<MessageSquare className="w-8 h-8 text-primary" />}
      title="No conversations yet"
      description="Your AI agent will start conversations automatically when leads come in. You can also start a conversation manually."
      action={{
        label: 'Start Conversation',
        onClick: onStart,
        icon: <Plus className="w-4 h-4 mr-2" />,
      }}
    />
  )
}

export function EmptyBookings({ onSchedule }: { onSchedule: () => void }) {
  return (
    <EmptyState
      icon={<Calendar className="w-8 h-8 text-primary" />}
      title="No upcoming bookings"
      description="When your AI agent books calls with leads, they will appear here. You can also manually schedule meetings."
      action={{
        label: 'Schedule Meeting',
        onClick: onSchedule,
        icon: <Plus className="w-4 h-4 mr-2" />,
      }}
    />
  )
}

export function EmptyAgents({ onCreate }: { onCreate: () => void }) {
  return (
    <EmptyState
      icon={<Bot className="w-8 h-8 text-primary" />}
      title="No AI agents configured"
      description="Create your first AI agent to start automating your sales conversations and follow-ups."
      action={{
        label: 'Create AI Agent',
        onClick: onCreate,
        icon: <Sparkles className="w-4 h-4 mr-2" />,
      }}
    />
  )
}

export function EmptyAnalytics() {
  return (
    <EmptyState
      icon={<BarChart3 className="w-8 h-8 text-primary" />}
      title="Not enough data"
      description="Analytics will appear once your AI agents start processing leads and conversations. This usually takes 24-48 hours."
    />
  )
}

export function EmptySearch({ query }: { query: string }) {
  return (
    <EmptyState
      icon={<Search className="w-8 h-8 text-muted-foreground" />}
      title="No results found"
      description={`We couldn't find anything matching "${query}". Try adjusting your search or filters.`}
    />
  )
}

export function EmptyNotes({ onAdd }: { onAdd: () => void }) {
  return (
    <EmptyState
      icon={<FileText className="w-8 h-8 text-primary" />}
      title="No notes yet"
      description="Add notes to keep track of important details about this lead or conversation."
      action={{
        label: 'Add Note',
        onClick: onAdd,
        icon: <Plus className="w-4 h-4 mr-2" />,
      }}
    />
  )
}
