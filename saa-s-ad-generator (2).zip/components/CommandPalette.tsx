'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Search,
  LayoutDashboard,
  Users,
  MessageSquare,
  Bot,
  Calendar,
  BarChart3,
  CreditCard,
  Settings,
  Zap,
  Globe,
  Shield,
  Gift,
  Mic,
  Brain,
  Megaphone,
  Workflow,
  FileText,
  Mail,
  Plus,
  ArrowRight,
  Sparkles,
  Command
} from 'lucide-react'
import { Input } from '@/components/ui/input'

interface CommandItem {
  id: string
  label: string
  description?: string
  icon: React.ComponentType<{ className?: string }>
  action: () => void
  category: 'navigation' | 'action' | 'ai'
}

export function CommandPalette() {
  const [isOpen, setIsOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [selectedIndex, setSelectedIndex] = useState(0)
  const router = useRouter()

  const commands: CommandItem[] = [
    // Navigation
    { id: 'dashboard', label: 'Go to Dashboard', icon: LayoutDashboard, action: () => router.push('/'), category: 'navigation' },
    { id: 'inbox', label: 'Go to Inbox', icon: MessageSquare, action: () => router.push('/inbox'), category: 'navigation' },
    { id: 'leads', label: 'Go to Leads', icon: Users, action: () => router.push('/leads'), category: 'navigation' },
    { id: 'crm', label: 'Go to CRM', icon: Workflow, action: () => router.push('/crm'), category: 'navigation' },
    { id: 'agents', label: 'Go to AI Agents', icon: Bot, action: () => router.push('/agents'), category: 'navigation' },
    { id: 'chatbot', label: 'Go to AI Chatbot', icon: MessageSquare, action: () => router.push('/chatbot'), category: 'navigation' },
    { id: 'voice', label: 'Go to Voice AI', icon: Mic, action: () => router.push('/voice'), category: 'navigation' },
    { id: 'training', label: 'Go to Training', icon: Brain, action: () => router.push('/training'), category: 'navigation' },
    { id: 'automations', label: 'Go to Automations', icon: Zap, action: () => router.push('/automations'), category: 'navigation' },
    { id: 'analytics', label: 'Go to Analytics', icon: BarChart3, action: () => router.push('/analytics'), category: 'navigation' },
    { id: 'ads', label: 'Go to Ads Generator', icon: Megaphone, action: () => router.push('/ads'), category: 'navigation' },
    { id: 'website', label: 'Go to Website Builder', icon: Globe, action: () => router.push('/website-builder'), category: 'navigation' },
    { id: 'funnels', label: 'Go to Funnels', icon: Workflow, action: () => router.push('/funnels'), category: 'navigation' },
    { id: 'bookings', label: 'Go to Bookings', icon: Calendar, action: () => router.push('/bookings'), category: 'navigation' },
    { id: 'billing', label: 'Go to Billing', icon: CreditCard, action: () => router.push('/billing'), category: 'navigation' },
    { id: 'settings', label: 'Go to Settings', icon: Settings, action: () => router.push('/settings'), category: 'navigation' },
    
    // Actions
    { id: 'new-lead', label: 'Create New Lead', description: 'Add a new lead to CRM', icon: Plus, action: () => router.push('/leads?new=true'), category: 'action' },
    { id: 'new-automation', label: 'Create Automation', description: 'Build a new workflow', icon: Zap, action: () => router.push('/automations?new=true'), category: 'action' },
    { id: 'new-agent', label: 'Create AI Agent', description: 'Set up a new AI agent', icon: Bot, action: () => router.push('/agents?new=true'), category: 'action' },
    { id: 'generate-report', label: 'Generate Report', description: 'Create analytics report', icon: FileText, action: () => router.push('/analytics?report=true'), category: 'action' },
    { id: 'send-email', label: 'Send Email Campaign', description: 'Create and send emails', icon: Mail, action: () => router.push('/automations?email=true'), category: 'action' },
    
    // AI
    { id: 'ai-analyze', label: 'AI: Analyze Leads', description: 'Get AI insights on leads', icon: Sparkles, action: () => router.push('/leads?ai=analyze'), category: 'ai' },
    { id: 'ai-generate-ads', label: 'AI: Generate Ads', description: 'Create AI-powered ads', icon: Megaphone, action: () => router.push('/ads?generate=true'), category: 'ai' },
    { id: 'ai-summary', label: 'AI: Executive Summary', description: 'Generate business summary', icon: FileText, action: () => router.push('/analytics?summary=true'), category: 'ai' },
  ]

  const filteredCommands = commands.filter(cmd => 
    cmd.label.toLowerCase().includes(search.toLowerCase()) ||
    cmd.description?.toLowerCase().includes(search.toLowerCase())
  )

  const groupedCommands = {
    ai: filteredCommands.filter(c => c.category === 'ai'),
    action: filteredCommands.filter(c => c.category === 'action'),
    navigation: filteredCommands.filter(c => c.category === 'navigation'),
  }

  const flatFiltered = [...groupedCommands.ai, ...groupedCommands.action, ...groupedCommands.navigation]

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setIsOpen(prev => !prev)
      }
      if (e.key === 'Escape') {
        setIsOpen(false)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  useEffect(() => {
    if (!isOpen) {
      setSearch('')
      setSelectedIndex(0)
    }
  }, [isOpen])

  const handleKeyNavigation = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setSelectedIndex(prev => (prev + 1) % flatFiltered.length)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setSelectedIndex(prev => (prev - 1 + flatFiltered.length) % flatFiltered.length)
    } else if (e.key === 'Enter' && flatFiltered[selectedIndex]) {
      flatFiltered[selectedIndex].action()
      setIsOpen(false)
    }
  }, [flatFiltered, selectedIndex])

  const runCommand = (cmd: CommandItem) => {
    cmd.action()
    setIsOpen(false)
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm"
          />

          {/* Palette */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ duration: 0.15 }}
            className="fixed top-[20%] left-1/2 -translate-x-1/2 z-[101] w-full max-w-[600px] bg-[#0a0a1a]/95 backdrop-blur-xl rounded-[18px] border border-white/10 shadow-2xl shadow-indigo-500/10 overflow-hidden"
          >
            {/* Search Input */}
            <div className="flex items-center gap-3 p-4 border-b border-white/10">
              <Search className="w-5 h-5 text-gray-400" />
              <Input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setSelectedIndex(0) }}
                onKeyDown={handleKeyNavigation}
                placeholder="Type a command or search..."
                className="flex-1 border-0 bg-transparent focus-visible:ring-0 text-white placeholder:text-gray-500"
                autoFocus
              />
              <kbd className="px-2 py-1 text-xs bg-white/5 border border-white/10 rounded text-gray-400">
                ESC
              </kbd>
            </div>

            {/* Commands */}
            <div className="max-h-[400px] overflow-y-auto p-2">
              {groupedCommands.ai.length > 0 && (
                <div className="mb-2">
                  <p className="px-3 py-1.5 text-xs font-medium text-indigo-400 flex items-center gap-2">
                    <Sparkles className="w-3 h-3" />
                    AI Actions
                  </p>
                  {groupedCommands.ai.map((cmd, idx) => (
                    <CommandRow 
                      key={cmd.id} 
                      cmd={cmd} 
                      isSelected={flatFiltered.indexOf(cmd) === selectedIndex}
                      onSelect={() => runCommand(cmd)}
                    />
                  ))}
                </div>
              )}

              {groupedCommands.action.length > 0 && (
                <div className="mb-2">
                  <p className="px-3 py-1.5 text-xs font-medium text-cyan-400 flex items-center gap-2">
                    <Zap className="w-3 h-3" />
                    Quick Actions
                  </p>
                  {groupedCommands.action.map((cmd, idx) => (
                    <CommandRow 
                      key={cmd.id} 
                      cmd={cmd} 
                      isSelected={flatFiltered.indexOf(cmd) === selectedIndex}
                      onSelect={() => runCommand(cmd)}
                    />
                  ))}
                </div>
              )}

              {groupedCommands.navigation.length > 0 && (
                <div>
                  <p className="px-3 py-1.5 text-xs font-medium text-gray-400 flex items-center gap-2">
                    <ArrowRight className="w-3 h-3" />
                    Navigation
                  </p>
                  {groupedCommands.navigation.map((cmd, idx) => (
                    <CommandRow 
                      key={cmd.id} 
                      cmd={cmd} 
                      isSelected={flatFiltered.indexOf(cmd) === selectedIndex}
                      onSelect={() => runCommand(cmd)}
                    />
                  ))}
                </div>
              )}

              {flatFiltered.length === 0 && (
                <div className="py-12 text-center">
                  <Search className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                  <p className="text-gray-400 text-sm">No commands found</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-white/10 bg-white/[0.02]">
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 bg-white/5 border border-white/10 rounded">↑↓</kbd>
                  Navigate
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 bg-white/5 border border-white/10 rounded">↵</kbd>
                  Select
                </span>
              </div>
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <Command className="w-3 h-3" />
                <span>+ K</span>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

function CommandRow({ cmd, isSelected, onSelect }: { cmd: CommandItem; isSelected: boolean; onSelect: () => void }) {
  return (
    <button
      onClick={onSelect}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
        isSelected ? 'bg-indigo-500/20 text-white' : 'text-gray-300 hover:bg-white/5'
      }`}
    >
      <cmd.icon className={`w-4 h-4 ${isSelected ? 'text-indigo-400' : 'text-gray-500'}`} />
      <div className="flex-1 text-left">
        <p className="text-sm font-medium">{cmd.label}</p>
        {cmd.description && (
          <p className={`text-xs ${isSelected ? 'text-indigo-300' : 'text-gray-500'}`}>{cmd.description}</p>
        )}
      </div>
      {isSelected && (
        <ArrowRight className="w-4 h-4 text-indigo-400" />
      )}
    </button>
  )
}
